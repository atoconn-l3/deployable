"use strict";
(self["webpackChunkverona_ng"] = self["webpackChunkverona_ng"] || []).push([["src_app_modules_app_inventory_vendor_vendor_module_ts"],{

/***/ 71286:
/*!*********************************************************!*\
  !*** ./src/app/core/inventory/vendor/vendor.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorSharedService: () => (/* binding */ VendorSharedService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 58071);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 13738);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2389);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 33252);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 81527);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 81891);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 20553);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 54860);




class VendorSharedService {
  constructor(_httpClient) {
    this._httpClient = _httpClient;
    // Base URLs
    this.BASE_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl;
    this.VENDORS_URL = `${this.BASE_URL}/vendors`;
    this.VENDOR_CATEGORIES_URL = `${this.BASE_URL}/vendor_categories`;
    // BehaviorSubjects
    this._category = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this._categories = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this._vendor = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this._vendors = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
  }
  // Accessors
  get category$() {
    return this._category.asObservable();
  }
  get categories$() {
    return this._categories.asObservable();
  }
  get vendor$() {
    return this._vendor.asObservable();
  }
  get vendors$() {
    return this._vendors.asObservable();
  }
  get getVendorsUrl() {
    return this.VENDORS_URL;
  }
  updateVendors(vendors) {
    this._vendors.next(vendors);
  }
  // Category Methods
  getCategoriesBySchool(schoolCode) {
    return this._httpClient.get(`${this.VENDOR_CATEGORIES_URL}/school/${schoolCode}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._categories.next(response.data);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to fetch vendor categories:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to fetch vendor categories',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }));
  }
  createCategory(category) {
    return this.categories$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(categories => this._httpClient.post(this.VENDOR_CATEGORIES_URL, category).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._categories.next([response.data, ...(categories || [])]);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to create vendor category:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to create vendor category',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  updateCategory(category) {
    return this.categories$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(categories => this._httpClient.put(`${this.VENDOR_CATEGORIES_URL}/code/${category.code}`, category).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        const index = categories?.findIndex(item => item.code === category.code) ?? -1;
        if (index !== -1 && categories) {
          categories[index] = response.data;
          this._categories.next(categories);
        }
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to update vendor category:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to update vendor category',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  deleteCategory(code) {
    return this.categories$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(categories => this._httpClient.delete(`${this.VENDOR_CATEGORIES_URL}/code/${code}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && categories) {
        const filteredCategories = categories.filter(item => item.code !== code);
        this._categories.next(filteredCategories);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to delete vendor category:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to delete vendor category',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  // Vendor Methods
  getVendorsBySchool(schoolCode) {
    return this._httpClient.get(`${this.VENDORS_URL}/school/${schoolCode}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._vendors.next(response.data);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to fetch vendors:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to fetch vendors',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }));
  }
  createVendor(vendor) {
    return this.vendors$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(vendors => this._httpClient.post(this.VENDORS_URL, vendor).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._vendors.next([response.data, ...(vendors || [])]);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to create vendor:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to create vendor',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  updateVendor(vendor) {
    return this.vendors$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(vendors => this._httpClient.put(`${this.VENDORS_URL}/${vendor.code}`, vendor).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        const index = vendors?.findIndex(item => item.code === vendor.code) ?? -1;
        if (index !== -1 && vendors) {
          vendors[index] = response.data;
          this._vendors.next(vendors);
        }
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to update vendor:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to update vendor',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  deleteVendor(code) {
    return this.vendors$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(vendors => this._httpClient.delete(`${this.VENDORS_URL}/${code}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && vendors) {
        const filteredVendors = vendors.filter(item => item.code !== code);
        this._vendors.next(filteredVendors);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to delete vendor:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to delete vendor',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  static #_ = this.ɵfac = function VendorSharedService_Factory(t) {
    return new (t || VendorSharedService)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjectable"]({
    token: VendorSharedService,
    factory: VendorSharedService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 75062:
/*!*******************************************************!*\
  !*** ./src/app/core/inventory/vendor/vendor.types.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorCategoryStatus: () => (/* binding */ VendorCategoryStatus),
/* harmony export */   VendorStatus: () => (/* binding */ VendorStatus)
/* harmony export */ });
// vendor-category.dto.ts
var VendorCategoryStatus;
(function (VendorCategoryStatus) {
  VendorCategoryStatus["ACTIVE"] = "ACTIVE";
  VendorCategoryStatus["INACTIVE"] = "INACTIVE";
})(VendorCategoryStatus || (VendorCategoryStatus = {}));
var VendorStatus;
(function (VendorStatus) {
  VendorStatus["ACTIVE"] = "ACTIVE";
  VendorStatus["INACTIVE"] = "INACTIVE";
})(VendorStatus || (VendorStatus = {}));

/***/ }),

/***/ 46164:
/*!******************************************************************************!*\
  !*** ./src/app/modules/app/inventory/vendor/category/list/list.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorCategoryListComponent: () => (/* binding */ VendorCategoryListComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/api */ 98026);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var src_app_core_inventory_vendor_vendor_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/inventory/vendor/vendor.types */ 75062);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/inventory/vendor/vendor.service */ 71286);
/* harmony import */ var src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/school/school.service */ 62915);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var _vendor_category_count_card_vendor_category_count_cards_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../vendor-category-count-card/vendor-category-count-cards.component */ 75122);



















function VendorCategoryListComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 25)(1, "span", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "i", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "input", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("input", function VendorCategoryListComponent_ng_template_14_Template_input_input_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](13);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.onGlobalFilter(_r0, $event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCategoryListComponent_ng_template_14_Template_button_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](13);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r8.clearFilters(_r0));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function VendorCategoryListComponent_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "p-sortIcon", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "th", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Vendor Count ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "p-sortIcon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "th", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Description ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "p-sortIcon", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Action");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
const _c0 = () => ({
  "min-width": "24px",
  width: "24px",
  height: "24px",
  padding: "0"
});
function VendorCategoryListComponent_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td")(2, "a", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCategoryListComponent_ng_template_16_Template_a_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r13);
      const category_r9 = restoredCtx.$implicit;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r12.goToVendorsByCategory(category_r9.code));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "td", 38)(9, "button", 39, 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCategoryListComponent_ng_template_16_Template_button_click_9_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r13);
      const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](12);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](_r11.toggle($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "p-menu", 41, 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const category_r9 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", category_r9.name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](category_r9.vendorCount);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](category_r9.description);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](8, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("popup", true)("model", ctx_r3.getActionItems(category_r9))("appendTo", "body");
  }
}
function VendorCategoryListComponent_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td", 43)(2, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "i", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "No categories available");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "span", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Add new categories using the 'Add Category' button");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
}
function VendorCategoryListComponent_ng_template_19_small_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "small", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Name is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
const _c1 = () => ({
  height: "40px",
  border: "1px solid #57335366",
  borderRadius: "8px"
});
const _c2 = () => ({
  width: "177.21px",
  height: "48px",
  gap: "8.7px",
  borderRadius: "6.96px",
  background: "linear-gradient(90deg, #5978F7 0%, #9C84FF 100%)",
  border: "none"
});
function VendorCategoryListComponent_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 48)(1, "div", 49)(2, "label", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "input", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, VendorCategoryListComponent_ng_template_19_small_5_Template, 2, 0, "small", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 49)(7, "label", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Description");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 49)(11, "label", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, "Remark");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 57)(15, "button", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCategoryListComponent_ng_template_19_Template_button_click_15_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r16.category.code ? ctx_r16.updateCategory() : ctx_r16.saveCategory());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    let tmp_2_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r5.categoryForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](13, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_2_0 = ctx_r5.categoryForm.get("name")) == null ? null : tmp_2_0.touched) && ((tmp_2_0 = ctx_r5.categoryForm.get("name")) == null ? null : tmp_2_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](14, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](15, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](16, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("icon", ctx_r5.submitted ? "pi pi-spinner pi-spin" : "")("label", ctx_r5.submitted ? "" : ctx_r5.category.code ? "Update" : "Add")("disabled", ctx_r5.categoryForm.invalid || ctx_r5.submitted);
  }
}
const _c3 = () => ["name", "description", "status"];
const _c4 = () => ({
  width: "450px"
});
const _c5 = () => ({
  width: "480px"
});
class VendorCategoryListComponent {
  constructor(_vendorService, _schoolService, _messageService, _confirmationService, _formBuilder, _router, _changeDetectorRef) {
    this._vendorService = _vendorService;
    this._schoolService = _schoolService;
    this._messageService = _messageService;
    this._confirmationService = _confirmationService;
    this._formBuilder = _formBuilder;
    this._router = _router;
    this._changeDetectorRef = _changeDetectorRef;
    this.submitted = false;
    // Data
    this.school = {};
    this.category = {
      name: '',
      schoolCode: '',
      vendorCount: 0,
      status: src_app_core_inventory_vendor_vendor_types__WEBPACK_IMPORTED_MODULE_0__.VendorCategoryStatus.ACTIVE
    };
    this.categories = [];
    this.selectedCategory = null;
    this.isRefreshCount = false;
    // UI States
    this.categoryDialog = false;
    this.deleteCategoryDialog = false;
    // Table
    this.cols = [{
      field: 'name',
      header: 'Name'
    }, {
      field: 'vendorCount',
      header: 'Vendor Count'
    }, {
      field: 'description',
      header: 'Description'
    }];
    this.rowsPerPageOptions = [5, 10, 20];
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
  }
  ngOnInit() {
    this.initForm();
    this.subscribeToSchool();
  }
  ngOnDestroy() {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
  initForm() {
    this.categoryForm = this._formBuilder.group({
      name: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100)]],
      description: [''],
      remark: [''],
      status: [src_app_core_inventory_vendor_vendor_types__WEBPACK_IMPORTED_MODULE_0__.VendorCategoryStatus.ACTIVE]
    });
  }
  subscribeToSchool() {
    this._schoolService.school$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._unsubscribeAll)).subscribe(school => {
      if (school?.code) {
        this.school = school;
        this._vendorService.getCategoriesBySchool(school.code).subscribe();
      }
      this._changeDetectorRef.markForCheck();
    });
    this._vendorService.categories$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._unsubscribeAll)).subscribe(categories => {
      if (categories) {
        this.categories = categories;
      }
      this._changeDetectorRef.markForCheck();
    });
  }
  createNewCategory() {
    this.category = {
      name: '',
      schoolCode: '',
      vendorCount: 0,
      status: src_app_core_inventory_vendor_vendor_types__WEBPACK_IMPORTED_MODULE_0__.VendorCategoryStatus.ACTIVE
    };
    this.submitted = false;
    this.categoryDialog = true;
  }
  saveCategory() {
    if (this.categoryForm.valid) {
      this.submitted = true;
      const categoryData = {
        ...this.categoryForm.getRawValue(),
        schoolCode: this.school.code,
        status: src_app_core_inventory_vendor_vendor_types__WEBPACK_IMPORTED_MODULE_0__.VendorCategoryStatus.ACTIVE
      };
      this._vendorService.createCategory(categoryData).subscribe({
        next: response => {
          if (response.success && response.data) {
            // Add new category to the beginning of the list
            // this.categories = [response.data, ...this.categories];
            this._changeDetectorRef.markForCheck();
            // ...existing code...
            this.isRefreshCount = true;
            setTimeout(() => this.isRefreshCount = false, 0);
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Category created successfully'
            });
            this.hideDialog();
          }
          this.submitted = false;
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to create category'
          });
        }
      });
    }
  }
  editCategory(category) {
    this.category = {
      ...category
    };
    this.categoryForm.patchValue(category);
    this.categoryDialog = true;
  }
  updateCategory() {
    if (this.categoryForm.valid && this.category.code) {
      this.submitted = true;
      const updatedCategory = {
        ...this.categoryForm.getRawValue(),
        code: this.category.code,
        schoolCode: this.school.code
      };
      this._vendorService.updateCategory(updatedCategory).subscribe({
        next: response => {
          if (response.success && response.data) {
            const index = this.categories.findIndex(item => item.code === this.category.code);
            if (index !== -1) {
              this.categories[index] = response.data;
              this.categories = [...this.categories];
              this._changeDetectorRef.markForCheck();
            }
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Category updated successfully'
            });
            this.hideDialog();
          }
          this.submitted = false;
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to update category'
          });
        }
      });
    }
  }
  deleteCategory(category) {
    this.category = category;
    this.deleteCategoryDialog = true;
  }
  confirmDelete() {
    if (this.category?.code) {
      this.submitted = true;
      this._vendorService.deleteCategory(this.category.code).subscribe({
        next: response => {
          if (response.success) {
            this.categories = this.categories.filter(item => item.code !== this.category.code);
            this.deleteCategoryDialog = false;
            this.submitted = false;
            // ...existing code...
            this.isRefreshCount = true;
            setTimeout(() => this.isRefreshCount = false, 0);
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Category deleted successfully'
            });
          }
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to delete category'
          });
        }
      });
    }
  }
  goToVendorsByCategory(categoryCode) {
    this._router.navigate(['/vendors/vendor-list'], {
      queryParams: {
        category: categoryCode
      }
    });
  }
  getActionItems(category) {
    return [{
      label: 'Edit',
      command: () => this.editCategory(category)
    }, {
      label: 'Delete',
      command: () => this.deleteCategory(category)
    }];
  }
  hideDialog() {
    this.categoryDialog = false;
    this.deleteCategoryDialog = false;
    this.submitted = false;
    this.categoryForm.reset();
  }
  onGlobalFilter(table, event) {
    table.filterGlobal(event.target.value, 'contains');
  }
  clearFilters(table) {
    table.clear();
  }
  static #_ = this.ɵfac = function VendorCategoryListComponent_Factory(t) {
    return new (t || VendorCategoryListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_1__.VendorSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_2__.SchoolSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: VendorCategoryListComponent,
    selectors: [["ng-component"]],
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵProvidersFeature"]([primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService, primeng_api__WEBPACK_IMPORTED_MODULE_8__.ConfirmationService])],
    decls: 32,
    vars: 26,
    consts: [[1, "grid"], [1, "col-12"], [1, "flex", "align-items-center", "justify-content-start", "mb-3"], [1, "text-xl", "font-medium", "text-color-secondary", 2, "color", "#573353 !important", "line-height", "14px", "font-size", "16px !important"], [1, "flex", "justify-content-between", "align-items-center", "flex-wrap", "w-full"], [3, "isRefreshCount"], ["pButton", "", 1, "flex", "align-items-center", "gap-2", "border-none", "mb-3", 2, "width", "241px", "height", "40px", "border-radius", "12px", "padding-left", "8px", "padding-right", "16px", "background", "linear-gradient(90deg, #5978f7 0%, #9c84ff 100%)", "color", "white", "font-weight", "500", 3, "click"], [1, "pi", "pi-plus", 2, "margin-right", "6px"], [1, "card", "px-3"], ["currentPageReportTemplate", "Showing {first} to {last} of {totalRecords} entries", "dataKey", "code", "responsiveLayout", "scroll", 3, "value", "columns", "rows", "paginator", "globalFilterFields", "rowsPerPageOptions", "showCurrentPageReport", "selection", "rowHover", "selectionChange"], ["dt", ""], ["pTemplate", "caption"], ["pTemplate", "header"], ["pTemplate", "body"], ["pTemplate", "emptymessage"], [1, "p-fluid", 3, "visible", "header", "modal", "visibleChange"], ["pTemplate", "content"], ["header", "Delete Category", "styleClass", "delete-dialog", 3, "visible", "modal", "showHeader", "visibleChange"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", "gap-3"], [1, "delete-icon-container"], [1, "pi", "pi-trash"], [1, "delete-message", "text-center"], [1, "flex", "align-items-center", "gap-2", "mt-4"], ["pButton", "", "pRipple", "", "label", "Cancel", 1, "p-button-outlined", "cancel-button", 3, "click"], ["pButton", "", "pRipple", "", 1, "delete-confirm-button", 3, "icon", "label", "click"], [1, "flex", "flex-column", "md:flex-row", "md:align-items-center", "gap-5"], [1, "block", "mt-2", "md:mt-0", "p-input-icon-left"], [1, "pi", "pi-search"], ["pInputText", "", "type", "text", "placeholder", "Search...", 1, "w-full", "sm:w-auto", 3, "input"], ["pButton", "", "type", "button", "label", "Clear", 1, "p-button-secondary", "clear-button", 3, "click"], ["pSortableColumn", "name"], ["field", "name"], ["pSortableColumn", "vendorCount"], ["field", "vendorCount"], ["pSortableColumn", "description"], ["field", "description"], [2, "width", "10%"], ["href", "javascript:void(0)", 2, "color", "#495057", "text-decoration", "none", "cursor", "pointer", 3, "click"], [1, "table-cell"], ["type", "button", "pButton", "", "icon", "pi pi-ellipsis-v", 1, "p-button-text", "p-button-plain", "action-button", 3, "click"], ["menuButton", ""], ["styleClass", "custom-action-menu", 3, "popup", "model", "appendTo"], ["menu", ""], ["colspan", "5"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", 2, "padding", "2rem"], [1, "pi", "pi-tag", 2, "font-size", "3rem", "color", "#ccc", "margin-bottom", "1rem"], [2, "font-size", "1.2rem", "color", "#666"], [2, "color", "#888", "margin-top", "0.5rem"], [1, "p-fluid", 3, "formGroup"], [1, "col-12", "pb-0"], ["for", "name"], ["pInputText", "", "id", "name", "formControlName", "name"], ["class", "p-error", 4, "ngIf"], ["for", "description"], ["pInputText", "", "id", "description", "formControlName", "description"], ["for", "remark"], ["pInputText", "", "id", "remark", "formControlName", "remark"], [1, "col-12", "flex", "justify-content-center", "gap-2"], ["pButton", "", "type", "submit", 1, "submit-button", 3, "icon", "label", "disabled", "click"], [1, "p-error"]],
    template: function VendorCategoryListComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, " Vendor Categories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "app-vendor-category-count-card", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCategoryListComponent_Template_button_click_7_listener() {
          return ctx.createNewCategory();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "i", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, " Create vendor category ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "p-toast");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "p-table", 9, 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("selectionChange", function VendorCategoryListComponent_Template_p_table_selectionChange_12_listener($event) {
          return ctx.selectedCategory = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, VendorCategoryListComponent_ng_template_14_Template, 5, 0, "ng-template", 11)(15, VendorCategoryListComponent_ng_template_15_Template, 12, 0, "ng-template", 12)(16, VendorCategoryListComponent_ng_template_16_Template, 13, 9, "ng-template", 13)(17, VendorCategoryListComponent_ng_template_17_Template, 8, 0, "ng-template", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "p-dialog", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function VendorCategoryListComponent_Template_p_dialog_visibleChange_18_listener($event) {
          return ctx.categoryDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, VendorCategoryListComponent_ng_template_19_Template, 16, 17, "ng-template", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "p-dialog", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function VendorCategoryListComponent_Template_p_dialog_visibleChange_20_listener($event) {
          return ctx.deleteCategoryDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 18)(22, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](23, "i", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "div", 21)(25, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, "Do you want to delete this category -");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "div", 22)(30, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCategoryListComponent_Template_button_click_30_listener() {
          return ctx.deleteCategoryDialog = false;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCategoryListComponent_Template_button_click_31_listener() {
          return ctx.confirmDelete();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("isRefreshCount", ctx.isRefreshCount);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", ctx.categories)("columns", ctx.cols)("rows", 10)("paginator", true)("globalFilterFields", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](23, _c3))("rowsPerPageOptions", ctx.rowsPerPageOptions)("showCurrentPageReport", true)("selection", ctx.selectedCategory)("rowHover", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](24, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.categoryDialog)("header", ctx.category.code ? "Edit Category" : "Add Category")("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](25, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.deleteCategoryDialog)("modal", true)("showHeader", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("\"", ctx.category == null ? null : ctx.category.name, "\"?");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("icon", ctx.submitted ? "pi pi-spinner pi-spin" : "")("label", ctx.submitted ? "" : "Delete");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, primeng_table__WEBPACK_IMPORTED_MODULE_11__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_8__.PrimeTemplate, primeng_table__WEBPACK_IMPORTED_MODULE_11__.SortableColumn, primeng_table__WEBPACK_IMPORTED_MODULE_11__.SortIcon, primeng_button__WEBPACK_IMPORTED_MODULE_12__.ButtonDirective, primeng_menu__WEBPACK_IMPORTED_MODULE_13__.Menu, primeng_ripple__WEBPACK_IMPORTED_MODULE_14__.Ripple, primeng_toast__WEBPACK_IMPORTED_MODULE_15__.Toast, primeng_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, primeng_dialog__WEBPACK_IMPORTED_MODULE_17__.Dialog, _vendor_category_count_card_vendor_category_count_cards_component__WEBPACK_IMPORTED_MODULE_3__.VendorCategoryCountCardComponent],
    styles: ["\n\n.flex[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  \n\n}\n\n\n\n.search-input[_ngcontent-%COMP%] {\n  width: 246px;\n  \n\n  height: 40px;\n  \n\n  padding-left: 10px;\n  \n\n  border-radius: 4px;\n  \n\n}\n\n.category-link[_ngcontent-%COMP%] {\n  color: #495057;\n  text-decoration: none;\n  cursor: pointer;\n}\n\n\n\n.clear-button[_ngcontent-%COMP%] {\n  width: 63px;\n  height: 23px;\n  gap: 6px;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 3px;\n  padding-top: 4px;\n  padding-right: 8px;\n  padding-bottom: 4px;\n  padding-left: 8px;\n}\n.clear-button[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n\n\n\n.clear-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  margin-right: 4px;\n  \n\n}\n\n  .add-button {\n  width: 11.5rem;\n  height: 3rem;\n  font-weight: 600;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 6px;\n  padding: 0.5rem 1rem;\n  transition: background 0.3s ease;\n  margin-bottom: 1rem;\n}\n  .add-button:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n  .add-button:disabled {\n  cursor: not-allowed !important;\n}\n\n.table-cell[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.action-container[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.plain-dots[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  cursor: pointer;\n  padding: 5px;\n}\n\n.custom-dropdown[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 100%;\n  background: white;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  border-radius: 4px;\n  z-index: 1000;\n}\n\n.dropdown-item[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  padding: 8px 16px;\n  border: none;\n  background: none;\n  text-align: left;\n  cursor: pointer;\n}\n.dropdown-item[_ngcontent-%COMP%]:hover {\n  background-color: #f5f5f5;\n}\n\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td {\n  background: #fff;\n  text-align: center;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i {\n  transition: color 0.2s;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i:hover {\n  color: #999 !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=role], [_nghost-%COMP%]     th[pSortableColumn=requestsPending], [_nghost-%COMP%]     th[pSortableColumn=requestsCompleted], [_nghost-%COMP%]     th[pSortableColumn=consumptions] {\n  text-align: center !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=role] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=requestsPending] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=requestsCompleted] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=consumptions] .p-sortable-column-icon {\n  margin-left: 4px;\n}\n\n[_nghost-%COMP%]     .custom-calendar .p-calendar {\n  min-width: 247px;\n  display: inline-flex;\n  position: relative;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar input {\n  width: 100%;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 8px 0 0 8px;\n  padding: 0.5rem;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger {\n  width: 40px;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 0 8px 8px 0;\n  color: #666;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:enabled:hover {\n  background: rgba(177, 175, 233, 0.1019607843);\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker {\n  min-width: 247px;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker.p-datepicker-inline {\n  position: absolute;\n  top: 100%;\n  left: 0;\n  z-index: 1000;\n}\n\n[_nghost-%COMP%]     .update-button {\n  width: 364.42px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .update-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .update-button:disabled {\n  opacity: 0.6;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  cursor: not-allowed;\n}\n\n.classroom-initial[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  background: #E6E8F3;\n  color: #FFFFFF;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.classroom-count[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 23px;\n  gap: 16px;\n  padding: 4px 8px;\n  border-radius: 3px;\n  background-color: rgba(217, 255, 203, 0.4);\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  color: #333333;\n}\n\n  .p-tooltip .p-tooltip-text {\n  background-color: #F0FFEA !important;\n  color: #333333 !important;\n  border: 1px solid #E6E6E6;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  font-size: 11px;\n}\n  .p-tooltip .p-tooltip-arrow {\n  border-top-color: #F0FFEA !important;\n}\n\n.classroom-count-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #6E6E6E;\n  cursor: pointer;\n  opacity: 0.7;\n  transition: opacity 0.2s;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%]:hover {\n  opacity: 1;\n}\n\n[_nghost-%COMP%]     .p-menu {\n  background: none !important;\n  border: none !important;\n  box-shadow: none !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay {\n  margin: 0;\n  padding: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu {\n  width: 73px !important;\n  min-height: 80px !important;\n  padding: 16px !important;\n  border-radius: 8px !important;\n  border: 1px solid #E6E6E6 !important;\n  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.05) !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu * {\n  background: #FFFFFF !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list {\n  gap: 16px;\n  display: flex;\n  flex-direction: column;\n  padding: 0;\n  margin: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem {\n  margin: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link {\n  padding: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link:hover .p-menuitem-text, [_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link:hover .p-menuitem-icon {\n  color: #5978F7 !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link .p-menuitem-icon {\n  font-size: 12px;\n  margin-right: 8px;\n  color: #6C757D !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link .p-menuitem-text {\n  font-size: 12px;\n  color: #495057 !important;\n}\n\n[_nghost-%COMP%]     .delete-dialog .p-dialog-content {\n  padding: 2rem;\n}\n[_nghost-%COMP%]     .delete-icon-container {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background-color: #D92D20;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 1rem;\n}\n[_nghost-%COMP%]     .delete-icon-container .pi-trash {\n  font-size: 24px;\n  color: #FFFFFF;\n}\n[_nghost-%COMP%]     .delete-message {\n  font-size: 14px;\n  color: #344054;\n  line-height: 1.5;\n}\n[_nghost-%COMP%]     .delete-message strong {\n  color: #101828;\n}\n\n[_nghost-%COMP%]     .delete-confirm-button {\n  width: 177px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .delete-confirm-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .delete-confirm-button:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .cancel-button {\n  color: #6C757D;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n  color: #495057;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .cancel-button {\n  width: 177.21px;\n  height: 48px;\n  border-radius: 6.96px;\n  gap: 8.7px;\n  background: transparent;\n  position: relative;\n}\n[_nghost-%COMP%]     .cancel-button::before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  border-radius: 6.96px;\n  border: 1px solid transparent;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%) border-box;\n  -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);\n  -webkit-mask-composite: destination-out;\n  mask-composite: exclude;\n}\n[_nghost-%COMP%]     .cancel-button .p-button-label {\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n}\n[_nghost-%COMP%]     .cancel-button:hover::before {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%) border-box;\n}\n[_nghost-%COMP%]     .cancel-button:hover .p-button-label {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .p-dialog.p-fluid {\n  height: auto;\n}\n[_nghost-%COMP%]     .p-dialog.p-fluid .p-dialog-content {\n  overflow-y: visible;\n  overflow-x: hidden;\n  max-height: none !important;\n}\n[_nghost-%COMP%]     .p-dialog .p-fluid .grid {\n  row-gap: 1.5rem;\n}\n\n[_nghost-%COMP%]     .p-dropdown {\n  display: flex;\n  align-items: center;\n}\n[_nghost-%COMP%]     .p-dropdown .p-dropdown-label {\n  padding-top: 0;\n  padding-bottom: 0;\n  line-height: 31px;\n}\n[_nghost-%COMP%]     .p-dropdown .p-dropdown-trigger {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvaW52ZW50b3J5L3ZlbmRvci9jYXRlZ29yeS9saXN0L2xpc3QuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi9OZXclMjBmb2xkZXIvdmdzY2hvb2wtdGhlbWUvc3JjL2FwcC9tb2R1bGVzL2FwcC9pbnZlbnRvcnkvdmVuZG9yL2NhdGVnb3J5L2xpc3QvbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxtREFBQTtBQUNBO0VBQ0ksYUFBQTtFQUNBLFNBQUE7RUFDQSxrQ0FBQTtBQ0NKOztBREVBLHdCQUFBO0FBQ0E7RUFDSSxZQUFBO0VBQ0Esa0NBQUE7RUFDQSxZQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLDhDQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQ0FBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVBLCtCQUFBO0FBQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVEQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQ0NKO0FEQ0k7RUFDSSx1REFBQTtBQ0NSOztBREdBLDBDQUFBO0FBQ0E7RUFDSSxpQkFBQTtFQUNBLHVEQUFBO0FDQUo7O0FES0k7RUFDSSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSx1REFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQ0FBQTtFQUNBLG1CQUFBO0FDRlI7QURJUTtFQUNJLHVEQUFBO0FDRlo7QURLUTtFQUVJLDhCQUFBO0FDSlo7O0FEVUE7RUFDSSxrQkFBQTtBQ1BKOztBRFVBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtBQ1BKOztBRFVBO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUNQSjs7QURVQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLHdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FDUEo7O0FEVUE7RUFDSSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDUEo7QURTSTtFQUNJLHlCQUFBO0FDUFI7O0FEY1k7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0FDWGhCO0FEYWdCO0VBQ0ksc0JBQUE7QUNYcEI7QURhb0I7RUFDSSxzQkFBQTtBQ1h4QjtBRHFCSTs7OztFQUlJLDZCQUFBO0FDbkJSO0FEcUJROzs7O0VBQ0ksZ0JBQUE7QUNoQlo7O0FEMEJRO0VBQ0ksZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0FDdkJaO0FEeUJZO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSw2Q0FBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtFQUNBLGVBQUE7QUN2QmhCO0FEMEJZO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSw2Q0FBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtFQUNBLFdBQUE7QUN4QmhCO0FEMEJnQjtFQUNJLDZDQUFBO0FDeEJwQjtBRDJCZ0I7RUFDSSxnQkFBQTtBQ3pCcEI7QUQ4QlE7RUFDSSxnQkFBQTtBQzVCWjtBRDhCWTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLE9BQUE7RUFDQSxhQUFBO0FDNUJoQjs7QURtQ0k7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsNERBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNoQ1I7QURrQ1E7RUFDSSw0REFBQTtBQ2hDWjtBRG1DUTtFQUNJLFlBQUE7RUFDQSw0REFBQTtFQUNBLG1CQUFBO0FDakNaOztBRHNDQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ25DSjs7QURzQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMENBQUE7RUFDQSxvQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQ25DSjs7QUR1Q0k7RUFDSSxvQ0FBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx3Q0FBQTtFQUNBLGVBQUE7QUNwQ1I7QUR1Q0k7RUFDSSxvQ0FBQTtBQ3JDUjs7QUR5Q0E7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxRQUFBO0FDdENKO0FEd0NJO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHdCQUFBO0FDdENSO0FEd0NRO0VBQ0ksVUFBQTtBQ3RDWjs7QUQ4Q0k7RUFDSSwyQkFBQTtFQUNBLHVCQUFBO0VBQ0EsMkJBQUE7QUMzQ1I7QURnRFE7RUFDSSxTQUFBO0VBQ0EsVUFBQTtBQzlDWjtBRGdEWTtFQUNJLHNCQUFBO0VBQ0EsMkJBQUE7RUFDQSx3QkFBQTtFQUNBLDZCQUFBO0VBQ0Esb0NBQUE7RUFDQSxzREFBQTtBQzlDaEI7QURnRGdCO0VBQ0ksOEJBQUE7QUM5Q3BCO0FEaURnQjtFQUNJLFNBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtBQy9DcEI7QURpRG9CO0VBQ0ksU0FBQTtBQy9DeEI7QURpRHdCO0VBQ0ksVUFBQTtBQy9DNUI7QURtRGdDOztFQUVJLHlCQUFBO0FDakRwQztBRHFENEI7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtBQ25EaEM7QURzRDRCO0VBQ0ksZUFBQTtFQUNBLHlCQUFBO0FDcERoQzs7QURnRVE7RUFDSSxhQUFBO0FDN0RaO0FEaUVJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQy9EUjtBRGlFUTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FDL0RaO0FEbUVJO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ2pFUjtBRG1FUTtFQUNJLGNBQUE7QUNqRVo7O0FEdUVJO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLDREQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDcEVSO0FEc0VRO0VBQ0ksNERBQUE7QUNwRVo7QUR1RVE7RUFDSSxnQkFBQTtBQ3JFWjtBRHlFSTtFQUNJLGNBQUE7QUN2RVI7QUR5RVE7RUFDSSx1QkFBQTtFQUNBLGNBQUE7QUN2RVo7QUQwRVE7RUFDSSxnQkFBQTtBQ3hFWjs7QUQ4RUk7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUMzRVI7QUQ4RVE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EscUJBQUE7RUFDQSw2QkFBQTtFQUNBLHVFQUFBO0VBQ0EsOEVBQ0k7RUFFSix1Q0FBQTtFQUNBLHVCQUFBO0FDOUVaO0FEa0ZRO0VBQ0ksNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0NBQUE7RUFDQSxnQkFBQTtBQ2hGWjtBRG1GUTtFQUNJLHVCQUFBO0FDakZaO0FEbUZZO0VBQ0ksdUVBQUE7QUNqRmhCO0FEb0ZZO0VBQ0ksNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0FDbEZoQjtBRHNGUTtFQUNJLGdCQUFBO0FDcEZaOztBRDZGUTtFQUNJLFlBQUE7QUMxRlo7QUQ0Rlk7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7QUMxRmhCO0FEcUdZO0VBQ0ksZUFBQTtBQ25HaEI7O0FEMkdJO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0FDeEdSO0FEMEdRO0VBQ0ksY0FBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUN4R1o7QUQyR1E7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7QUN6R1oiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBHZW5lcmFsIEZsZXggTGF5b3V0OiAxMnB4IGdhcCBiZXR3ZWVuIGNvbnRyb2xzICovXHJcbi5mbGV4IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBnYXA6IDEycHg7XHJcbiAgICAvKiAxMnB4IGdhcCBiZXR3ZWVuIGVhY2ggY29udHJvbCAqL1xyXG59XHJcblxyXG4vKiBTZWFyY2ggSW5wdXQgc3R5bGVzICovXHJcbi5zZWFyY2gtaW5wdXQge1xyXG4gICAgd2lkdGg6IDI0NnB4O1xyXG4gICAgLyogTWF0Y2hpbmcgdGhlIHdpZHRoIGZyb20gRmlnbWEgKi9cclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIC8qIE1hdGNoaW5nIHRoZSBoZWlnaHQgZnJvbSBGaWdtYSAqL1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgLyogT3B0aW9uYWw6IFNwYWNlIGJldHdlZW4gdGhlIGljb24gYW5kIHRleHQgKi9cclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIC8qIFJvdW5kZWQgY29ybmVycyBmb3IgdGhlIGlucHV0ICovXHJcbn1cclxuXHJcbi5jYXRlZ29yeS1saW5rIHtcclxuICAgIGNvbG9yOiAjNDk1MDU3O1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4vKiBDbGVhciBCdXR0b24gY3VzdG9tIHN0eWxlcyAqL1xyXG4uY2xlYXItYnV0dG9uIHtcclxuICAgIHdpZHRoOiA2M3B4O1xyXG4gICAgaGVpZ2h0OiAyM3B4O1xyXG4gICAgZ2FwOiA2cHg7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzU5NzhGNywgIzlDODRGRik7IC8vIEluZGlnbyA1MDAgdG8gNjAwXHJcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XHJcbiAgICBwYWRkaW5nLXRvcDogNHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogOHB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDRweDtcclxuICAgIHBhZGRpbmctbGVmdDogOHB4O1xyXG5cclxuICAgICY6aG92ZXIge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzRCNjhFMSwgIzhCNkVGRik7IC8vIERhcmtlciBvbiBob3ZlclxyXG4gICAgfVxyXG59XHJcblxyXG4vKiBPcHRpb25hbDogU3R5bGUgZm9yIHRoZSBidXR0b24ncyBpY29uICovXHJcbi5jbGVhci1idXR0b24gaSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDRweDtcclxuICAgIC8qIEFkanVzdCBpZiB5b3Ugd2FudCBzcGFjZSBiZXR3ZWVuIHRoZSBpY29uIGFuZCB0ZXh0ICovXHJcbn1cclxuXHJcblxyXG46Om5nLWRlZXAge1xyXG4gICAgLmFkZC1idXR0b24ge1xyXG4gICAgICAgIHdpZHRoOiAxMS41cmVtO1xyXG4gICAgICAgIGhlaWdodDogM3JlbTtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpOyAvLyBJbmRpZ28gNTAwIHRvIDYwMFxyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICAgICAgICBwYWRkaW5nOiAwLjVyZW0gMXJlbTtcclxuICAgICAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuM3MgZWFzZTtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNEI2OEUxLCAjOEI2RUZGKTsgLy8gRGFya2VyIG9uIGhvdmVyXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAmOmRpc2FibGVkIHtcclxuICAgICAgICAgICAgLy8gb3BhY2l0eTogMC42ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGN1cnNvcjogbm90LWFsbG93ZWQgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG4udGFibGUtY2VsbCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5hY3Rpb24tY29udGFpbmVyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG5cclxuLnBsYWluLWRvdHMge1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHBhZGRpbmc6IDVweDtcclxufVxyXG5cclxuLmN1c3RvbS1kcm9wZG93biB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogMDtcclxuICAgIHRvcDogMTAwJTtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgYm94LXNoYWRvdzogMCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIHotaW5kZXg6IDEwMDA7XHJcbn1cclxuXHJcbi5kcm9wZG93bi1pdGVtIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nOiA4cHggMTZweDtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG5cclxuICAgICY6aG92ZXIge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWY1ZjU7XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAucC1kYXRhdGFibGUge1xyXG4gICAgICAgIC5wLWRhdGF0YWJsZS1lbXB0eW1lc3NhZ2Uge1xyXG4gICAgICAgICAgICB0ZCB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxuICAgICAgICAgICAgICAgIGkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IGNvbG9yIDAuMnM7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICY6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzk5OSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBFbnN1cmUgaGVhZGVyIGNlbGxzIGFyZSBhbHNvIGNlbnRlcmVkXHJcbiAgICAvLyB0aFtwU29ydGFibGVDb2x1bW49XCJuYW1lXCJdLFxyXG4gICAgLy8gdGhbcFNvcnRhYmxlQ29sdW1uPVwiY2xhc3Nyb29tc1wiXSxcclxuICAgIHRoW3BTb3J0YWJsZUNvbHVtbj1cInJvbGVcIl0sXHJcbiAgICB0aFtwU29ydGFibGVDb2x1bW49XCJyZXF1ZXN0c1BlbmRpbmdcIl0sXHJcbiAgICB0aFtwU29ydGFibGVDb2x1bW49XCJyZXF1ZXN0c0NvbXBsZXRlZFwiXSxcclxuICAgIHRoW3BTb3J0YWJsZUNvbHVtbj1cImNvbnN1bXB0aW9uc1wiXSB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XHJcblxyXG4gICAgICAgIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uIHtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDRweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxufVxyXG5cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAuY3VzdG9tLWNhbGVuZGFyIHtcclxuICAgICAgICAucC1jYWxlbmRhciB7XHJcbiAgICAgICAgICAgIG1pbi13aWR0aDogMjQ3cHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgICAgICAgICBpbnB1dCB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNCMUFGRTkxQTtcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweCAwIDAgOHB4O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMC41cmVtO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAucC1kYXRlcGlja2VyLXRyaWdnZXIge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDQwcHg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjQjFBRkU5MUE7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwIDhweCA4cHggMDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAjNjY2O1xyXG5cclxuICAgICAgICAgICAgICAgICY6ZW5hYmxlZDpob3ZlciB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0IxQUZFOTFBO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5wLWRhdGVwaWNrZXIge1xyXG4gICAgICAgICAgICBtaW4td2lkdGg6IDI0N3B4O1xyXG5cclxuICAgICAgICAgICAgJi5wLWRhdGVwaWNrZXItaW5saW5lIHtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIHRvcDogMTAwJTtcclxuICAgICAgICAgICAgICAgIGxlZnQ6IDA7XHJcbiAgICAgICAgICAgICAgICB6LWluZGV4OiAxMDAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLnVwZGF0ZS1idXR0b24ge1xyXG4gICAgICAgIHdpZHRoOiAzNjQuNDJweDtcclxuICAgICAgICBoZWlnaHQ6IDQ4cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNi45NnB4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcclxuICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6ZGlzYWJsZWQge1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAwLjY7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcclxuICAgICAgICAgICAgY3Vyc29yOiBub3QtYWxsb3dlZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jbGFzc3Jvb20taW5pdGlhbCB7XHJcbiAgICB3aWR0aDogMjRweDtcclxuICAgIGhlaWdodDogMjRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGJhY2tncm91bmQ6ICNFNkU4RjM7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4uY2xhc3Nyb29tLWNvdW50IHtcclxuICAgIHdpZHRoOiAzMnB4O1xyXG4gICAgaGVpZ2h0OiAyM3B4O1xyXG4gICAgZ2FwOiAxNnB4O1xyXG4gICAgcGFkZGluZzogNHB4IDhweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNEOUZGQ0I2NjtcclxuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICMzMzMzMzM7XHJcbn1cclxuXHJcbjo6bmctZGVlcCAucC10b29sdGlwIHtcclxuICAgIC5wLXRvb2x0aXAtdGV4dCB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0YwRkZFQSAhaW1wb3J0YW50O1xyXG4gICAgICAgIGNvbG9yOiAjMzMzMzMzICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNjtcclxuICAgICAgICBib3gtc2hhZG93OiAwIDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIH1cclxuXHJcbiAgICAucC10b29sdGlwLWFycm93IHtcclxuICAgICAgICBib3JkZXItdG9wLWNvbG9yOiAjRjBGRkVBICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jbGFzc3Jvb20tY291bnQtd3JhcHBlciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGdhcDogOHB4O1xyXG5cclxuICAgIC5lZGl0LWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBjb2xvcjogIzZFNkU2RTtcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgb3BhY2l0eTogMC43O1xyXG4gICAgICAgIHRyYW5zaXRpb246IG9wYWNpdHkgMC4ycztcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDE7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG5cclxuICAgIC8vIFJlc2V0IGFuZCBvdmVycmlkZSBhbGwgbWVudSBzdHlsZXNcclxuICAgIC5wLW1lbnUge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gU3R5bGUgdGhlIHNwZWNpZmljIG1lbnUgb3ZlcmxheVxyXG4gICAgLmN1c3RvbS1hY3Rpb24tbWVudSB7XHJcbiAgICAgICAgJi5wLW1lbnUtb3ZlcmxheSB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuXHJcbiAgICAgICAgICAgIC5wLW1lbnUge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDczcHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDgwcHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDE2cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjA1KSAhaW1wb3J0YW50O1xyXG5cclxuICAgICAgICAgICAgICAgICoge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNGRkZGRkYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAucC1tZW51LWxpc3Qge1xyXG4gICAgICAgICAgICAgICAgICAgIGdhcDogMTZweDtcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC5wLW1lbnVpdGVtIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnAtbWVudWl0ZW0tbGluayB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICY6aG92ZXIge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbS10ZXh0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5wLW1lbnVpdGVtLWljb24ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzU5NzhGNyAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbS1pY29uIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA4cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM2Qzc1N0QgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbS10ZXh0IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM0OTUwNTcgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5kZWxldGUtZGlhbG9nIHtcclxuICAgICAgICAucC1kaWFsb2ctY29udGVudCB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDJyZW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5kZWxldGUtaWNvbi1jb250YWluZXIge1xyXG4gICAgICAgIHdpZHRoOiA2NHB4O1xyXG4gICAgICAgIGhlaWdodDogNjRweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0Q5MkQyMDtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAgICAgLnBpLXRyYXNoIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmRlbGV0ZS1tZXNzYWdlIHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgY29sb3I6ICMzNDQwNTQ7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDEuNTtcclxuXHJcbiAgICAgICAgc3Ryb25nIHtcclxuICAgICAgICAgICAgY29sb3I6ICMxMDE4Mjg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDE3N3B4O1xyXG4gICAgICAgIGhlaWdodDogNDhweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xyXG4gICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpmb2N1cyB7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5jYW5jZWwtYnV0dG9uIHtcclxuICAgICAgICBjb2xvcjogIzZDNzU3RDtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICBjb2xvcjogIzQ5NTA1NztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5jYW5jZWwtYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMTc3LjIxcHg7XHJcbiAgICAgICAgaGVpZ2h0OiA0OHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcclxuICAgICAgICBnYXA6IDguN3B4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAgICAgLy8gQ3JlYXRlIGdyYWRpZW50IGJvcmRlclxyXG4gICAgICAgICY6OmJlZm9yZSB7XHJcbiAgICAgICAgICAgIGNvbnRlbnQ6ICcnO1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDogMDtcclxuICAgICAgICAgICAgbGVmdDogMDtcclxuICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgIGJvdHRvbTogMDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNi45NnB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpIGJvcmRlci1ib3g7XHJcbiAgICAgICAgICAgIC13ZWJraXQtbWFzazpcclxuICAgICAgICAgICAgICAgIGxpbmVhci1ncmFkaWVudCgjZmZmIDAgMCkgcGFkZGluZy1ib3gsXHJcbiAgICAgICAgICAgICAgICBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApO1xyXG4gICAgICAgICAgICAtd2Via2l0LW1hc2stY29tcG9zaXRlOiBkZXN0aW5hdGlvbi1vdXQ7XHJcbiAgICAgICAgICAgIG1hc2stY29tcG9zaXRlOiBleGNsdWRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gR3JhZGllbnQgdGV4dFxyXG4gICAgICAgIC5wLWJ1dHRvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcclxuICAgICAgICAgICAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY2xpcDogdGV4dDtcclxuICAgICAgICAgICAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cclxuICAgICAgICAgICAgJjo6YmVmb3JlIHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKSBib3JkZXItYm94O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAucC1idXR0b24tbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xyXG4gICAgICAgICAgICAgICAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuXHJcbiAgICAvLyBBZGQgdGhpcyBuZXcgc2VjdGlvblxyXG4gICAgLnAtZGlhbG9nIHtcclxuICAgICAgICAmLnAtZmx1aWQge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IGF1dG87XHJcblxyXG4gICAgICAgICAgICAucC1kaWFsb2ctY29udGVudCB7XHJcbiAgICAgICAgICAgICAgICBvdmVyZmxvdy15OiB2aXNpYmxlO1xyXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgICAgICAgICAgICAgbWF4LWhlaWdodDogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgLy8gcGFkZGluZzogMnJlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnAtZGlhbG9nLWhlYWRlciB7XHJcbiAgICAgICAgICAgIC8vIHBhZGRpbmc6IDJyZW0gMnJlbSAwIDJyZW07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBBZGp1c3QgZm9ybSBzcGFjaW5nXHJcbiAgICAgICAgLnAtZmx1aWQge1xyXG4gICAgICAgICAgICAuZ3JpZCB7XHJcbiAgICAgICAgICAgICAgICByb3ctZ2FwOiAxLjVyZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8vIEFkZCB0aGlzIHRvIHlvdXIgZXhpc3RpbmcgOmhvc3QgOjpuZy1kZWVwIHNlY3Rpb25cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5wLWRyb3Bkb3duIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgICAgIC5wLWRyb3Bkb3duLWxhYmVsIHtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDA7XHJcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAwO1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMzFweDsgLy8gQWRqdXN0IHRoaXMgdG8gbWF0Y2ggeW91ciBoZWlnaHQgLSAycHggZm9yIGJvcmRlcnNcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5wLWRyb3Bkb3duLXRyaWdnZXIge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iLCIvKiBHZW5lcmFsIEZsZXggTGF5b3V0OiAxMnB4IGdhcCBiZXR3ZWVuIGNvbnRyb2xzICovXG4uZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGdhcDogMTJweDtcbiAgLyogMTJweCBnYXAgYmV0d2VlbiBlYWNoIGNvbnRyb2wgKi9cbn1cblxuLyogU2VhcmNoIElucHV0IHN0eWxlcyAqL1xuLnNlYXJjaC1pbnB1dCB7XG4gIHdpZHRoOiAyNDZweDtcbiAgLyogTWF0Y2hpbmcgdGhlIHdpZHRoIGZyb20gRmlnbWEgKi9cbiAgaGVpZ2h0OiA0MHB4O1xuICAvKiBNYXRjaGluZyB0aGUgaGVpZ2h0IGZyb20gRmlnbWEgKi9cbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAvKiBPcHRpb25hbDogU3BhY2UgYmV0d2VlbiB0aGUgaWNvbiBhbmQgdGV4dCAqL1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIC8qIFJvdW5kZWQgY29ybmVycyBmb3IgdGhlIGlucHV0ICovXG59XG5cbi5jYXRlZ29yeS1saW5rIHtcbiAgY29sb3I6ICM0OTUwNTc7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4vKiBDbGVhciBCdXR0b24gY3VzdG9tIHN0eWxlcyAqL1xuLmNsZWFyLWJ1dHRvbiB7XG4gIHdpZHRoOiA2M3B4O1xuICBoZWlnaHQ6IDIzcHg7XG4gIGdhcDogNnB4O1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyOiBub25lO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpO1xuICBib3JkZXItcmFkaXVzOiAzcHg7XG4gIHBhZGRpbmctdG9wOiA0cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDhweDtcbiAgcGFkZGluZy1ib3R0b206IDRweDtcbiAgcGFkZGluZy1sZWZ0OiA4cHg7XG59XG4uY2xlYXItYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNEI2OEUxLCAjOEI2RUZGKTtcbn1cblxuLyogT3B0aW9uYWw6IFN0eWxlIGZvciB0aGUgYnV0dG9uJ3MgaWNvbiAqL1xuLmNsZWFyLWJ1dHRvbiBpIHtcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XG4gIC8qIEFkanVzdCBpZiB5b3Ugd2FudCBzcGFjZSBiZXR3ZWVuIHRoZSBpY29uIGFuZCB0ZXh0ICovXG59XG5cbjo6bmctZGVlcCAuYWRkLWJ1dHRvbiB7XG4gIHdpZHRoOiAxMS41cmVtO1xuICBoZWlnaHQ6IDNyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiAjZmZmO1xuICBib3JkZXI6IG5vbmU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzU5NzhGNywgIzlDODRGRik7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgcGFkZGluZzogMC41cmVtIDFyZW07XG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4zcyBlYXNlO1xuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xufVxuOjpuZy1kZWVwIC5hZGQtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNEI2OEUxLCAjOEI2RUZGKTtcbn1cbjo6bmctZGVlcCAuYWRkLWJ1dHRvbjpkaXNhYmxlZCB7XG4gIGN1cnNvcjogbm90LWFsbG93ZWQgIWltcG9ydGFudDtcbn1cblxuLnRhYmxlLWNlbGwge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5hY3Rpb24tY29udGFpbmVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbi5wbGFpbi1kb3RzIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgYm9yZGVyOiBub25lO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLmN1c3RvbS1kcm9wZG93biB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogMTAwJTtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgei1pbmRleDogMTAwMDtcbn1cblxuLmRyb3Bkb3duLWl0ZW0ge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDhweCAxNnB4O1xuICBib3JkZXI6IG5vbmU7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi5kcm9wZG93bi1pdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIGkge1xuICB0cmFuc2l0aW9uOiBjb2xvciAwLjJzO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIGk6aG92ZXIge1xuICBjb2xvcjogIzk5OSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yb2xlXSxcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cmVxdWVzdHNQZW5kaW5nXSxcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cmVxdWVzdHNDb21wbGV0ZWRdLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1jb25zdW1wdGlvbnNdIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPXJvbGVdIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yZXF1ZXN0c1BlbmRpbmddIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yZXF1ZXN0c0NvbXBsZXRlZF0gLnAtc29ydGFibGUtY29sdW1uLWljb24sXG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPWNvbnN1bXB0aW9uc10gLnAtc29ydGFibGUtY29sdW1uLWljb24ge1xuICBtYXJnaW4tbGVmdDogNHB4O1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciB7XG4gIG1pbi13aWR0aDogMjQ3cHg7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciBpbnB1dCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDQwcHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTc3LCAxNzUsIDIzMywgMC4xMDE5NjA3ODQzKTtcbiAgYm9yZGVyOiBub25lO1xuICBib3JkZXItcmFkaXVzOiA4cHggMCAwIDhweDtcbiAgcGFkZGluZzogMC41cmVtO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci10cmlnZ2VyIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgYmFja2dyb3VuZDogcmdiYSgxNzcsIDE3NSwgMjMzLCAwLjEwMTk2MDc4NDMpO1xuICBib3JkZXI6IG5vbmU7XG4gIGJvcmRlci1yYWRpdXM6IDAgOHB4IDhweCAwO1xuICBjb2xvcjogIzY2Njtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXItdHJpZ2dlcjplbmFibGVkOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogcmdiYSgxNzcsIDE3NSwgMjMzLCAwLjEwMTk2MDc4NDMpO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci10cmlnZ2VyOmZvY3VzIHtcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXIge1xuICBtaW4td2lkdGg6IDI0N3B4O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci5wLWRhdGVwaWNrZXItaW5saW5lIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDEwMCU7XG4gIGxlZnQ6IDA7XG4gIHotaW5kZXg6IDEwMDA7XG59XG5cbjpob3N0IDo6bmctZGVlcCAudXBkYXRlLWJ1dHRvbiB7XG4gIHdpZHRoOiAzNjQuNDJweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xufVxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uOmRpc2FibGVkIHtcbiAgb3BhY2l0eTogMC42O1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XG59XG5cbi5jbGFzc3Jvb20taW5pdGlhbCB7XG4gIHdpZHRoOiAyNHB4O1xuICBoZWlnaHQ6IDI0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZDogI0U2RThGMztcbiAgY29sb3I6ICNGRkZGRkY7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXNpemU6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5jbGFzc3Jvb20tY291bnQge1xuICB3aWR0aDogMzJweDtcbiAgaGVpZ2h0OiAyM3B4O1xuICBnYXA6IDE2cHg7XG4gIHBhZGRpbmc6IDRweCA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyMTcsIDI1NSwgMjAzLCAwLjQpO1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICMzMzMzMzM7XG59XG5cbjo6bmctZGVlcCAucC10b29sdGlwIC5wLXRvb2x0aXAtdGV4dCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcbiAgY29sb3I6ICMzMzMzMzMgIWltcG9ydGFudDtcbiAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNjtcbiAgYm94LXNoYWRvdzogMCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgZm9udC1zaXplOiAxMXB4O1xufVxuOjpuZy1kZWVwIC5wLXRvb2x0aXAgLnAtdG9vbHRpcC1hcnJvdyB7XG4gIGJvcmRlci10b3AtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcbn1cblxuLmNsYXNzcm9vbS1jb3VudC13cmFwcGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZ2FwOiA4cHg7XG59XG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIgLmVkaXQtaWNvbiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM2RTZFNkU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgb3BhY2l0eTogMC43O1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuMnM7XG59XG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIgLmVkaXQtaWNvbjpob3ZlciB7XG4gIG9wYWNpdHk6IDE7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1tZW51IHtcbiAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xuICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkge1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IHtcbiAgd2lkdGg6IDczcHggIWltcG9ydGFudDtcbiAgbWluLWhlaWdodDogODBweCAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAxNnB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDhweCAhaW1wb3J0YW50O1xuICBib3JkZXI6IDFweCBzb2xpZCAjRTZFNkU2ICFpbXBvcnRhbnQ7XG4gIGJveC1zaGFkb3c6IDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4wNSkgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgKiB7XG4gIGJhY2tncm91bmQ6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IHtcbiAgZ2FwOiAxNnB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IC5wLW1lbnUtbGlzdCAucC1tZW51aXRlbSB7XG4gIG1hcmdpbjogMDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IC5wLW1lbnVpdGVtIC5wLW1lbnVpdGVtLWxpbmsge1xuICBwYWRkaW5nOiAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3QgLnAtbWVudWl0ZW0gLnAtbWVudWl0ZW0tbGluazpob3ZlciAucC1tZW51aXRlbS10ZXh0LFxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3QgLnAtbWVudWl0ZW0gLnAtbWVudWl0ZW0tbGluazpob3ZlciAucC1tZW51aXRlbS1pY29uIHtcbiAgY29sb3I6ICM1OTc4RjcgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IC5wLW1lbnVpdGVtIC5wLW1lbnVpdGVtLWxpbmsgLnAtbWVudWl0ZW0taWNvbiB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XG4gIGNvbG9yOiAjNkM3NTdEICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IC5wLW1lbnUtbGlzdCAucC1tZW51aXRlbSAucC1tZW51aXRlbS1saW5rIC5wLW1lbnVpdGVtLXRleHQge1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjNDk1MDU3ICFpbXBvcnRhbnQ7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLWRpYWxvZyAucC1kaWFsb2ctY29udGVudCB7XG4gIHBhZGRpbmc6IDJyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciB7XG4gIHdpZHRoOiA2NHB4O1xuICBoZWlnaHQ6IDY0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0Q5MkQyMDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciAucGktdHJhc2gge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtbWVzc2FnZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICMzNDQwNTQ7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1tZXNzYWdlIHN0cm9uZyB7XG4gIGNvbG9yOiAjMTAxODI4O1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbiB7XG4gIHdpZHRoOiAxNzdweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtY29uZmlybS1idXR0b246aG92ZXIge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSk7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b24ge1xuICBjb2xvcjogIzZDNzU3RDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBjb2xvcjogIzQ5NTA1Nztcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbiB7XG4gIHdpZHRoOiAxNzcuMjFweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGdhcDogOC43cHg7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246OmJlZm9yZSB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgYm90dG9tOiAwO1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSkgYm9yZGVyLWJveDtcbiAgLXdlYmtpdC1tYXNrOiBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApIHBhZGRpbmctYm94LCBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApO1xuICAtd2Via2l0LW1hc2stY29tcG9zaXRlOiBkZXN0aW5hdGlvbi1vdXQ7XG4gIG1hc2stY29tcG9zaXRlOiBleGNsdWRlO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uIC5wLWJ1dHRvbi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246aG92ZXI6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKSBib3JkZXItYm94O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIC5wLWJ1dHRvbi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cucC1mbHVpZCB7XG4gIGhlaWdodDogYXV0bztcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cucC1mbHVpZCAucC1kaWFsb2ctY29udGVudCB7XG4gIG92ZXJmbG93LXk6IHZpc2libGU7XG4gIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgbWF4LWhlaWdodDogbm9uZSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRpYWxvZyAucC1mbHVpZCAuZ3JpZCB7XG4gIHJvdy1nYXA6IDEuNXJlbTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5wLWRyb3Bkb3duIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kcm9wZG93biAucC1kcm9wZG93bi1sYWJlbCB7XG4gIHBhZGRpbmctdG9wOiAwO1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgbGluZS1oZWlnaHQ6IDMxcHg7XG59XG46aG9zdCA6Om5nLWRlZXAgLnAtZHJvcGRvd24gLnAtZHJvcGRvd24tdHJpZ2dlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBoZWlnaHQ6IDEwMCU7XG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 75122:
/*!***************************************************************************************************************************!*\
  !*** ./src/app/modules/app/inventory/vendor/category/vendor-category-count-card/vendor-category-count-cards.component.ts ***!
  \***************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorCategoryCountCardComponent: () => (/* binding */ VendorCategoryCountCardComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/inventory/vendor/vendor.service */ 71286);
/* harmony import */ var _vendor_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../vendor.service */ 47303);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 27947);





class VendorCategoryCountCardComponent {
  constructor(_vendorSharedService, _vendorService, router) {
    this._vendorSharedService = _vendorSharedService;
    this._vendorService = _vendorService;
    this.router = router;
    this.totalVendors = 0;
    this.activeVendors = 0;
    this.inactiveVendors = 0;
    this.totalCategories = 0;
    this.isRefreshCount = false;
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
  }
  ngOnInit() {
    this.getCountCard();
    // Subscribe to vendor updates
    this._vendorSharedService.vendors$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.takeUntil)(this._unsubscribeAll)).subscribe(() => {
      this.getCountCard();
    });
  }
  ngOnChanges() {
    if (this.isRefreshCount) {
      this.getCountCard();
    }
  }
  goToVendorList() {
    this.router.navigate(['/vendors/vendor-list']);
  }
  ngOnDestroy() {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
  getCountCard() {
    this._vendorService.getVendorCategoryCounts().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.takeUntil)(this._unsubscribeAll)).subscribe({
      next: response => {
        if (response.success && response.data) {
          this.totalVendors = response.data.totalVendors;
          this.totalCategories = response.data.totalCategories;
        }
      },
      error: error => {
        console.error('Error fetching vendor category counts:', error);
        this.totalVendors = 0;
        this.totalCategories = 0;
      }
    });
  }
  static #_ = this.ɵfac = function VendorCategoryCountCardComponent_Factory(t) {
    return new (t || VendorCategoryCountCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_0__.VendorSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_vendor_service__WEBPACK_IMPORTED_MODULE_1__.VendorService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: VendorCategoryCountCardComponent,
    selectors: [["app-vendor-category-count-card"]],
    inputs: {
      isRefreshCount: "isRefreshCount"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵNgOnChangesFeature"]],
    decls: 16,
    vars: 2,
    consts: [[1, "grid", "nested-grid", "pl-0"], [1, "col-12", "xl:col-8", "lg:col-8", "md:col-12", "sm:col-12", "w-full"], [1, "flex", "flex-wrap", "w-full", "gap-2", "justify-content-between", "align-items-center"], [1, "flex", "flex-wrap", "gap-2"], [1, "count-card"], [1, "count-card-content"], [1, "count-label"], [1, "count-value"], [1, "count-card", 2, "cursor", "pointer", 3, "click"]],
    template: function VendorCategoryCountCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Total Categories");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCategoryCountCardComponent_Template_div_click_10_listener() {
          return ctx.goToVendorList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 5)(12, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Total Vendors");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.totalCategories);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.totalVendors);
      }
    },
    styles: ["[_nghost-%COMP%]     .count-card {\n  width: 208px;\n  height: 77px;\n}\n[_nghost-%COMP%]     .count-card .count-card-content {\n  height: 100%;\n  background: var(--White-colour, #ffffff);\n  border: 1px solid rgba(22, 40, 49, 0.1);\n  border-radius: 12px;\n  padding: 1rem;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n[_nghost-%COMP%]     .count-card .count-label {\n  font-size: 13px;\n  font-weight: 600;\n  color: rgba(65, 65, 78, 0.8);\n  max-width: 100px;\n}\n[_nghost-%COMP%]     .count-card .count-value {\n  font-size: 18px;\n  font-weight: 600;\n  color: #41414E;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvaW52ZW50b3J5L3ZlbmRvci9jYXRlZ29yeS92ZW5kb3ItY2F0ZWdvcnktY291bnQtY2FyZC92ZW5kb3ItY2F0ZWdvcnktY291bnQtY2FyZHMuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi9OZXclMjBmb2xkZXIvdmdzY2hvb2wtdGhlbWUvc3JjL2FwcC9tb2R1bGVzL2FwcC9pbnZlbnRvcnkvdmVuZG9yL2NhdGVnb3J5L3ZlbmRvci1jYXRlZ29yeS1jb3VudC1jYXJkL3ZlbmRvci1jYXRlZ29yeS1jb3VudC1jYXJkcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLFlBQUE7RUFDQSxZQUFBO0FDQVI7QURFUTtFQUNJLFlBQUE7RUFDQSx3Q0FBQTtFQUNBLHVDQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUNBWjtBREdRO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtBQ0RaO0FESVE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0NBQUE7QUNGWiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAuY291bnQtY2FyZCB7XHJcbiAgICAgICAgd2lkdGg6IDIwOHB4O1xyXG4gICAgICAgIGhlaWdodDogNzdweDtcclxuXHJcbiAgICAgICAgLmNvdW50LWNhcmQtY29udGVudCB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tV2hpdGUtY29sb3VyLCAjZmZmZmZmKTtcclxuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMiwgNDAsIDQ5LCAwLjEpO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxcmVtO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY291bnQtbGFiZWwge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiByZ2JhKDY1LCA2NSwgNzgsIDAuOCk7XHJcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY291bnQtdmFsdWUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNDE0MTRFO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XHJcbiAgICAgICAgICAgIC13ZWJraXQtYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIC13ZWJraXQtdGV4dC1maWxsLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIiwiOmhvc3QgOjpuZy1kZWVwIC5jb3VudC1jYXJkIHtcbiAgd2lkdGg6IDIwOHB4O1xuICBoZWlnaHQ6IDc3cHg7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNvdW50LWNhcmQgLmNvdW50LWNhcmQtY29udGVudCB7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZDogdmFyKC0tV2hpdGUtY29sb3VyLCAjZmZmZmZmKTtcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMiwgNDAsIDQ5LCAwLjEpO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBwYWRkaW5nOiAxcmVtO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG46aG9zdCA6Om5nLWRlZXAgLmNvdW50LWNhcmQgLmNvdW50LWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogcmdiYSg2NSwgNjUsIDc4LCAwLjgpO1xuICBtYXgtd2lkdGg6IDEwMHB4O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jb3VudC1jYXJkIC5jb3VudC12YWx1ZSB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICM0MTQxNEU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 87865:
/*!*********************************************************************!*\
  !*** ./src/app/modules/app/inventory/vendor/list/list.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorComponent: () => (/* binding */ VendorComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 98026);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var src_app_core_inventory_vendor_vendor_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/inventory/vendor/vendor.types */ 75062);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/inventory/vendor/vendor.service */ 71286);
/* harmony import */ var _vendor_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../vendor.service */ 47303);
/* harmony import */ var src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/school/school.service */ 62915);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dropdown */ 94553);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var _vendor_count_card_vendor_count_cards_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../vendor-count-card/vendor-count-cards.component */ 96539);





















function VendorComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 24)(1, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "i", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "input", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("input", function VendorComponent_ng_template_14_Template_input_input_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](13);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r6.onGlobalFilter(_r0, $event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function VendorComponent_ng_template_14_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r7);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r8.exportData());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
}
function VendorComponent_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Vendor Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "p-sortIcon", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "th", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5, " Category ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "p-sortIcon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "th", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, " Contact No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "p-sortIcon", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](11, " Email ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](12, "p-sortIcon", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "th", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](14, " Website ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](15, "p-sortIcon", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "th", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](17, "Action");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
}
const _c0 = () => ({
  "min-width": "24px",
  width: "24px",
  height: "24px",
  padding: "0"
});
const _c1 = () => ({
  width: "200px",
  backgroundColor: "#fff",
  borderRadius: "8px",
  border: "1px solid #E6E6E6",
  boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.05)"
});
function VendorComponent_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "td", 41)(12, "button", 42, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function VendorComponent_ng_template_16_Template_button_click_12_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r13);
      const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](15);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](_r11.toggle($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](14, "p-menu", 44, 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const vendor_r9 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](vendor_r9.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r3.getCategoryName(vendor_r9.vendorCategoryCode), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](vendor_r9.mobile);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](vendor_r9.email);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](vendor_r9.websiteLink);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](12, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](13, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("popup", true)("model", ctx_r3.getActionItems(vendor_r9))("appendTo", "body");
  }
}
function VendorComponent_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td", 46)(2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "i", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5, "No vendors available");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "span", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7, "Add new vendors using the 'Add Vendor' button");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
  }
}
function VendorComponent_ng_template_19_small_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Vendor name is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VendorComponent_ng_template_19_small_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Category is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VendorComponent_ng_template_19_small_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Valid mobile number is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VendorComponent_ng_template_19_small_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Website is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VendorComponent_ng_template_19_small_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Valid phone number is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VendorComponent_ng_template_19_small_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Tax ID is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VendorComponent_ng_template_19_small_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Valid email is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VendorComponent_ng_template_19_small_52_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Valid email is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
const _c2 = () => ({
  height: "33px",
  border: "1px solid #57335366",
  borderRadius: "8px"
});
const _c3 = () => ({
  height: "33px",
  borderRadius: "8px",
  border: "1px solid #57335366"
});
const _c4 = () => ({
  width: "177.21px",
  height: "48px",
  gap: "8.7px",
  borderRadius: "6.96px",
  background: "linear-gradient(90deg, #5978F7 0%, #9C84FF 100%)",
  border: "none"
});
function VendorComponent_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "form", 51)(1, "div", 52)(2, "label", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, "Vendor Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "sup");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5, "*");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, VendorComponent_ng_template_19_small_7_Template, 2, 0, "small", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 52)(9, "label", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10, "Category ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "sup");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](12, "*");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](13, "p-dropdown", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, VendorComponent_ng_template_19_small_14_Template, 2, 0, "small", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "div", 52)(16, "label", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](17, "Company");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](18, "input", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](19, "div", 52)(20, "label", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](21, "Contact No. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](22, "input", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](23, VendorComponent_ng_template_19_small_23_Template, 2, 0, "small", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "div", 62)(25, "label", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](26, "Website");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](27, "input", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](28, VendorComponent_ng_template_19_small_28_Template, 2, 0, "small", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "div", 52)(30, "label", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31, "Office Phone");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](32, "input", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](33, VendorComponent_ng_template_19_small_33_Template, 2, 0, "small", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](34, "div", 52)(35, "label", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](36, "Tax ID");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](37, "input", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](38, VendorComponent_ng_template_19_small_38_Template, 2, 0, "small", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](39, "div", 62)(40, "label", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](41, "Company Address");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](42, "input", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](43, "div", 62)(44, "label", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](45, "Email");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](46, "input", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](47, VendorComponent_ng_template_19_small_47_Template, 2, 0, "small", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](48, "div", 62)(49, "label", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](50, "Remark");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](51, "input", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](52, VendorComponent_ng_template_19_small_52_Template, 2, 0, "small", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](53, "div", 74)(54, "button", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function VendorComponent_ng_template_19_Template_button_click_54_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r23);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r22.vendor.code ? ctx_r22.updateVendor() : ctx_r22.saveVendor());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    let tmp_2_0;
    let tmp_5_0;
    let tmp_8_0;
    let tmp_10_0;
    let tmp_12_0;
    let tmp_14_0;
    let tmp_17_0;
    let tmp_19_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx_r5.vendorForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](35, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_2_0 = ctx_r5.vendorForm.get("firstName")) == null ? null : tmp_2_0.touched) && ((tmp_2_0 = ctx_r5.vendorForm.get("firstName")) == null ? null : tmp_2_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](36, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r5.vendorCategories);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_5_0 = ctx_r5.vendorForm.get("vendorCategoryCode")) == null ? null : tmp_5_0.touched) && ((tmp_5_0 = ctx_r5.vendorForm.get("vendorCategoryCode")) == null ? null : tmp_5_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](37, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](38, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_8_0 = ctx_r5.vendorForm.get("mobile")) == null ? null : tmp_8_0.touched) && ((tmp_8_0 = ctx_r5.vendorForm.get("mobile")) == null ? null : tmp_8_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](39, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_10_0 = ctx_r5.vendorForm.get("websiteLink")) == null ? null : tmp_10_0.touched) && ((tmp_10_0 = ctx_r5.vendorForm.get("websiteLink")) == null ? null : tmp_10_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](40, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_12_0 = ctx_r5.vendorForm.get("officePhone")) == null ? null : tmp_12_0.touched) && ((tmp_12_0 = ctx_r5.vendorForm.get("officePhone")) == null ? null : tmp_12_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](41, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_14_0 = ctx_r5.vendorForm.get("taxId")) == null ? null : tmp_14_0.touched) && ((tmp_14_0 = ctx_r5.vendorForm.get("taxId")) == null ? null : tmp_14_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](42, _c3));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](43, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_17_0 = ctx_r5.vendorForm.get("email")) == null ? null : tmp_17_0.touched) && ((tmp_17_0 = ctx_r5.vendorForm.get("email")) == null ? null : tmp_17_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](44, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_19_0 = ctx_r5.vendorForm.get("remark")) == null ? null : tmp_19_0.touched) && ((tmp_19_0 = ctx_r5.vendorForm.get("remark")) == null ? null : tmp_19_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](45, _c4));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("icon", ctx_r5.submitted ? "pi pi-spinner pi-spin" : "")("label", ctx_r5.submitted ? "" : ctx_r5.vendor.code ? "Update" : "Add")("disabled", ctx_r5.vendorForm.invalid || ctx_r5.submitted);
  }
}
const _c5 = () => ["firstName", "lastName", "company", "email", "mobile", "status"];
const _c6 = () => ({
  width: "450px",
  overflow: "visible"
});
const _c7 = () => ({
  overflow: "visible"
});
const _c8 = () => ({
  width: "480px"
});
const _c9 = () => ({
  background: "linear-gradient(90deg, #5978F7 0%, #9C84FF 100%)"
});
class VendorComponent {
  constructor(_vendorService, _vendorNativeService, _schoolService, _messageService, _confirmationService, _formBuilder, _route, _changeDetectorRef) {
    this._vendorService = _vendorService;
    this._vendorNativeService = _vendorNativeService;
    this._schoolService = _schoolService;
    this._messageService = _messageService;
    this._confirmationService = _confirmationService;
    this._formBuilder = _formBuilder;
    this._route = _route;
    this._changeDetectorRef = _changeDetectorRef;
    this.submitted = false;
    // Date Range
    this.dateRange = null;
    // Data
    this.school = {};
    this.vendor = {};
    this.vendors = [];
    this.selectedVendor = null;
    this.vendorCategories = [];
    this.isRefreshCount = false;
    this.selectedCategoryCode = null;
    this.filteredVendors = [];
    // UI States
    this.vendorDialog = false;
    this.editVendorDialog = false;
    this.deleteVendorDialog = false;
    // Table
    this.cols = [];
    this.rowsPerPageOptions = [5, 10, 20];
    this.sortField = '';
    this.sortOrder = 1;
    // Cleanup
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
  }
  ngOnInit() {
    this.initForm();
    this.initTable();
    this.subscribeToSchool();
    this._route.queryParams.subscribe(params => {
      this.selectedCategoryCode = params['category'] || null;
      this.applyCategoryFilter();
    });
  }
  ngOnDestroy() {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
  // Private Methods
  initForm() {
    this.vendorForm = this._formBuilder.group({
      firstName: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.maxLength(100)]],
      lastName: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.maxLength(100)]],
      mobile: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.pattern(/^[0-9]{10}$/)]],
      email: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.email]],
      company: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.maxLength(100)]],
      officePhone: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.pattern(/^[0-9]{10}$/)]],
      address: [null],
      remark: [null],
      websiteLink: [null],
      taxId: [null],
      vendorCategoryCode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      isFavorite: [false]
    });
  }
  initTable() {
    this.cols = [{
      field: 'name',
      header: 'Vendor Name'
    }, {
      field: 'category',
      header: 'Category'
    }, {
      field: 'mobile',
      header: 'Contact no'
    }, {
      field: 'email',
      header: 'Email'
    }, {
      field: 'websiteLink',
      header: 'Website'
    }];
  }
  subscribeToSchool() {
    // Subscribe to school updates
    this._schoolService.school$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this._unsubscribeAll)).subscribe(school => {
      if (school?.code) {
        this.school = school;
        this._vendorService.getVendorsBySchool(school.code).subscribe();
        this._vendorService.getCategoriesBySchool(school.code).subscribe();
      }
      this._changeDetectorRef.markForCheck();
    });
    // Subscribe to vendors
    this._vendorService.vendors$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this._unsubscribeAll)).subscribe(vendors => {
      if (vendors) {
        this.vendors = vendors;
        this.applyCategoryFilter();
      }
      this._changeDetectorRef.markForCheck();
    });
    // Subscribe to vendor categories
    this._vendorService.categories$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this._unsubscribeAll)).subscribe(categories => {
      if (categories) {
        this.vendorCategories = categories;
      }
      this._changeDetectorRef.markForCheck();
    });
  }
  // Public Methods
  getCategoryName(code) {
    const category = this.vendorCategories.find(cat => cat.code === code);
    return category ? category.name : 'Unknown Category';
  }
  createNewVendor() {
    this.vendor = {};
    this.submitted = false;
    this.vendorDialog = true;
  }
  applyCategoryFilter() {
    if (this.selectedCategoryCode) {
      this.filteredVendors = this.vendors.filter(v => v.vendorCategoryCode === this.selectedCategoryCode);
    } else {
      this.filteredVendors = this.vendors;
    }
  }
  saveVendor() {
    if (this.vendorForm.valid) {
      this.submitted = true;
      const vendorData = {
        ...this.vendorForm.getRawValue(),
        schoolCode: this.school.code,
        status: src_app_core_inventory_vendor_vendor_types__WEBPACK_IMPORTED_MODULE_0__.VendorStatus.ACTIVE
      };
      this._vendorService.createVendor(vendorData).subscribe({
        next: response => {
          if (response.success) {
            this.isRefreshCount = true;
            setTimeout(() => this.isRefreshCount = false, 0);
            this.submitted = false;
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Vendor created successfully'
            });
            this.hideDialog();
          }
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to create vendor'
          });
        }
      });
    }
  }
  editVendor(vendor) {
    this.vendor = {
      ...vendor
    };
    this.vendorForm.patchValue(vendor);
    this.vendorDialog = true;
  }
  updateVendor() {
    if (this.vendorForm.valid && this.vendor.code) {
      this.submitted = true;
      const updatedVendor = {
        ...this.vendorForm.getRawValue(),
        code: this.vendor.code,
        schoolCode: this.school.code,
        status: this.vendor.status
      };
      this._vendorService.updateVendor(updatedVendor).subscribe({
        next: response => {
          if (response.success) {
            this.submitted = false;
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Vendor updated successfully'
            });
            this.hideDialog();
          }
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to update vendor'
          });
        }
      });
    }
  }
  deleteVendor(vendor) {
    this.vendor = vendor;
    this.deleteVendorDialog = true;
  }
  confirmDelete() {
    if (this.vendor?.code) {
      this.submitted = true;
      this._vendorService.deleteVendor(this.vendor.code).subscribe({
        next: response => {
          if (response.success) {
            this.deleteVendorDialog = false;
            this.isRefreshCount = true;
            this.submitted = false;
            setTimeout(() => this.isRefreshCount = false, 0);
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Vendor deleted successfully'
            });
          }
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to delete vendor'
          });
        }
      });
    }
  }
  exportData() {
    if (!this.school.code) {
      return;
    }
    this._vendorNativeService.exportVendors(this.school.code).subscribe(blob => {
      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl;
      a.download = 'vendors.xlsx'; // or .csv, etc.
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }
  getActionItems(vendor) {
    return [{
      label: 'Edit',
      command: () => this.editVendor(vendor)
    }, {
      label: 'Delete',
      command: () => this.deleteVendor(vendor)
    }];
  }
  hideDialog() {
    this.vendorDialog = false;
    this.editVendorDialog = false;
    this.submitted = false;
    this.vendorForm.reset();
  }
  onGlobalFilter(table, event) {
    table.filterGlobal(event.target.value, 'contains');
  }
  clearFilters(table) {
    table.clear();
    this.dateRange = null;
  }
  onSort(event) {
    this.sortField = event.field;
    this.sortOrder = event.order;
  }
  static #_ = this.ɵfac = function VendorComponent_Factory(t) {
    return new (t || VendorComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_1__.VendorSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_vendor_service__WEBPACK_IMPORTED_MODULE_2__.VendorService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_3__.SchoolSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: VendorComponent,
    selectors: [["ng-component"]],
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵProvidersFeature"]([primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService, primeng_api__WEBPACK_IMPORTED_MODULE_9__.ConfirmationService])],
    decls: 32,
    vars: 33,
    consts: [[1, "grid"], [1, "col-12"], [1, "flex", "align-items-center", "justify-content-start", "mb-3"], [1, "text-xl", "font-medium", "text-color-secondary", 2, "color", "#573353 !important", "line-height", "14px", "font-size", "16px !important"], [1, "flex", "justify-content-between", "align-items-center", "flex-wrap", "w-full"], ["pButton", "", 1, "flex", "align-items-center", "gap-2", "border-none", 2, "width", "136px", "height", "40px", "border-radius", "12px", "padding-left", "8px", "padding-right", "16px", "background", "linear-gradient(\n                        90deg,\n                        #5978f7 0%,\n                        #9c84ff 100%\n                    )", "color", "white", "font-weight", "500", 3, "click"], [1, "pi", "pi-plus", 2, "margin-right", "6px"], [1, "card", "px-3"], ["responsiveLayout", "scroll", "currentPageReportTemplate", "Showing {first} to {last} of {totalRecords} entries", "selectionMode", "single", "dataKey", "code", 3, "value", "columns", "rows", "globalFilterFields", "paginator", "rowsPerPageOptions", "showCurrentPageReport", "selection", "rowHover", "sortField", "sortOrder", "selectionChange", "onSort"], ["dt", ""], ["pTemplate", "caption"], ["pTemplate", "header"], ["pTemplate", "body"], ["pTemplate", "emptymessage"], [1, "p-fluid", "vendor-dialog", 3, "visible", "contentStyle", "header", "modal", "visibleChange"], ["pTemplate", "content"], ["header", "Delete Vendor", "styleClass", "delete-dialog", 3, "visible", "modal", "showHeader", "visibleChange"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", "gap-3"], [1, "delete-icon-container"], [1, "pi", "pi-trash"], [1, "delete-message", "text-center"], [1, "flex", "align-items-center", "gap-2", "mt-4"], ["pButton", "", "pRipple", "", "label", "Cancel", 1, "p-button-outlined", "cancel-button", 3, "click"], ["pButton", "", "pRipple", "", 1, "delete-confirm-button", 3, "icon", "label", "click"], [1, "flex", "flex-column", "md:flex-row", "md:align-items-center", "gap-5"], [1, "block", "mt-2", "md:mt-0", "p-input-icon-left"], [1, "pi", "pi-search"], ["pInputText", "", "type", "text", "placeholder", "Search...", 1, "w-full", "sm:w-auto", 3, "input"], [1, "flex-1"], ["pButton", "", "type", "button", "label", "Export Data", "icon", "pi pi-download", 1, "p-button-sm", 2, "min-width", "140px", "color", "#573353 !important", "background-color", "#FFF", 3, "click"], ["pSortableColumn", "name", 2, "min-width", "200px"], ["field", "name"], ["pSortableColumn", "category", 2, "min-width", "150px"], ["field", "category"], ["pSortableColumn", "mobile", 2, "min-width", "150px"], ["field", "mobile"], ["pSortableColumn", "email", 2, "min-width", "200px"], ["field", "email"], ["pSortableColumn", "websiteLink", 2, "min-width", "200px"], ["field", "websiteLink"], [2, "width", "10%"], [1, "table-cell"], ["type", "button", "pButton", "", "icon", "pi pi-ellipsis-v", 1, "p-button-text", "p-button-plain", "action-button", 3, "click"], ["menuButton", ""], ["styleClass", "custom-action-menu", 3, "popup", "model", "appendTo"], ["menu", ""], ["colspan", "6"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", 2, "padding", "2rem"], [1, "pi", "pi-users", 2, "font-size", "3rem", "color", "#ccc", "margin-bottom", "1rem"], [2, "font-size", "1.2rem", "color", "#666"], [2, "color", "#888", "margin-top", "0.5rem"], [1, "p-fluid", "p-formgrid", "grid", 3, "formGroup"], [1, "col-12", "md:col-6", "pb-0"], ["for", "firstName"], ["pInputText", "", "id", "firstName", "formControlName", "firstName"], ["class", "p-error", 4, "ngIf"], ["for", "vendorCategoryCode"], ["id", "vendorCategoryCode", "formControlName", "vendorCategoryCode", "optionLabel", "name", "optionValue", "code", "placeholder", "Select Category", 3, "options"], ["for", "company"], ["pInputText", "", "id", "company", "formControlName", "company"], ["for", "mobile"], ["pInputText", "", "id", "mobile", "formControlName", "mobile"], [1, "col-12", "pb-0"], ["for", "websiteLink"], ["pInputText", "", "id", "websiteLink", "formControlName", "websiteLink"], ["for", "officePhone"], ["pInputText", "", "id", "officePhone", "formControlName", "officePhone"], ["for", "taxId"], ["pInputText", "", "id", "taxId", "formControlName", "taxId"], ["for", "address"], ["pInputText", "", "id", "address", "formControlName", "address"], ["for", "email"], ["pInputText", "", "id", "email", "formControlName", "email"], ["pInputText", "", "id", "remark", "formControlName", "remark"], [1, "col-12", "flex", "justify-content-center", "gap-2"], ["pButton", "", "type", "submit", 1, "submit-button", 3, "icon", "label", "disabled", "click"], [1, "p-error"]],
    template: function VendorComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4, "Vendors");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "app-vendor-count-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function VendorComponent_Template_button_click_7_listener() {
          return ctx.createNewVendor();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](8, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9, " Add Vendor ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](11, "p-toast");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "p-table", 8, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("selectionChange", function VendorComponent_Template_p_table_selectionChange_12_listener($event) {
          return ctx.selectedVendor = $event;
        })("onSort", function VendorComponent_Template_p_table_onSort_12_listener($event) {
          return ctx.onSort($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, VendorComponent_ng_template_14_Template, 6, 0, "ng-template", 10)(15, VendorComponent_ng_template_15_Template, 18, 0, "ng-template", 11)(16, VendorComponent_ng_template_16_Template, 16, 14, "ng-template", 12)(17, VendorComponent_ng_template_17_Template, 8, 0, "ng-template", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "p-dialog", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function VendorComponent_Template_p_dialog_visibleChange_18_listener($event) {
          return ctx.vendorDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, VendorComponent_ng_template_19_Template, 55, 46, "ng-template", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](20, "p-dialog", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function VendorComponent_Template_p_dialog_visibleChange_20_listener($event) {
          return ctx.deleteVendorDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "div", 17)(22, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](23, "i", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "div", 20)(25, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](26, "Do you want to delete this vendor -");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "div", 21)(30, "button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function VendorComponent_Template_button_click_30_listener() {
          return ctx.deleteVendorDialog = false;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function VendorComponent_Template_button_click_31_listener() {
          return ctx.confirmDelete();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", ctx.filteredVendors)("columns", ctx.cols)("rows", 10)("globalFilterFields", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](28, _c5))("paginator", true)("rowsPerPageOptions", ctx.rowsPerPageOptions)("showCurrentPageReport", true)("selection", ctx.selectedVendor)("rowHover", true)("sortField", ctx.sortField)("sortOrder", ctx.sortOrder);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](29, _c6));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.vendorDialog)("contentStyle", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](30, _c7))("header", ctx.vendor.code ? "Edit Vendor" : "Add Vendor")("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](31, _c8));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.deleteVendorDialog)("modal", true)("showHeader", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate2"]("\"", ctx.vendor == null ? null : ctx.vendor.firstName, " ", ctx.vendor == null ? null : ctx.vendor.lastName, "\"?");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](32, _c9));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("icon", ctx.submitted ? "pi pi-spinner pi-spin" : "")("label", ctx.submitted ? "" : "Delete");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName, primeng_table__WEBPACK_IMPORTED_MODULE_12__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_9__.PrimeTemplate, primeng_table__WEBPACK_IMPORTED_MODULE_12__.SortableColumn, primeng_table__WEBPACK_IMPORTED_MODULE_12__.SortIcon, primeng_button__WEBPACK_IMPORTED_MODULE_13__.ButtonDirective, primeng_menu__WEBPACK_IMPORTED_MODULE_14__.Menu, primeng_ripple__WEBPACK_IMPORTED_MODULE_15__.Ripple, primeng_toast__WEBPACK_IMPORTED_MODULE_16__.Toast, primeng_inputtext__WEBPACK_IMPORTED_MODULE_17__.InputText, primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__.Dropdown, primeng_dialog__WEBPACK_IMPORTED_MODULE_19__.Dialog, _vendor_count_card_vendor_count_cards_component__WEBPACK_IMPORTED_MODULE_4__.VendorCountCardComponent],
    styles: ["\n\n.flex[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  \n\n}\n\n\n\n.search-input[_ngcontent-%COMP%] {\n  width: 246px;\n  \n\n  height: 40px;\n  \n\n  padding-left: 10px;\n  \n\n  border-radius: 4px;\n  \n\n}\n\n\n\n.clear-button[_ngcontent-%COMP%] {\n  width: 63px;\n  height: 23px;\n  gap: 6px;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 3px;\n  padding-top: 4px;\n  padding-right: 8px;\n  padding-bottom: 4px;\n  padding-left: 8px;\n}\n.clear-button[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n\n\n\n.clear-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  margin-right: 4px;\n  \n\n}\n\n  .add-button {\n  width: 11.5rem;\n  height: 3rem;\n  font-weight: 600;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 6px;\n  padding: 0.5rem 1rem;\n  transition: background 0.3s ease;\n  margin-bottom: 1rem;\n}\n  .add-button:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n  .add-button:disabled {\n  cursor: not-allowed !important;\n}\n\n.table-cell[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.action-container[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.plain-dots[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  cursor: pointer;\n  padding: 5px;\n}\n\n.custom-dropdown[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 100%;\n  background: white;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  border-radius: 4px;\n  z-index: 1000;\n}\n\n.dropdown-item[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  padding: 8px 16px;\n  border: none;\n  background: none;\n  text-align: left;\n  cursor: pointer;\n}\n.dropdown-item[_ngcontent-%COMP%]:hover {\n  background-color: #f5f5f5;\n}\n\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td {\n  background: #fff;\n  text-align: center;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i {\n  transition: color 0.2s;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i:hover {\n  color: #999 !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=role], [_nghost-%COMP%]     th[pSortableColumn=requestsPending], [_nghost-%COMP%]     th[pSortableColumn=requestsCompleted], [_nghost-%COMP%]     th[pSortableColumn=consumptions] {\n  text-align: center !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=role] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=requestsPending] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=requestsCompleted] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=consumptions] .p-sortable-column-icon {\n  margin-left: 4px;\n}\n\n[_nghost-%COMP%]     .custom-calendar .p-calendar {\n  min-width: 247px;\n  display: inline-flex;\n  position: relative;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar input {\n  width: 100%;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 8px 0 0 8px;\n  padding: 0.5rem;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger {\n  width: 40px;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 0 8px 8px 0;\n  color: #666;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:enabled:hover {\n  background: rgba(177, 175, 233, 0.1019607843);\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker {\n  min-width: 247px;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker.p-datepicker-inline {\n  position: absolute;\n  top: 100%;\n  left: 0;\n  z-index: 1000;\n}\n\n[_nghost-%COMP%]     .update-button {\n  width: 364.42px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .update-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .update-button:disabled {\n  opacity: 0.6;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  cursor: not-allowed;\n}\n\n.classroom-initial[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  background: #E6E8F3;\n  color: #FFFFFF;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.classroom-count[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 23px;\n  gap: 16px;\n  padding: 4px 8px;\n  border-radius: 3px;\n  background-color: rgba(217, 255, 203, 0.4);\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  color: #333333;\n}\n\n  .p-tooltip .p-tooltip-text {\n  background-color: #F0FFEA !important;\n  color: #333333 !important;\n  border: 1px solid #E6E6E6;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  font-size: 11px;\n}\n  .p-tooltip .p-tooltip-arrow {\n  border-top-color: #F0FFEA !important;\n}\n\n.classroom-count-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #6E6E6E;\n  cursor: pointer;\n  opacity: 0.7;\n  transition: opacity 0.2s;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%]:hover {\n  opacity: 1;\n}\n\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay, [_nghost-%COMP%]     .custom-action-menu .p-menu, [_nghost-%COMP%]     .p-menu.custom-action-menu, [_nghost-%COMP%]     .p-menu.custom-action-menu .p-menu, [_nghost-%COMP%]     .p-menu-overlay.custom-action-menu, [_nghost-%COMP%]     .p-menu-overlay.custom-action-menu .p-menu {\n  background: #fff !important;\n  border-radius: 8px !important;\n  border: 1px solid #E6E6E6 !important;\n  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.05) !important;\n}\n[_nghost-%COMP%]     .custom-action-menu .p-menuitem-link, [_nghost-%COMP%]     .custom-action-menu .p-menuitem {\n  background: #fff !important;\n}\n\n[_nghost-%COMP%]     .delete-dialog .p-dialog-content {\n  padding: 2rem;\n}\n[_nghost-%COMP%]     .delete-icon-container {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background-color: #D92D20;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 1rem;\n}\n[_nghost-%COMP%]     .delete-icon-container .pi-trash {\n  font-size: 24px;\n  color: #FFFFFF;\n}\n[_nghost-%COMP%]     .delete-message {\n  font-size: 14px;\n  color: #344054;\n  line-height: 1.5;\n}\n[_nghost-%COMP%]     .delete-message strong {\n  color: #101828;\n}\n\n[_nghost-%COMP%]     .delete-confirm-button {\n  width: 177px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .delete-confirm-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .delete-confirm-button:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .cancel-button {\n  color: #6C757D;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n  color: #495057;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .cancel-button {\n  width: 177.21px;\n  height: 48px;\n  border-radius: 6.96px;\n  gap: 8.7px;\n  background: transparent;\n  position: relative;\n}\n[_nghost-%COMP%]     .cancel-button::before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  border-radius: 6.96px;\n  border: 1px solid transparent;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%) border-box;\n  -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);\n  -webkit-mask-composite: destination-out;\n  mask-composite: exclude;\n}\n[_nghost-%COMP%]     .cancel-button .p-button-label {\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n}\n[_nghost-%COMP%]     .cancel-button:hover::before {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%) border-box;\n}\n[_nghost-%COMP%]     .cancel-button:hover .p-button-label {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .p-dialog.p-fluid {\n  height: auto;\n}\n[_nghost-%COMP%]     .p-dialog.p-fluid .p-dialog-content {\n  overflow-y: visible;\n  overflow-x: hidden;\n  max-height: none !important;\n}\n[_nghost-%COMP%]     .p-dialog .p-fluid .grid {\n  row-gap: 1.5rem;\n}\n\n[_nghost-%COMP%]     .p-dropdown {\n  display: flex;\n  align-items: center;\n}\n[_nghost-%COMP%]     .p-dropdown .p-dropdown-label {\n  padding-top: 0;\n  padding-bottom: 0;\n  line-height: 31px;\n}\n[_nghost-%COMP%]     .p-dropdown .p-dropdown-trigger {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n}\n\n[_nghost-%COMP%]     label sup {\n  color: red;\n  font-size: 1em;\n  margin-left: 0.5px;\n  margin-top: -0.5px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvaW52ZW50b3J5L3ZlbmRvci9saXN0L2xpc3QuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi9OZXclMjBmb2xkZXIvdmdzY2hvb2wtdGhlbWUvc3JjL2FwcC9tb2R1bGVzL2FwcC9pbnZlbnRvcnkvdmVuZG9yL2xpc3QvbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxtREFBQTtBQUNBO0VBQ0ksYUFBQTtFQUNBLFNBQUE7RUFDQSxrQ0FBQTtBQ0NKOztBREVBLHdCQUFBO0FBQ0E7RUFDSSxZQUFBO0VBQ0Esa0NBQUE7RUFDQSxZQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLDhDQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQ0FBQTtBQ0NKOztBRElBLCtCQUFBO0FBQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVEQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQ0RKO0FER0k7RUFDSSx1REFBQTtBQ0RSOztBREtBLDBDQUFBO0FBQ0E7RUFDSSxpQkFBQTtFQUNBLHVEQUFBO0FDRko7O0FET0k7RUFDSSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSx1REFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQ0FBQTtFQUNBLG1CQUFBO0FDSlI7QURNUTtFQUNJLHVEQUFBO0FDSlo7QURPUTtFQUVJLDhCQUFBO0FDTlo7O0FEWUE7RUFDSSxrQkFBQTtBQ1RKOztBRFlBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtBQ1RKOztBRFlBO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUNUSjs7QURZQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLHdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FDVEo7O0FEWUE7RUFDSSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDVEo7QURXSTtFQUNJLHlCQUFBO0FDVFI7O0FEZ0JZO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtBQ2JoQjtBRGVnQjtFQUNJLHNCQUFBO0FDYnBCO0FEZW9CO0VBQ0ksc0JBQUE7QUNieEI7QUR1Qkk7Ozs7RUFJSSw2QkFBQTtBQ3JCUjtBRHVCUTs7OztFQUNJLGdCQUFBO0FDbEJaOztBRDRCUTtFQUNJLGdCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQ3pCWjtBRDJCWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkNBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0FDekJoQjtBRDRCWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkNBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxXQUFBO0FDMUJoQjtBRDRCZ0I7RUFDSSw2Q0FBQTtBQzFCcEI7QUQ2QmdCO0VBQ0ksZ0JBQUE7QUMzQnBCO0FEZ0NRO0VBQ0ksZ0JBQUE7QUM5Qlo7QURnQ1k7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0VBQ0EsYUFBQTtBQzlCaEI7O0FEcUNJO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLDREQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDbENSO0FEb0NRO0VBQ0ksNERBQUE7QUNsQ1o7QURxQ1E7RUFDSSxZQUFBO0VBQ0EsNERBQUE7RUFDQSxtQkFBQTtBQ25DWjs7QUR3Q0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNyQ0o7O0FEd0NBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0VBQ0Esb0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUNyQ0o7O0FEeUNJO0VBQ0ksb0NBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0NBQUE7RUFDQSxlQUFBO0FDdENSO0FEeUNJO0VBQ0ksb0NBQUE7QUN2Q1I7O0FEMkNBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsUUFBQTtBQ3hDSjtBRDBDSTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSx3QkFBQTtBQ3hDUjtBRDBDUTtFQUNJLFVBQUE7QUN4Q1o7O0FEK0NJOzs7Ozs7RUFNSSwyQkFBQTtFQUNBLDZCQUFBO0VBQ0Esb0NBQUE7RUFDQSxzREFBQTtBQzVDUjtBRCtDSTs7RUFFSSwyQkFBQTtBQzdDUjs7QURtRFE7RUFDSSxhQUFBO0FDaERaO0FEb0RJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ2xEUjtBRG9EUTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FDbERaO0FEc0RJO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ3BEUjtBRHNEUTtFQUNJLGNBQUE7QUNwRFo7O0FEMERJO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLDREQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDdkRSO0FEeURRO0VBQ0ksNERBQUE7QUN2RFo7QUQwRFE7RUFDSSxnQkFBQTtBQ3hEWjtBRDRESTtFQUNJLGNBQUE7QUMxRFI7QUQ0RFE7RUFDSSx1QkFBQTtFQUNBLGNBQUE7QUMxRFo7QUQ2RFE7RUFDSSxnQkFBQTtBQzNEWjs7QURpRUk7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUM5RFI7QURpRVE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EscUJBQUE7RUFDQSw2QkFBQTtFQUNBLHVFQUFBO0VBQ0EsOEVBQ0k7RUFFSix1Q0FBQTtFQUNBLHVCQUFBO0FDakVaO0FEcUVRO0VBQ0ksNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0NBQUE7RUFDQSxnQkFBQTtBQ25FWjtBRHNFUTtFQUNJLHVCQUFBO0FDcEVaO0FEc0VZO0VBQ0ksdUVBQUE7QUNwRWhCO0FEdUVZO0VBQ0ksNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0FDckVoQjtBRHlFUTtFQUNJLGdCQUFBO0FDdkVaOztBRGdGUTtFQUNJLFlBQUE7QUM3RVo7QUQrRVk7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7QUM3RWhCO0FEd0ZZO0VBQ0ksZUFBQTtBQ3RGaEI7O0FEOEZJO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0FDM0ZSO0FENkZRO0VBQ0ksY0FBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUMzRlo7QUQ4RlE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7QUM1Rlo7O0FEaUdBO0VBQ0ksVUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDOUZKIiwic291cmNlc0NvbnRlbnQiOlsiLyogR2VuZXJhbCBGbGV4IExheW91dDogMTJweCBnYXAgYmV0d2VlbiBjb250cm9scyAqL1xyXG4uZmxleCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZ2FwOiAxMnB4O1xyXG4gICAgLyogMTJweCBnYXAgYmV0d2VlbiBlYWNoIGNvbnRyb2wgKi9cclxufVxyXG5cclxuLyogU2VhcmNoIElucHV0IHN0eWxlcyAqL1xyXG4uc2VhcmNoLWlucHV0IHtcclxuICAgIHdpZHRoOiAyNDZweDtcclxuICAgIC8qIE1hdGNoaW5nIHRoZSB3aWR0aCBmcm9tIEZpZ21hICovXHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAvKiBNYXRjaGluZyB0aGUgaGVpZ2h0IGZyb20gRmlnbWEgKi9cclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgIC8qIE9wdGlvbmFsOiBTcGFjZSBiZXR3ZWVuIHRoZSBpY29uIGFuZCB0ZXh0ICovXHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAvKiBSb3VuZGVkIGNvcm5lcnMgZm9yIHRoZSBpbnB1dCAqL1xyXG59XHJcblxyXG5cclxuXHJcbi8qIENsZWFyIEJ1dHRvbiBjdXN0b20gc3R5bGVzICovXHJcbi5jbGVhci1idXR0b24ge1xyXG4gICAgd2lkdGg6IDYzcHg7XHJcbiAgICBoZWlnaHQ6IDIzcHg7XHJcbiAgICBnYXA6IDZweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNTk3OEY3LCAjOUM4NEZGKTsgLy8gSW5kaWdvIDUwMCB0byA2MDBcclxuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcclxuICAgIHBhZGRpbmctdG9wOiA0cHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA4cHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiA4cHg7XHJcblxyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNEI2OEUxLCAjOEI2RUZGKTsgLy8gRGFya2VyIG9uIGhvdmVyXHJcbiAgICB9XHJcbn1cclxuXHJcbi8qIE9wdGlvbmFsOiBTdHlsZSBmb3IgdGhlIGJ1dHRvbidzIGljb24gKi9cclxuLmNsZWFyLWJ1dHRvbiBpIHtcclxuICAgIG1hcmdpbi1yaWdodDogNHB4O1xyXG4gICAgLyogQWRqdXN0IGlmIHlvdSB3YW50IHNwYWNlIGJldHdlZW4gdGhlIGljb24gYW5kIHRleHQgKi9cclxufVxyXG5cclxuXHJcbjo6bmctZGVlcCB7XHJcbiAgICAuYWRkLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDExLjVyZW07XHJcbiAgICAgICAgaGVpZ2h0OiAzcmVtO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzU5NzhGNywgIzlDODRGRik7IC8vIEluZGlnbyA1MDAgdG8gNjAwXHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDAuNXJlbSAxcmVtO1xyXG4gICAgICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4zcyBlYXNlO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDFyZW07XHJcblxyXG4gICAgICAgICY6aG92ZXIge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0QjY4RTEsICM4QjZFRkYpOyAvLyBEYXJrZXIgb24gaG92ZXJcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6ZGlzYWJsZWQge1xyXG4gICAgICAgICAgICAvLyBvcGFjaXR5OiAwLjYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgY3Vyc29yOiBub3QtYWxsb3dlZCAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcbi50YWJsZS1jZWxsIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLmFjdGlvbi1jb250YWluZXIge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4ucGxhaW4tZG90cyB7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG59XHJcblxyXG4uY3VzdG9tLWRyb3Bkb3duIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAwO1xyXG4gICAgdG9wOiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAwIDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgei1pbmRleDogMTAwMDtcclxufVxyXG5cclxuLmRyb3Bkb3duLWl0ZW0ge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmc6IDhweCAxNnB4O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcblxyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5wLWRhdGF0YWJsZSB7XHJcbiAgICAgICAgLnAtZGF0YXRhYmxlLWVtcHR5bWVzc2FnZSB7XHJcbiAgICAgICAgICAgIHRkIHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG4gICAgICAgICAgICAgICAgaSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogY29sb3IgMC4ycztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjOTk5ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIEVuc3VyZSBoZWFkZXIgY2VsbHMgYXJlIGFsc28gY2VudGVyZWRcclxuICAgIC8vIHRoW3BTb3J0YWJsZUNvbHVtbj1cIm5hbWVcIl0sXHJcbiAgICAvLyB0aFtwU29ydGFibGVDb2x1bW49XCJjbGFzc3Jvb21zXCJdLFxyXG4gICAgdGhbcFNvcnRhYmxlQ29sdW1uPVwicm9sZVwiXSxcclxuICAgIHRoW3BTb3J0YWJsZUNvbHVtbj1cInJlcXVlc3RzUGVuZGluZ1wiXSxcclxuICAgIHRoW3BTb3J0YWJsZUNvbHVtbj1cInJlcXVlc3RzQ29tcGxldGVkXCJdLFxyXG4gICAgdGhbcFNvcnRhYmxlQ29sdW1uPVwiY29uc3VtcHRpb25zXCJdIHtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXIgIWltcG9ydGFudDtcclxuXHJcbiAgICAgICAgLnAtc29ydGFibGUtY29sdW1uLWljb24ge1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogNHB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG59XHJcblxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5jdXN0b20tY2FsZW5kYXIge1xyXG4gICAgICAgIC5wLWNhbGVuZGFyIHtcclxuICAgICAgICAgICAgbWluLXdpZHRoOiAyNDdweDtcclxuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAgICAgICAgIGlucHV0IHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0IxQUZFOTFBO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4IDAgMCA4cHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLjVyZW07XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5wLWRhdGVwaWNrZXItdHJpZ2dlciB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogNDBweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNCMUFGRTkxQTtcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAgOHB4IDhweCAwO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICM2NjY7XHJcblxyXG4gICAgICAgICAgICAgICAgJjplbmFibGVkOmhvdmVyIHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjQjFBRkU5MUE7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgJjpmb2N1cyB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnAtZGF0ZXBpY2tlciB7XHJcbiAgICAgICAgICAgIG1pbi13aWR0aDogMjQ3cHg7XHJcblxyXG4gICAgICAgICAgICAmLnAtZGF0ZXBpY2tlci1pbmxpbmUge1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgdG9wOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgbGVmdDogMDtcclxuICAgICAgICAgICAgICAgIHotaW5kZXg6IDEwMDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAudXBkYXRlLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDM2NC40MnB4O1xyXG4gICAgICAgIGhlaWdodDogNDhweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xyXG4gICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpkaXNhYmxlZCB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuNjtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xyXG4gICAgICAgICAgICBjdXJzb3I6IG5vdC1hbGxvd2VkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmNsYXNzcm9vbS1pbml0aWFsIHtcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgaGVpZ2h0OiAyNHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgYmFja2dyb3VuZDogI0U2RThGMztcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcbi5jbGFzc3Jvb20tY291bnQge1xyXG4gICAgd2lkdGg6IDMycHg7XHJcbiAgICBoZWlnaHQ6IDIzcHg7XHJcbiAgICBnYXA6IDE2cHg7XHJcbiAgICBwYWRkaW5nOiA0cHggOHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Q5RkZDQjY2O1xyXG4gICAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBjb2xvcjogIzMzMzMzMztcclxufVxyXG5cclxuOjpuZy1kZWVwIC5wLXRvb2x0aXAge1xyXG4gICAgLnAtdG9vbHRpcC10ZXh0IHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjBGRkVBICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6ICMzMzMzMzMgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjRTZFNkU2O1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5wLXRvb2x0aXAtYXJyb3cge1xyXG4gICAgICAgIGJvcmRlci10b3AtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG5cclxuLmNsYXNzcm9vbS1jb3VudC13cmFwcGVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZ2FwOiA4cHg7XHJcblxyXG4gICAgLmVkaXQtaWNvbiB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGNvbG9yOiAjNkU2RTZFO1xyXG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICBvcGFjaXR5OiAwLjc7XHJcbiAgICAgICAgdHJhbnNpdGlvbjogb3BhY2l0eSAwLjJzO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAvLyBFbnN1cmUgQUxMIG92ZXJsYXlzIGFuZCBtZW51cyBoYXZlIHdoaXRlIGJhY2tncm91bmQsIGFsd2F5c1xyXG4gICAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSxcclxuICAgIC5jdXN0b20tYWN0aW9uLW1lbnUgLnAtbWVudSxcclxuICAgIC5wLW1lbnUuY3VzdG9tLWFjdGlvbi1tZW51LFxyXG4gICAgLnAtbWVudS5jdXN0b20tYWN0aW9uLW1lbnUgLnAtbWVudSxcclxuICAgIC5wLW1lbnUtb3ZlcmxheS5jdXN0b20tYWN0aW9uLW1lbnUsXHJcbiAgICAucC1tZW51LW92ZXJsYXkuY3VzdG9tLWFjdGlvbi1tZW51IC5wLW1lbnUge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA4cHggIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjRTZFNkU2ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMHB4IDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjA1KSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxuICAgIC5jdXN0b20tYWN0aW9uLW1lbnUgLnAtbWVudWl0ZW0tbGluayxcclxuICAgIC5jdXN0b20tYWN0aW9uLW1lbnUgLnAtbWVudWl0ZW0ge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5kZWxldGUtZGlhbG9nIHtcclxuICAgICAgICAucC1kaWFsb2ctY29udGVudCB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDJyZW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5kZWxldGUtaWNvbi1jb250YWluZXIge1xyXG4gICAgICAgIHdpZHRoOiA2NHB4O1xyXG4gICAgICAgIGhlaWdodDogNjRweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0Q5MkQyMDtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAgICAgLnBpLXRyYXNoIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmRlbGV0ZS1tZXNzYWdlIHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgY29sb3I6ICMzNDQwNTQ7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDEuNTtcclxuXHJcbiAgICAgICAgc3Ryb25nIHtcclxuICAgICAgICAgICAgY29sb3I6ICMxMDE4Mjg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDE3N3B4O1xyXG4gICAgICAgIGhlaWdodDogNDhweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xyXG4gICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpmb2N1cyB7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5jYW5jZWwtYnV0dG9uIHtcclxuICAgICAgICBjb2xvcjogIzZDNzU3RDtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICBjb2xvcjogIzQ5NTA1NztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5jYW5jZWwtYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMTc3LjIxcHg7XHJcbiAgICAgICAgaGVpZ2h0OiA0OHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcclxuICAgICAgICBnYXA6IDguN3B4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAgICAgLy8gQ3JlYXRlIGdyYWRpZW50IGJvcmRlclxyXG4gICAgICAgICY6OmJlZm9yZSB7XHJcbiAgICAgICAgICAgIGNvbnRlbnQ6ICcnO1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDogMDtcclxuICAgICAgICAgICAgbGVmdDogMDtcclxuICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgIGJvdHRvbTogMDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNi45NnB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpIGJvcmRlci1ib3g7XHJcbiAgICAgICAgICAgIC13ZWJraXQtbWFzazpcclxuICAgICAgICAgICAgICAgIGxpbmVhci1ncmFkaWVudCgjZmZmIDAgMCkgcGFkZGluZy1ib3gsXHJcbiAgICAgICAgICAgICAgICBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApO1xyXG4gICAgICAgICAgICAtd2Via2l0LW1hc2stY29tcG9zaXRlOiBkZXN0aW5hdGlvbi1vdXQ7XHJcbiAgICAgICAgICAgIG1hc2stY29tcG9zaXRlOiBleGNsdWRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gR3JhZGllbnQgdGV4dFxyXG4gICAgICAgIC5wLWJ1dHRvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcclxuICAgICAgICAgICAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY2xpcDogdGV4dDtcclxuICAgICAgICAgICAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cclxuICAgICAgICAgICAgJjo6YmVmb3JlIHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKSBib3JkZXItYm94O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAucC1idXR0b24tbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xyXG4gICAgICAgICAgICAgICAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuXHJcbiAgICAvLyBBZGQgdGhpcyBuZXcgc2VjdGlvblxyXG4gICAgLnAtZGlhbG9nIHtcclxuICAgICAgICAmLnAtZmx1aWQge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IGF1dG87XHJcblxyXG4gICAgICAgICAgICAucC1kaWFsb2ctY29udGVudCB7XHJcbiAgICAgICAgICAgICAgICBvdmVyZmxvdy15OiB2aXNpYmxlO1xyXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgICAgICAgICAgICAgbWF4LWhlaWdodDogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgLy8gcGFkZGluZzogMnJlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnAtZGlhbG9nLWhlYWRlciB7XHJcbiAgICAgICAgICAgIC8vIHBhZGRpbmc6IDJyZW0gMnJlbSAwIDJyZW07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBBZGp1c3QgZm9ybSBzcGFjaW5nXHJcbiAgICAgICAgLnAtZmx1aWQge1xyXG4gICAgICAgICAgICAuZ3JpZCB7XHJcbiAgICAgICAgICAgICAgICByb3ctZ2FwOiAxLjVyZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8vIEFkZCB0aGlzIHRvIHlvdXIgZXhpc3RpbmcgOmhvc3QgOjpuZy1kZWVwIHNlY3Rpb25cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5wLWRyb3Bkb3duIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgICAgIC5wLWRyb3Bkb3duLWxhYmVsIHtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDA7XHJcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAwO1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMzFweDsgLy8gQWRqdXN0IHRoaXMgdG8gbWF0Y2ggeW91ciBoZWlnaHQgLSAycHggZm9yIGJvcmRlcnNcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5wLWRyb3Bkb3duLXRyaWdnZXIge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIGxhYmVsIHN1cCB7XHJcbiAgICBjb2xvcjogcmVkO1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICBtYXJnaW4tbGVmdDogMC41cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtMC41cHg7XHJcbn1cclxuIiwiLyogR2VuZXJhbCBGbGV4IExheW91dDogMTJweCBnYXAgYmV0d2VlbiBjb250cm9scyAqL1xuLmZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xuICBnYXA6IDEycHg7XG4gIC8qIDEycHggZ2FwIGJldHdlZW4gZWFjaCBjb250cm9sICovXG59XG5cbi8qIFNlYXJjaCBJbnB1dCBzdHlsZXMgKi9cbi5zZWFyY2gtaW5wdXQge1xuICB3aWR0aDogMjQ2cHg7XG4gIC8qIE1hdGNoaW5nIHRoZSB3aWR0aCBmcm9tIEZpZ21hICovXG4gIGhlaWdodDogNDBweDtcbiAgLyogTWF0Y2hpbmcgdGhlIGhlaWdodCBmcm9tIEZpZ21hICovXG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgLyogT3B0aW9uYWw6IFNwYWNlIGJldHdlZW4gdGhlIGljb24gYW5kIHRleHQgKi9cbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAvKiBSb3VuZGVkIGNvcm5lcnMgZm9yIHRoZSBpbnB1dCAqL1xufVxuXG4vKiBDbGVhciBCdXR0b24gY3VzdG9tIHN0eWxlcyAqL1xuLmNsZWFyLWJ1dHRvbiB7XG4gIHdpZHRoOiA2M3B4O1xuICBoZWlnaHQ6IDIzcHg7XG4gIGdhcDogNnB4O1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyOiBub25lO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpO1xuICBib3JkZXItcmFkaXVzOiAzcHg7XG4gIHBhZGRpbmctdG9wOiA0cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDhweDtcbiAgcGFkZGluZy1ib3R0b206IDRweDtcbiAgcGFkZGluZy1sZWZ0OiA4cHg7XG59XG4uY2xlYXItYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNEI2OEUxLCAjOEI2RUZGKTtcbn1cblxuLyogT3B0aW9uYWw6IFN0eWxlIGZvciB0aGUgYnV0dG9uJ3MgaWNvbiAqL1xuLmNsZWFyLWJ1dHRvbiBpIHtcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XG4gIC8qIEFkanVzdCBpZiB5b3Ugd2FudCBzcGFjZSBiZXR3ZWVuIHRoZSBpY29uIGFuZCB0ZXh0ICovXG59XG5cbjo6bmctZGVlcCAuYWRkLWJ1dHRvbiB7XG4gIHdpZHRoOiAxMS41cmVtO1xuICBoZWlnaHQ6IDNyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiAjZmZmO1xuICBib3JkZXI6IG5vbmU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzU5NzhGNywgIzlDODRGRik7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgcGFkZGluZzogMC41cmVtIDFyZW07XG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4zcyBlYXNlO1xuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xufVxuOjpuZy1kZWVwIC5hZGQtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNEI2OEUxLCAjOEI2RUZGKTtcbn1cbjo6bmctZGVlcCAuYWRkLWJ1dHRvbjpkaXNhYmxlZCB7XG4gIGN1cnNvcjogbm90LWFsbG93ZWQgIWltcG9ydGFudDtcbn1cblxuLnRhYmxlLWNlbGwge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5hY3Rpb24tY29udGFpbmVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbi5wbGFpbi1kb3RzIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgYm9yZGVyOiBub25lO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLmN1c3RvbS1kcm9wZG93biB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogMTAwJTtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgei1pbmRleDogMTAwMDtcbn1cblxuLmRyb3Bkb3duLWl0ZW0ge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDhweCAxNnB4O1xuICBib3JkZXI6IG5vbmU7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi5kcm9wZG93bi1pdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIGkge1xuICB0cmFuc2l0aW9uOiBjb2xvciAwLjJzO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIGk6aG92ZXIge1xuICBjb2xvcjogIzk5OSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yb2xlXSxcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cmVxdWVzdHNQZW5kaW5nXSxcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cmVxdWVzdHNDb21wbGV0ZWRdLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1jb25zdW1wdGlvbnNdIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPXJvbGVdIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yZXF1ZXN0c1BlbmRpbmddIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yZXF1ZXN0c0NvbXBsZXRlZF0gLnAtc29ydGFibGUtY29sdW1uLWljb24sXG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPWNvbnN1bXB0aW9uc10gLnAtc29ydGFibGUtY29sdW1uLWljb24ge1xuICBtYXJnaW4tbGVmdDogNHB4O1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciB7XG4gIG1pbi13aWR0aDogMjQ3cHg7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciBpbnB1dCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDQwcHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTc3LCAxNzUsIDIzMywgMC4xMDE5NjA3ODQzKTtcbiAgYm9yZGVyOiBub25lO1xuICBib3JkZXItcmFkaXVzOiA4cHggMCAwIDhweDtcbiAgcGFkZGluZzogMC41cmVtO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci10cmlnZ2VyIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgYmFja2dyb3VuZDogcmdiYSgxNzcsIDE3NSwgMjMzLCAwLjEwMTk2MDc4NDMpO1xuICBib3JkZXI6IG5vbmU7XG4gIGJvcmRlci1yYWRpdXM6IDAgOHB4IDhweCAwO1xuICBjb2xvcjogIzY2Njtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXItdHJpZ2dlcjplbmFibGVkOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogcmdiYSgxNzcsIDE3NSwgMjMzLCAwLjEwMTk2MDc4NDMpO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci10cmlnZ2VyOmZvY3VzIHtcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXIge1xuICBtaW4td2lkdGg6IDI0N3B4O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci5wLWRhdGVwaWNrZXItaW5saW5lIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDEwMCU7XG4gIGxlZnQ6IDA7XG4gIHotaW5kZXg6IDEwMDA7XG59XG5cbjpob3N0IDo6bmctZGVlcCAudXBkYXRlLWJ1dHRvbiB7XG4gIHdpZHRoOiAzNjQuNDJweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xufVxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uOmRpc2FibGVkIHtcbiAgb3BhY2l0eTogMC42O1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XG59XG5cbi5jbGFzc3Jvb20taW5pdGlhbCB7XG4gIHdpZHRoOiAyNHB4O1xuICBoZWlnaHQ6IDI0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZDogI0U2RThGMztcbiAgY29sb3I6ICNGRkZGRkY7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXNpemU6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5jbGFzc3Jvb20tY291bnQge1xuICB3aWR0aDogMzJweDtcbiAgaGVpZ2h0OiAyM3B4O1xuICBnYXA6IDE2cHg7XG4gIHBhZGRpbmc6IDRweCA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyMTcsIDI1NSwgMjAzLCAwLjQpO1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICMzMzMzMzM7XG59XG5cbjo6bmctZGVlcCAucC10b29sdGlwIC5wLXRvb2x0aXAtdGV4dCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcbiAgY29sb3I6ICMzMzMzMzMgIWltcG9ydGFudDtcbiAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNjtcbiAgYm94LXNoYWRvdzogMCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgZm9udC1zaXplOiAxMXB4O1xufVxuOjpuZy1kZWVwIC5wLXRvb2x0aXAgLnAtdG9vbHRpcC1hcnJvdyB7XG4gIGJvcmRlci10b3AtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcbn1cblxuLmNsYXNzcm9vbS1jb3VudC13cmFwcGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZ2FwOiA4cHg7XG59XG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIgLmVkaXQtaWNvbiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM2RTZFNkU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgb3BhY2l0eTogMC43O1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuMnM7XG59XG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIgLmVkaXQtaWNvbjpob3ZlciB7XG4gIG9wYWNpdHk6IDE7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5LFxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUgLnAtbWVudSxcbjpob3N0IDo6bmctZGVlcCAucC1tZW51LmN1c3RvbS1hY3Rpb24tbWVudSxcbjpob3N0IDo6bmctZGVlcCAucC1tZW51LmN1c3RvbS1hY3Rpb24tbWVudSAucC1tZW51LFxuOmhvc3QgOjpuZy1kZWVwIC5wLW1lbnUtb3ZlcmxheS5jdXN0b20tYWN0aW9uLW1lbnUsXG46aG9zdCA6Om5nLWRlZXAgLnAtbWVudS1vdmVybGF5LmN1c3RvbS1hY3Rpb24tbWVudSAucC1tZW51IHtcbiAgYmFja2dyb3VuZDogI2ZmZiAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiA4cHggIWltcG9ydGFudDtcbiAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNiAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiAwcHggMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMDUpICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudSAucC1tZW51aXRlbS1saW5rLFxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUgLnAtbWVudWl0ZW0ge1xuICBiYWNrZ3JvdW5kOiAjZmZmICFpbXBvcnRhbnQ7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLWRpYWxvZyAucC1kaWFsb2ctY29udGVudCB7XG4gIHBhZGRpbmc6IDJyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciB7XG4gIHdpZHRoOiA2NHB4O1xuICBoZWlnaHQ6IDY0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0Q5MkQyMDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciAucGktdHJhc2gge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtbWVzc2FnZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICMzNDQwNTQ7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1tZXNzYWdlIHN0cm9uZyB7XG4gIGNvbG9yOiAjMTAxODI4O1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbiB7XG4gIHdpZHRoOiAxNzdweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtY29uZmlybS1idXR0b246aG92ZXIge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSk7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b24ge1xuICBjb2xvcjogIzZDNzU3RDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBjb2xvcjogIzQ5NTA1Nztcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbiB7XG4gIHdpZHRoOiAxNzcuMjFweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGdhcDogOC43cHg7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246OmJlZm9yZSB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgYm90dG9tOiAwO1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSkgYm9yZGVyLWJveDtcbiAgLXdlYmtpdC1tYXNrOiBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApIHBhZGRpbmctYm94LCBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApO1xuICAtd2Via2l0LW1hc2stY29tcG9zaXRlOiBkZXN0aW5hdGlvbi1vdXQ7XG4gIG1hc2stY29tcG9zaXRlOiBleGNsdWRlO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uIC5wLWJ1dHRvbi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246aG92ZXI6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKSBib3JkZXItYm94O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIC5wLWJ1dHRvbi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cucC1mbHVpZCB7XG4gIGhlaWdodDogYXV0bztcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cucC1mbHVpZCAucC1kaWFsb2ctY29udGVudCB7XG4gIG92ZXJmbG93LXk6IHZpc2libGU7XG4gIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgbWF4LWhlaWdodDogbm9uZSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRpYWxvZyAucC1mbHVpZCAuZ3JpZCB7XG4gIHJvdy1nYXA6IDEuNXJlbTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5wLWRyb3Bkb3duIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kcm9wZG93biAucC1kcm9wZG93bi1sYWJlbCB7XG4gIHBhZGRpbmctdG9wOiAwO1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgbGluZS1oZWlnaHQ6IDMxcHg7XG59XG46aG9zdCA6Om5nLWRlZXAgLnAtZHJvcGRvd24gLnAtZHJvcGRvd24tdHJpZ2dlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbjpob3N0IDo6bmctZGVlcCBsYWJlbCBzdXAge1xuICBjb2xvcjogcmVkO1xuICBmb250LXNpemU6IDFlbTtcbiAgbWFyZ2luLWxlZnQ6IDAuNXB4O1xuICBtYXJnaW4tdG9wOiAtMC41cHg7XG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 96539:
/*!************************************************************************************************!*\
  !*** ./src/app/modules/app/inventory/vendor/vendor-count-card/vendor-count-cards.component.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorCountCardComponent: () => (/* binding */ VendorCountCardComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/inventory/vendor/vendor.service */ 71286);
/* harmony import */ var _vendor_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../vendor.service */ 47303);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 27947);





class VendorCountCardComponent {
  constructor(_vendorSharedService, _vendorService, router) {
    this._vendorSharedService = _vendorSharedService;
    this._vendorService = _vendorService;
    this.router = router;
    this.totalVendors = 0;
    this.activeVendors = 0;
    this.inactiveVendors = 0;
    this.totalCategories = 0;
    this.isRefreshCount = false;
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
  }
  ngOnInit() {
    this.getCountCard();
    // Subscribe to vendor updates
    this._vendorSharedService.vendors$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.takeUntil)(this._unsubscribeAll)).subscribe(() => {
      this.getCountCard();
    });
  }
  ngOnChanges() {
    if (this.isRefreshCount) {
      this.getCountCard();
    }
  }
  ngOnDestroy() {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
  goToVendorCategories() {
    this.router.navigate(['/vendors/category-list']);
  }
  getCountCard() {
    this._vendorService.getVendorCounts().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.takeUntil)(this._unsubscribeAll)).subscribe({
      next: response => {
        if (response.success && response.data) {
          this.totalVendors = response.data.totalVendors;
          this.activeVendors = response.data.activeVendors;
          this.inactiveVendors = response.data.inactiveVendors;
          this.totalCategories = response.data.totalCategories;
        }
      },
      error: error => {
        console.error('Error fetching vendor counts:', error);
        this.totalVendors = 0;
        this.activeVendors = 0;
        this.inactiveVendors = 0;
      }
    });
  }
  static #_ = this.ɵfac = function VendorCountCardComponent_Factory(t) {
    return new (t || VendorCountCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_0__.VendorSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_vendor_service__WEBPACK_IMPORTED_MODULE_1__.VendorService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: VendorCountCardComponent,
    selectors: [["app-vendor-count-card"]],
    inputs: {
      isRefreshCount: "isRefreshCount"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵNgOnChangesFeature"]],
    decls: 16,
    vars: 2,
    consts: [[1, "grid", "nested-grid", "pl-0"], [1, "col-12", "xl:col-8", "lg:col-8", "md:col-12", "sm:col-12", "w-full"], [1, "flex", "flex-wrap", "w-full", "gap-2", "justify-content-between", "align-items-center"], [1, "flex", "flex-wrap", "gap-2"], [1, "count-card"], [1, "count-card-content"], [1, "count-label"], [1, "count-value"], [1, "count-card", 2, "cursor", "pointer", 3, "click"]],
    template: function VendorCountCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Total Vendors");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VendorCountCardComponent_Template_div_click_10_listener() {
          return ctx.goToVendorCategories();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 5)(12, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Total Categories");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.totalVendors);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.totalCategories);
      }
    },
    styles: ["[_nghost-%COMP%]     .count-card {\n  width: 208px;\n  height: 77px;\n}\n[_nghost-%COMP%]     .count-card .count-card-content {\n  height: 100%;\n  background: var(--White-colour, #ffffff);\n  border: 1px solid rgba(22, 40, 49, 0.1);\n  border-radius: 12px;\n  padding: 1rem;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n[_nghost-%COMP%]     .count-card .count-label {\n  font-size: 13px;\n  font-weight: 600;\n  color: rgba(65, 65, 78, 0.8);\n  max-width: 100px;\n}\n[_nghost-%COMP%]     .count-card .count-value {\n  font-size: 18px;\n  font-weight: 600;\n  color: #41414E;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvaW52ZW50b3J5L3ZlbmRvci92ZW5kb3ItY291bnQtY2FyZC92ZW5kb3ItY291bnQtY2FyZHMuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi9OZXclMjBmb2xkZXIvdmdzY2hvb2wtdGhlbWUvc3JjL2FwcC9tb2R1bGVzL2FwcC9pbnZlbnRvcnkvdmVuZG9yL3ZlbmRvci1jb3VudC1jYXJkL3ZlbmRvci1jb3VudC1jYXJkcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLFlBQUE7RUFDQSxZQUFBO0FDQVI7QURFUTtFQUNJLFlBQUE7RUFDQSx3Q0FBQTtFQUNBLHVDQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUNBWjtBREdRO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtBQ0RaO0FESVE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0NBQUE7QUNGWiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAuY291bnQtY2FyZCB7XHJcbiAgICAgICAgd2lkdGg6IDIwOHB4O1xyXG4gICAgICAgIGhlaWdodDogNzdweDtcclxuXHJcbiAgICAgICAgLmNvdW50LWNhcmQtY29udGVudCB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tV2hpdGUtY29sb3VyLCAjZmZmZmZmKTtcclxuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMiwgNDAsIDQ5LCAwLjEpO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxcmVtO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY291bnQtbGFiZWwge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiByZ2JhKDY1LCA2NSwgNzgsIDAuOCk7XHJcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY291bnQtdmFsdWUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNDE0MTRFO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XHJcbiAgICAgICAgICAgIC13ZWJraXQtYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIC13ZWJraXQtdGV4dC1maWxsLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIiwiOmhvc3QgOjpuZy1kZWVwIC5jb3VudC1jYXJkIHtcbiAgd2lkdGg6IDIwOHB4O1xuICBoZWlnaHQ6IDc3cHg7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNvdW50LWNhcmQgLmNvdW50LWNhcmQtY29udGVudCB7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZDogdmFyKC0tV2hpdGUtY29sb3VyLCAjZmZmZmZmKTtcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMiwgNDAsIDQ5LCAwLjEpO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBwYWRkaW5nOiAxcmVtO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG46aG9zdCA6Om5nLWRlZXAgLmNvdW50LWNhcmQgLmNvdW50LWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogcmdiYSg2NSwgNjUsIDc4LCAwLjgpO1xuICBtYXgtd2lkdGg6IDEwMHB4O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jb3VudC1jYXJkIC5jb3VudC12YWx1ZSB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICM0MTQxNEU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 47535:
/*!***********************************************************************!*\
  !*** ./src/app/modules/app/inventory/vendor/vendor-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorRoutingModule: () => (/* binding */ VendorRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _vendor_resolver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vendor.resolver */ 83278);
/* harmony import */ var _list_list_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list/list.component */ 87865);
/* harmony import */ var _category_list_list_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./category/list/list.component */ 46164);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61699);






class VendorRoutingModule {
  static #_ = this.ɵfac = function VendorRoutingModule_Factory(t) {
    return new (t || VendorRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: VendorRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild([{
      path: 'vendor-list',
      component: _list_list_component__WEBPACK_IMPORTED_MODULE_1__.VendorComponent,
      data: {
        breadcrumb: 'Vendor List'
      },
      resolve: {
        vendors: _vendor_resolver__WEBPACK_IMPORTED_MODULE_0__.vendorResolver,
        vendorCategories: _vendor_resolver__WEBPACK_IMPORTED_MODULE_0__.vendorCategoriesResolver
      }
    }, {
      path: 'category-list',
      component: _category_list_list_component__WEBPACK_IMPORTED_MODULE_2__.VendorCategoryListComponent,
      data: {
        breadcrumb: 'Vendor Category'
      },
      resolve: {
        vendorCategories: _vendor_resolver__WEBPACK_IMPORTED_MODULE_0__.vendorCategoriesResolver
      }
    }]), _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](VendorRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 42657:
/*!***************************************************************!*\
  !*** ./src/app/modules/app/inventory/vendor/vendor.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorModule: () => (/* binding */ VendorModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/fileupload */ 88285);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_toolbar__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/toolbar */ 39177);
/* harmony import */ var primeng_rating__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/rating */ 85583);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/inputtextarea */ 30652);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dropdown */ 94553);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/radiobutton */ 63313);
/* harmony import */ var primeng_inputnumber__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/inputnumber */ 65362);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/calendar */ 57411);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/multiselect */ 77524);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/tooltip */ 31251);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/splitbutton */ 64323);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var _vendor_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vendor-routing.module */ 47535);
/* harmony import */ var _list_list_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list/list.component */ 87865);
/* harmony import */ var _vendor_count_card_vendor_count_cards_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./vendor-count-card/vendor-count-cards.component */ 96539);
/* harmony import */ var _category_list_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./category/list/list.component */ 46164);
/* harmony import */ var _category_vendor_category_count_card_vendor_category_count_cards_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./category/vendor-category-count-card/vendor-category-count-cards.component */ 75122);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61699);


























class VendorModule {
  static #_ = this.ɵfac = function VendorModule_Factory(t) {
    return new (t || VendorModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
    type: VendorModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule, _vendor_routing_module__WEBPACK_IMPORTED_MODULE_0__.VendorRoutingModule, primeng_table__WEBPACK_IMPORTED_MODULE_8__.TableModule, primeng_fileupload__WEBPACK_IMPORTED_MODULE_9__.FileUploadModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_10__.ButtonModule, primeng_menu__WEBPACK_IMPORTED_MODULE_11__.MenuModule, primeng_calendar__WEBPACK_IMPORTED_MODULE_12__.CalendarModule, primeng_splitbutton__WEBPACK_IMPORTED_MODULE_13__.SplitButtonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_14__.RippleModule, primeng_toast__WEBPACK_IMPORTED_MODULE_15__.ToastModule, primeng_toolbar__WEBPACK_IMPORTED_MODULE_16__.ToolbarModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_17__.TooltipModule, primeng_rating__WEBPACK_IMPORTED_MODULE_18__.RatingModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_19__.InputTextModule, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_20__.InputTextareaModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_21__.DropdownModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_22__.RadioButtonModule, primeng_inputnumber__WEBPACK_IMPORTED_MODULE_23__.InputNumberModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_24__.DialogModule, primeng_multiselect__WEBPACK_IMPORTED_MODULE_25__.MultiSelectModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](VendorModule, {
    declarations: [_list_list_component__WEBPACK_IMPORTED_MODULE_1__.VendorComponent, _vendor_count_card_vendor_count_cards_component__WEBPACK_IMPORTED_MODULE_2__.VendorCountCardComponent, _category_list_list_component__WEBPACK_IMPORTED_MODULE_3__.VendorCategoryListComponent, _category_vendor_category_count_card_vendor_category_count_cards_component__WEBPACK_IMPORTED_MODULE_4__.VendorCategoryCountCardComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule, _vendor_routing_module__WEBPACK_IMPORTED_MODULE_0__.VendorRoutingModule, primeng_table__WEBPACK_IMPORTED_MODULE_8__.TableModule, primeng_fileupload__WEBPACK_IMPORTED_MODULE_9__.FileUploadModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_10__.ButtonModule, primeng_menu__WEBPACK_IMPORTED_MODULE_11__.MenuModule, primeng_calendar__WEBPACK_IMPORTED_MODULE_12__.CalendarModule, primeng_splitbutton__WEBPACK_IMPORTED_MODULE_13__.SplitButtonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_14__.RippleModule, primeng_toast__WEBPACK_IMPORTED_MODULE_15__.ToastModule, primeng_toolbar__WEBPACK_IMPORTED_MODULE_16__.ToolbarModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_17__.TooltipModule, primeng_rating__WEBPACK_IMPORTED_MODULE_18__.RatingModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_19__.InputTextModule, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_20__.InputTextareaModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_21__.DropdownModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_22__.RadioButtonModule, primeng_inputnumber__WEBPACK_IMPORTED_MODULE_23__.InputNumberModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_24__.DialogModule, primeng_multiselect__WEBPACK_IMPORTED_MODULE_25__.MultiSelectModule]
  });
})();

/***/ }),

/***/ 83278:
/*!*****************************************************************!*\
  !*** ./src/app/modules/app/inventory/vendor/vendor.resolver.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   vendorCategoriesResolver: () => (/* binding */ vendorCategoriesResolver),
/* harmony export */   vendorResolver: () => (/* binding */ vendorResolver)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 81891);
/* harmony import */ var src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/inventory/vendor/vendor.service */ 71286);
/* harmony import */ var src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/school/school.service */ 62915);
/* harmony import */ var _vendor_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./vendor.service */ 47303);





const vendorCategoriesResolver = () => {
  const vendorCategoryService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_0__.VendorSharedService);
  const schoolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_1__.SchoolSharedService);
  return schoolService.school$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.switchMap)(school => vendorCategoryService.getCategoriesBySchool(school?.code || '')));
};
const vendorResolver = route => {
  const vendorSharedService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_0__.VendorSharedService);
  const vendorService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_vendor_service__WEBPACK_IMPORTED_MODULE_2__.VendorService);
  const schoolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_1__.SchoolSharedService);
  const categoryCode = route.queryParamMap.get('category');
  return schoolService.school$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.switchMap)(school => {
    if (categoryCode) {
      // Call API to get vendors by category
      return vendorService.getVendorsBySchoolCategory(school?.code || '', categoryCode);
    } else {
      // Call API to get all vendors
      return vendorSharedService.getVendorsBySchool(school?.code || '');
    }
  }));
};

/***/ }),

/***/ 47303:
/*!****************************************************************!*\
  !*** ./src/app/modules/app/inventory/vendor/vendor.service.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VendorService: () => (/* binding */ VendorService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 13738);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2389);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 33252);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 81527);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 81891);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 79736);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 20553);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 54860);
/* harmony import */ var src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/inventory/vendor/vendor.service */ 71286);





class VendorService {
  /**
   * Constructor
   */
  constructor(_httpClient, _vendorSharedService) {
    this._httpClient = _httpClient;
    this._vendorSharedService = _vendorSharedService;
    // Private
    this.API_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl;
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Accessors
  // -----------------------------------------------------------------------------------------------------
  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------
  // Vendor Methods
  getVendorsBySchoolCategory(schoolCode, categoryCode) {
    return this._httpClient.get(`${this._vendorSharedService.getVendorsUrl}/school/${schoolCode}/category/${categoryCode}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._vendorSharedService.updateVendors(response.data);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to fetch vendors:', error);
      const errorResponse = error?.error || {
        success: false,
        message: 'Failed to fetch vendors',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }));
  }
  getVendorCounts() {
    return this._vendorSharedService.vendors$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(vendors => this._vendorSharedService.categories$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.map)(categories => {
      const counts = {
        totalVendors: vendors?.length || 0,
        activeVendors: vendors?.filter(v => v.status === 'ACTIVE').length || 0,
        inactiveVendors: vendors?.filter(v => v.status === 'INACTIVE').length || 0,
        totalCategories: categories?.length || 0
      };
      return {
        success: true,
        data: counts,
        message: 'Vendor counts retrieved successfully',
        timestamp: new Date()
      };
    }))));
  }
  getVendorCategoryCounts() {
    return this._vendorSharedService.categories$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.map)(categories => {
      // Sum vendorCount from each category (default to 0 if missing)
      const totalVendors = (categories || []).reduce((sum, category) => sum + (category.vendorCount || 0), 0);
      const counts = {
        totalVendors,
        totalCategories: categories?.length || 0
      };
      return {
        success: true,
        data: counts,
        message: 'Vendor category counts retrieved successfully',
        timestamp: new Date()
      };
    }));
  }
  /**
   * Export vendors as a file (e.g., Excel)
   */
  exportVendors(schoolCode) {
    // Replace with your actual backend export endpoint
    return this._httpClient.get(`${this.API_URL}/vendors/${schoolCode}/export`, {
      responseType: 'blob'
    });
  }
  static #_ = this.ɵfac = function VendorService_Factory(t) {
    return new (t || VendorService)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](src_app_core_inventory_vendor_vendor_service__WEBPACK_IMPORTED_MODULE_1__.VendorSharedService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjectable"]({
    token: VendorService,
    factory: VendorService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 30652:
/*!*****************************************************************!*\
  !*** ./node_modules/primeng/fesm2022/primeng-inputtextarea.mjs ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InputTextarea: () => (/* binding */ InputTextarea),
/* harmony export */   InputTextareaModule: () => (/* binding */ InputTextareaModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 28849);





/**
 * InputTextarea adds styling and autoResize functionality to standard textarea element.
 * @group Components
 */
class InputTextarea {
  el;
  ngModel;
  control;
  cd;
  /**
   * When present, textarea size changes as being typed.
   * @group Props
   */
  autoResize;
  /**
   * Callback to invoke on textarea resize.
   * @param {(Event | {})} event - Custom resize event.
   * @group Emits
   */
  onResize = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  filled;
  cachedScrollHeight;
  ngModelSubscription;
  ngControlSubscription;
  constructor(el, ngModel, control, cd) {
    this.el = el;
    this.ngModel = ngModel;
    this.control = control;
    this.cd = cd;
  }
  ngOnInit() {
    if (this.ngModel) {
      this.ngModelSubscription = this.ngModel.valueChanges.subscribe(() => {
        this.updateState();
      });
    }
    if (this.control) {
      this.ngControlSubscription = this.control.valueChanges.subscribe(() => {
        this.updateState();
      });
    }
  }
  ngAfterViewChecked() {
    this.updateState();
  }
  ngAfterViewInit() {
    if (this.autoResize) this.resize();
    this.updateFilledState();
    this.cd.detectChanges();
  }
  onInput(e) {
    this.updateState();
  }
  updateFilledState() {
    this.filled = this.el.nativeElement.value && this.el.nativeElement.value.length;
  }
  resize(event) {
    this.el.nativeElement.style.height = 'auto';
    this.el.nativeElement.style.height = this.el.nativeElement.scrollHeight + 'px';
    if (parseFloat(this.el.nativeElement.style.height) >= parseFloat(this.el.nativeElement.style.maxHeight)) {
      this.el.nativeElement.style.overflowY = 'scroll';
      this.el.nativeElement.style.height = this.el.nativeElement.style.maxHeight;
    } else {
      this.el.nativeElement.style.overflow = 'hidden';
    }
    this.onResize.emit(event || {});
  }
  updateState() {
    this.updateFilledState();
    if (this.autoResize) {
      this.resize();
    }
  }
  ngOnDestroy() {
    if (this.ngModelSubscription) {
      this.ngModelSubscription.unsubscribe();
    }
    if (this.ngControlSubscription) {
      this.ngControlSubscription.unsubscribe();
    }
  }
  static ɵfac = function InputTextarea_Factory(t) {
    return new (t || InputTextarea)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgModel, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControl, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef));
  };
  static ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
    type: InputTextarea,
    selectors: [["", "pInputTextarea", ""]],
    hostAttrs: [1, "p-inputtextarea", "p-inputtext", "p-component", "p-element"],
    hostVars: 4,
    hostBindings: function InputTextarea_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("input", function InputTextarea_input_HostBindingHandler($event) {
          return ctx.onInput($event);
        });
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("p-filled", ctx.filled)("p-inputtextarea-resizable", ctx.autoResize);
      }
    },
    inputs: {
      autoResize: "autoResize"
    },
    outputs: {
      onResize: "onResize"
    }
  });
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](InputTextarea, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[pInputTextarea]',
      host: {
        class: 'p-inputtextarea p-inputtext p-component p-element',
        '[class.p-filled]': 'filled',
        '[class.p-inputtextarea-resizable]': 'autoResize'
      }
    }]
  }], () => [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
  }, {
    type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgModel,
    decorators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
    }]
  }, {
    type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControl,
    decorators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
    }]
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
  }], {
    autoResize: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    onResize: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    onInput: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener,
      args: ['input', ['$event']]
    }]
  });
})();
class InputTextareaModule {
  static ɵfac = function InputTextareaModule_Factory(t) {
    return new (t || InputTextareaModule)();
  };
  static ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
    type: InputTextareaModule
  });
  static ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule]
  });
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](InputTextareaModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule],
      exports: [InputTextarea],
      declarations: [InputTextarea]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */



/***/ }),

/***/ 39177:
/*!***********************************************************!*\
  !*** ./node_modules/primeng/fesm2022/primeng-toolbar.mjs ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Toolbar: () => (/* binding */ Toolbar),
/* harmony export */   ToolbarModule: () => (/* binding */ ToolbarModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/api */ 98026);






/**
 * Toolbar is a grouping component for buttons and other content.
 * @group Components
 */
function Toolbar_div_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
function Toolbar_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, Toolbar_div_2_ng_container_1_Template, 1, 0, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("data-pc-section", "start");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r0.startTemplate);
  }
}
function Toolbar_div_3_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
function Toolbar_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, Toolbar_div_3_ng_container_1_Template, 1, 0, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("data-pc-section", "center");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r1.centerTemplate);
  }
}
function Toolbar_div_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
function Toolbar_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, Toolbar_div_4_ng_container_1_Template, 1, 0, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("data-pc-section", "end");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r2.endTemplate);
  }
}
const _c0 = ["*"];
class Toolbar {
  el;
  /**
   * Inline style of the component.
   * @group Props
   */
  style;
  /**
   * Style class of the component.
   * @group Props
   */
  styleClass;
  /**
   * Defines a string value that labels an interactive element.
   * @group Props
   */
  ariaLabelledBy;
  templates;
  startTemplate;
  endTemplate;
  centerTemplate;
  constructor(el) {
    this.el = el;
  }
  getBlockableElement() {
    return this.el.nativeElement.children[0];
  }
  ngAfterContentInit() {
    this.templates.forEach(item => {
      switch (item.getType()) {
        case 'start':
        case 'left':
          this.startTemplate = item.template;
          break;
        case 'end':
        case 'right':
          this.endTemplate = item.template;
          break;
        case 'center':
          this.centerTemplate = item.template;
          break;
      }
    });
  }
  static ɵfac = function Toolbar_Factory(t) {
    return new (t || Toolbar)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef));
  };
  static ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: Toolbar,
    selectors: [["p-toolbar"]],
    contentQueries: function Toolbar_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, primeng_api__WEBPACK_IMPORTED_MODULE_1__.PrimeTemplate, 4);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.templates = _t);
      }
    },
    hostAttrs: [1, "p-element"],
    inputs: {
      style: "style",
      styleClass: "styleClass",
      ariaLabelledBy: "ariaLabelledBy"
    },
    ngContentSelectors: _c0,
    decls: 5,
    vars: 9,
    consts: [["role", "toolbar", 3, "ngClass", "ngStyle"], ["class", "p-toolbar-group-left p-toolbar-group-start", 4, "ngIf"], ["class", "p-toolbar-group-center", 4, "ngIf"], ["class", "p-toolbar-group-right p-toolbar-group-end", 4, "ngIf"], [1, "p-toolbar-group-left", "p-toolbar-group-start"], [4, "ngTemplateOutlet"], [1, "p-toolbar-group-center"], [1, "p-toolbar-group-right", "p-toolbar-group-end"]],
    template: function Toolbar_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, Toolbar_div_2_Template, 2, 2, "div", 1)(3, Toolbar_div_3_Template, 2, 2, "div", 2)(4, Toolbar_div_4_Template, 2, 2, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.styleClass);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "p-toolbar p-component")("ngStyle", ctx.style);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-labelledby", ctx.ariaLabelledBy)("data-pc-name", "toolbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.startTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.centerTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.endTemplate);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgStyle],
    styles: ["@layer primeng{.p-toolbar{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap}.p-toolbar-group-start,.p-toolbar-group-center,.p-toolbar-group-end,.p-toolbar-group-left,.p-toolbar-group-right{display:flex;align-items:center}}\n"],
    encapsulation: 2,
    changeDetection: 0
  });
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Toolbar, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-toolbar',
      template: `
        <div [ngClass]="'p-toolbar p-component'" [attr.aria-labelledby]="ariaLabelledBy" [ngStyle]="style" [class]="styleClass" role="toolbar" [attr.data-pc-name]="'toolbar'">
            <ng-content></ng-content>
            <div class="p-toolbar-group-left p-toolbar-group-start" *ngIf="startTemplate" [attr.data-pc-section]="'start'">
                <ng-container *ngTemplateOutlet="startTemplate"></ng-container>
            </div>
            <div class="p-toolbar-group-center" *ngIf="centerTemplate" [attr.data-pc-section]="'center'">
                <ng-container *ngTemplateOutlet="centerTemplate"></ng-container>
            </div>
            <div class="p-toolbar-group-right p-toolbar-group-end" *ngIf="endTemplate" [attr.data-pc-section]="'end'">
                <ng-container *ngTemplateOutlet="endTemplate"></ng-container>
            </div>
        </div>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: ["@layer primeng{.p-toolbar{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap}.p-toolbar-group-start,.p-toolbar-group-center,.p-toolbar-group-end,.p-toolbar-group-left,.p-toolbar-group-right{display:flex;align-items:center}}\n"]
    }]
  }], () => [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
  }], {
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    ariaLabelledBy: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    templates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [primeng_api__WEBPACK_IMPORTED_MODULE_1__.PrimeTemplate]
    }]
  });
})();
class ToolbarModule {
  static ɵfac = function ToolbarModule_Factory(t) {
    return new (t || ToolbarModule)();
  };
  static ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
    type: ToolbarModule
  });
  static ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule]
  });
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ToolbarModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule],
      exports: [Toolbar],
      declarations: [Toolbar]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */



/***/ })

}]);
//# sourceMappingURL=src_app_modules_app_inventory_vendor_vendor_module_ts.js.map