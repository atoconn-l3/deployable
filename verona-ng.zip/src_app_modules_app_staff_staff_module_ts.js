"use strict";
(self["webpackChunkverona_ng"] = self["webpackChunkverona_ng"] || []).push([["src_app_modules_app_staff_staff_module_ts"],{

/***/ 40957:
/*!************************************************************************************!*\
  !*** ./src/app/modules/app/staff/staff-count-cards/staff-count-cards.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StaffCountCardComponent: () => (/* binding */ StaffCountCardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var _staff_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../staff.service */ 74975);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 27947);





class StaffCountCardComponent {
  constructor(_staffService, router) {
    this._staffService = _staffService;
    this.router = router;
    this.bgColor = "#9BE8FF";
    this.totalUsers = 0;
    this.totalStaff = 0;
    this.totalAdmins = 0;
    this.isRefreshCount = false;
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    // ...existing code...
    this.filterChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
  }
  ngOnChanges() {
    if (this.isRefreshCount) {
      this.getCountCard();
    }
  }
  ngOnInit() {
    this.getCountCard();
    // Subscribe to staff updates
    this._staffService.staffWithStockRequests$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.takeUntil)(this._unsubscribeAll)).subscribe(() => {
      this.getCountCard();
    });
  }
  ngOnDestroy() {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
  // ...existing code...
  onCardClick(type) {
    this.filterChanged.emit(type);
  }
  getCountCard() {
    this._staffService.getStaffCounts().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.takeUntil)(this._unsubscribeAll)).subscribe({
      next: response => {
        if (response.success && response.data) {
          this.totalUsers = response.data.totalUsers || 0;
          this.totalStaff = response.data.totalStaff || 0;
          this.totalAdmins = response.data.totalAdmins || 0;
        }
      },
      error: error => {
        console.error('Error fetching staff counts:', error);
        this.totalUsers = 0;
        this.totalStaff = 0;
        this.totalAdmins = 0;
      }
    });
  }
  filterData(event) {
    if (event.filterName == 'Enrolled Students' && event.filterType == 'Upcoming') {
      this.router.navigate(['/myschool/student'], {
        queryParams: {
          value: 'enrolledButNotStarted'
        }
      });
    } else if (event.filterName == 'Enrolled Students' && event.filterType == 'Active') {
      this.router.navigateByUrl('/myschool/student');
    }
  }
  static #_ = this.ɵfac = function StaffCountCardComponent_Factory(t) {
    return new (t || StaffCountCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_staff_service__WEBPACK_IMPORTED_MODULE_0__.StaffService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: StaffCountCardComponent,
    selectors: [["app-staff-count-card"]],
    inputs: {
      isRefreshCount: "isRefreshCount"
    },
    outputs: {
      filterChanged: "filterChanged"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵNgOnChangesFeature"]],
    decls: 22,
    vars: 3,
    consts: [[1, "grid", "nested-grid", "pl-0"], [1, "col-12", "xl:col-8", "lg:col-8", "md:col-12", "sm:col-12", "w-full"], [1, "flex", "flex-wrap", "w-full", "gap-2", "justify-content-between", "align-items-center"], [1, "flex", "flex-wrap", "gap-2"], [2, "width", "173px", "height", "77px"], [1, "flex", "align-items-center", "justify-content-between", "p-3", "border-round-xl", "border", 2, "height", "100%", "background", "var(--White-colour, #ffffff)", "border", "1px solid rgba(22, 40, 49, 0.1)"], [1, "font-semibold", "text-sm", "text-left", 2, "color", "rgba(65, 65, 78, 0.8)", "max-width", "100px"], [1, "text-lg", "font-semibold", "text-right", "count-text-color", 2, "cursor", "pointer", 3, "click"]],
    template: function StaffCountCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, " Total Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function StaffCountCardComponent_Template_span_click_8_listener() {
          return ctx.onCardClick("ALL");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "div", 4)(11, "div", 5)(12, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](13, " Staff ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function StaffCountCardComponent_Template_span_click_14_listener() {
          return ctx.onCardClick("STAFF");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div", 4)(17, "div", 5)(18, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](19, " Administrators ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function StaffCountCardComponent_Template_span_click_20_listener() {
          return ctx.onCardClick("ADMIN");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", ctx.totalUsers, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", ctx.totalStaff, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", ctx.totalAdmins, " ");
      }
    },
    styles: [".count-text-color[_ngcontent-%COMP%] {\n  color: #5978F7;\n  font-weight: 700 !important;\n  font-size: 20px !important;\n}\n\n.count-card[_ngcontent-%COMP%] {\n  background-color: white;\n  min-height: 10vh; \n\n  height: auto; \n\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvc3RhZmYvc3RhZmYtY291bnQtY2FyZHMvc3RhZmYtY291bnQtY2FyZHMuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi9OZXclMjBmb2xkZXIvdmdzY2hvb2wtdGhlbWUvc3JjL2FwcC9tb2R1bGVzL2FwcC9zdGFmZi9zdGFmZi1jb3VudC1jYXJkcy9zdGFmZi1jb3VudC1jYXJkcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBRTtFQUNFLGNBQUE7RUFDQSwyQkFBQTtFQUNBLDBCQUFBO0FDQ0o7O0FEQ0U7RUFDRSx1QkFBQTtFQUNBLGdCQUFBLEVBQUEseUNBQUE7RUFDQSxZQUFBLEVBQUEseURBQUE7QUNFSiIsInNvdXJjZXNDb250ZW50IjpbIiAgLmNvdW50LXRleHQtY29sb3J7XHJcbiAgICBjb2xvcjogIzU5NzhGNztcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDAgIWltcG9ydGFudDtcclxuICAgIGZvbnQtc2l6ZTogMjBweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICAuY291bnQtY2FyZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZjtcclxuICAgIG1pbi1oZWlnaHQ6IDEwdmg7IC8qIEhlaWdodCBpcyAxMCUgb2YgdGhlIHZpZXdwb3J0IGhlaWdodCAqL1xyXG4gICAgaGVpZ2h0OiBhdXRvOyAvKiBBbGxvd3MgdGhlIGNvbnRlbnQgdG8gZGV0ZXJtaW5lIHRoZSBoZWlnaHQgaWYgbmVlZGVkICovXHJcbn0iLCIuY291bnQtdGV4dC1jb2xvciB7XG4gIGNvbG9yOiAjNTk3OEY3O1xuICBmb250LXdlaWdodDogNzAwICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMjBweCAhaW1wb3J0YW50O1xufVxuXG4uY291bnQtY2FyZCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBtaW4taGVpZ2h0OiAxMHZoOyAvKiBIZWlnaHQgaXMgMTAlIG9mIHRoZSB2aWV3cG9ydCBoZWlnaHQgKi9cbiAgaGVpZ2h0OiBhdXRvOyAvKiBBbGxvd3MgdGhlIGNvbnRlbnQgdG8gZGV0ZXJtaW5lIHRoZSBoZWlnaHQgaWYgbmVlZGVkICovXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 59643:
/*!***********************************************************!*\
  !*** ./src/app/modules/app/staff/staff-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StaffRoutingModule: () => (/* binding */ StaffRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _staff_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./staff.component */ 17764);
/* harmony import */ var src_app_core_classroom_classroom_shared_resolver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/classroom/classroom-shared.resolver */ 40226);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61699);





class StaffRoutingModule {
  static #_ = this.ɵfac = function StaffRoutingModule_Factory(t) {
    return new (t || StaffRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
    type: StaffRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild([{
      path: '',
      component: _staff_component__WEBPACK_IMPORTED_MODULE_0__.StaffComponent,
      pathMatch: 'full',
      data: {
        breadcrumb: ''
      },
      resolve: {
        classrooms: src_app_core_classroom_classroom_shared_resolver__WEBPACK_IMPORTED_MODULE_1__.classroomsResolver
      }
    }]), _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](StaffRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
})();

/***/ }),

/***/ 17764:
/*!******************************************************!*\
  !*** ./src/app/modules/app/staff/staff.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StaffComponent: () => (/* binding */ StaffComponent)
/* harmony export */ });
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/api */ 98026);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var src_app_core_classroom_classroom_shared_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/classroom/classroom-shared.service */ 20823);
/* harmony import */ var _staff_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./staff.service */ 74975);
/* harmony import */ var src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/school/school.service */ 62915);
/* harmony import */ var src_app_demo_service_product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/demo/service/product.service */ 20981);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/tooltip */ 31251);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/calendar */ 57411);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/dropdown */ 94553);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/multiselect */ 77524);
/* harmony import */ var _staff_count_cards_staff_count_cards_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./staff-count-cards/staff-count-cards.component */ 40957);























function StaffComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 31)(1, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "i", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "input", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("input", function StaffComponent_ng_template_14_Template_input_input_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](13);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r9.onGlobalFilter(_r0, $event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "p-calendar", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function StaffComponent_ng_template_14_Template_p_calendar_ngModelChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r10);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r11.dateRange = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StaffComponent_ng_template_14_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r10);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](13);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r12.clearFilters(_r0));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngModel", ctx_r1.dateRange)("showIcon", true)("showOnFocus", false)("readonlyInput", true)("appendTo", "body");
  }
}
function StaffComponent_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "th", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "p-sortIcon", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "th", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5, " Classrooms ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "p-sortIcon", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "th", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, " Role ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "p-sortIcon", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "th", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](11, " Requests Pending ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](12, "p-sortIcon", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "th", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](14, " Requests Completed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](15, "p-sortIcon", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "th", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](17, " Consumptions ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](18, "p-sortIcon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](19, "th", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
}
function StaffComponent_ng_template_16_span_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const staffWithRequest_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("pTooltip", ctx_r14.getAllowedClassroomNames(staffWithRequest_r13.staff.allowedClassroomCodes));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" +", staffWithRequest_r13.staff.allowedClassroomCodes.length, " ");
  }
}
const _c0 = () => ({
  "min-width": "24px",
  width: "24px",
  height: "24px",
  padding: "0"
});
function StaffComponent_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td")(4, "div", 50)(5, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](9, StaffComponent_ng_template_16_span_9_Template, 2, 2, "span", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "i", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StaffComponent_ng_template_16_Template_i_click_10_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r19);
      const staffWithRequest_r13 = restoredCtx.$implicit;
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r18.openClassroomDialog(staffWithRequest_r13.staff));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "td", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "td", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "td", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "td", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](19, "td", 56)(20, "button", 57, 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StaffComponent_ng_template_16_Template_button_click_20_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r19);
      const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](23);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](_r16.toggle($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](22, "p-menu", 59, 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const staffWithRequest_r13 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate2"](" ", staffWithRequest_r13.staff.firstName, " ", staffWithRequest_r13.staff.lastName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleProp"]("background-color", ctx_r3.getInitialBgColor(ctx_r3.getClassroomName(staffWithRequest_r13.staff.primaryClassroomCode)));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r3.getClassroomInitials(ctx_r3.getClassroomName(staffWithRequest_r13.staff.primaryClassroomCode)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r3.getClassroomName(staffWithRequest_r13.staff.primaryClassroomCode), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", staffWithRequest_r13.staff.allowedClassroomCodes == null ? null : staffWithRequest_r13.staff.allowedClassroomCodes.length);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", staffWithRequest_r13.staff.role, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", staffWithRequest_r13.stockRequests.requestPending, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", staffWithRequest_r13.stockRequests.requestCompleted, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", staffWithRequest_r13.stockRequests.consumption, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](16, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("popup", true)("model", ctx_r3.getActionItems(staffWithRequest_r13.staff))("appendTo", "body");
  }
}
function StaffComponent_ng_template_17_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "i", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "span", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, "Loading staff members...");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
}
function StaffComponent_ng_template_17_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "i", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "span", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, "No staff members available");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "span", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4, " Add new staff members using the 'Add User' button ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td", 62)(2, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](3, StaffComponent_ng_template_17_ng_container_3_Template, 4, 0, "ng-container", 64)(4, StaffComponent_ng_template_17_ng_template_4_Template, 5, 0, "ng-template", null, 65, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](5);
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r4.isStaffLoading)("ngIfElse", _r23);
  }
}
function StaffComponent_ng_template_19_small_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " First name is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_19_small_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Last name is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_19_small_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Enter a valid email. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_19_small_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Enter a valid phone number. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_19_small_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Role is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_19_small_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Select at least one classroom. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_19_small_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Primary classroom is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_19_small_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Primary classroom must be one of the allowed classrooms. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
const _c1 = () => ({
  height: "33px",
  border: "1px solid #57335366",
  borderRadius: "8px"
});
function StaffComponent_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "form", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngSubmit", function StaffComponent_ng_template_19_Template_form_ngSubmit_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r33);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r32.saveStaff());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 72)(2, "label", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, "First Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "input", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, StaffComponent_ng_template_19_small_5_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 72)(7, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, "Last Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "input", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](10, StaffComponent_ng_template_19_small_10_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "div", 78)(12, "label", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, "Email");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](14, "input", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](15, StaffComponent_ng_template_19_small_15_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "div", 81)(17, "label", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](18, "Phone Number");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](19, "input", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](20, StaffComponent_ng_template_19_small_20_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "div", 81)(22, "label", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](23, "Role");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](24, "p-dropdown", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, StaffComponent_ng_template_19_small_25_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div", 86)(27, "label", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "Allowed Classrooms");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](29, "p-multiSelect", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](30, StaffComponent_ng_template_19_small_30_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "div", 86)(32, "label", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](33, "Primary Classroom");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](34, "p-dropdown", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](35, StaffComponent_ng_template_19_small_35_Template, 2, 0, "small", 75)(36, StaffComponent_ng_template_19_small_36_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](37, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](38, "button", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    let tmp_2_0;
    let tmp_4_0;
    let tmp_5_0;
    let tmp_7_0;
    let tmp_10_0;
    let tmp_13_0;
    let tmp_16_0;
    let tmp_17_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx_r5.userForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](27, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_2_0 = ctx_r5.userForm.get("firstName")) == null ? null : tmp_2_0.touched) && ((tmp_2_0 = ctx_r5.userForm.get("firstName")) == null ? null : tmp_2_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](28, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_4_0 = ctx_r5.userForm.get("lastName")) == null ? null : tmp_4_0.touched) && ((tmp_4_0 = ctx_r5.userForm.get("lastName")) == null ? null : tmp_4_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_5_0 = ctx_r5.userForm.get("email")) == null ? null : tmp_5_0.touched) && ((tmp_5_0 = ctx_r5.userForm.get("email")) == null ? null : tmp_5_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](29, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_7_0 = ctx_r5.userForm.get("phoneNumber")) == null ? null : tmp_7_0.touched) && ((tmp_7_0 = ctx_r5.userForm.get("phoneNumber")) == null ? null : tmp_7_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](30, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r5.roles);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_10_0 = ctx_r5.userForm.get("role")) == null ? null : tmp_10_0.touched) && ((tmp_10_0 = ctx_r5.userForm.get("role")) == null ? null : tmp_10_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](31, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r5.classrooms);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_13_0 = ctx_r5.userForm.get("allowedClassroomCodes")) == null ? null : tmp_13_0.touched) && ((tmp_13_0 = ctx_r5.userForm.get("allowedClassroomCodes")) == null ? null : tmp_13_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](32, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r5.filteredClassrooms);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_16_0 = ctx_r5.userForm.get("primaryClassroomCode")) == null ? null : tmp_16_0.touched) && ((tmp_16_0 = ctx_r5.userForm.get("primaryClassroomCode")) == null ? null : tmp_16_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (ctx_r5.userForm.errors == null ? null : ctx_r5.userForm.errors["primaryNotAllowed"]) && ((tmp_17_0 = ctx_r5.userForm.get("primaryClassroomCode")) == null ? null : tmp_17_0.touched));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("label", ctx_r5.submitted ? "" : "Add")("icon", ctx_r5.submitted ? "pi pi-spinner pi-spin" : "")("disabled", ctx_r5.userForm.invalid);
  }
}
function StaffComponent_ng_template_21_small_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " First name is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_21_small_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Last name is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_21_small_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Enter a valid email. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_21_small_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Enter a valid 10-digit phone number. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_21_small_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Role is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_21_small_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Select at least one classroom. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_21_small_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Primary classroom is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "form", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngSubmit", function StaffComponent_ng_template_21_Template_form_ngSubmit_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r42);
      const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r41.updateStaff());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 72)(2, "label", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, "First Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "input", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, StaffComponent_ng_template_21_small_5_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 72)(7, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, "Last Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "input", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](10, StaffComponent_ng_template_21_small_10_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "div", 78)(12, "label", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, "Email");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](14, "input", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](15, StaffComponent_ng_template_21_small_15_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "div", 72)(17, "label", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](18, "Phone Number");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](19, "input", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](20, StaffComponent_ng_template_21_small_20_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "div", 72)(22, "label", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](23, "Role");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](24, "p-dropdown", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, StaffComponent_ng_template_21_small_25_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div", 86)(27, "label", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "Allowed Classrooms");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](29, "p-multiSelect", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](30, StaffComponent_ng_template_21_small_30_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "div", 95)(32, "label", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](33, "Primary Classroom");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](34, "p-dropdown", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](35, StaffComponent_ng_template_21_small_35_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](36, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](37, "button", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    let tmp_2_0;
    let tmp_4_0;
    let tmp_6_0;
    let tmp_8_0;
    let tmp_11_0;
    let tmp_14_0;
    let tmp_17_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx_r6.userForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](28, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_2_0 = ctx_r6.userForm.get("firstName")) == null ? null : tmp_2_0.touched) && ((tmp_2_0 = ctx_r6.userForm.get("firstName")) == null ? null : tmp_2_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](29, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_4_0 = ctx_r6.userForm.get("lastName")) == null ? null : tmp_4_0.touched) && ((tmp_4_0 = ctx_r6.userForm.get("lastName")) == null ? null : tmp_4_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](30, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_6_0 = ctx_r6.userForm.get("email")) == null ? null : tmp_6_0.touched) && ((tmp_6_0 = ctx_r6.userForm.get("email")) == null ? null : tmp_6_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](31, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_8_0 = ctx_r6.userForm.get("phoneNumber")) == null ? null : tmp_8_0.touched) && ((tmp_8_0 = ctx_r6.userForm.get("phoneNumber")) == null ? null : tmp_8_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](32, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r6.roles);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_11_0 = ctx_r6.userForm.get("role")) == null ? null : tmp_11_0.touched) && ((tmp_11_0 = ctx_r6.userForm.get("role")) == null ? null : tmp_11_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](33, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r6.classrooms);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_14_0 = ctx_r6.userForm.get("allowedClassroomCodes")) == null ? null : tmp_14_0.touched) && ((tmp_14_0 = ctx_r6.userForm.get("allowedClassroomCodes")) == null ? null : tmp_14_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](34, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r6.classrooms);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_17_0 = ctx_r6.userForm.get("primaryClassroomCode")) == null ? null : tmp_17_0.touched) && ((tmp_17_0 = ctx_r6.userForm.get("primaryClassroomCode")) == null ? null : tmp_17_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("label", ctx_r6.submitted ? "" : "Update")("icon", ctx_r6.submitted ? "pi pi-spinner pi-spin" : "")("disabled", ctx_r6.userForm.invalid || ctx_r6.userForm.pristine);
  }
}
function StaffComponent_ng_template_35_small_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Select at least one classroom. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StaffComponent_ng_template_35_small_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "small", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Primary classroom is required. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
const _c2 = () => ({
  height: "40px",
  border: "1px solid #57335366",
  borderRadius: "8px"
});
function StaffComponent_ng_template_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r46 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "form", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngSubmit", function StaffComponent_ng_template_35_Template_form_ngSubmit_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r46);
      const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r45.updateClassrooms());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 1)(2, "label", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, "Allowed Classrooms");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "p-multiSelect", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, StaffComponent_ng_template_35_small_5_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 1)(7, "label", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, "Primary Classroom");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "p-dropdown", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](10, StaffComponent_ng_template_35_small_10_Template, 2, 0, "small", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](12, "button", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    let tmp_3_0;
    let tmp_6_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx_r7.classroomForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](10, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r7.classrooms);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_3_0 = ctx_r7.classroomForm.get("allowedClassroomCodes")) == null ? null : tmp_3_0.touched) && ((tmp_3_0 = ctx_r7.classroomForm.get("allowedClassroomCodes")) == null ? null : tmp_3_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](11, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("options", ctx_r7.classrooms);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ((tmp_6_0 = ctx_r7.classroomForm.get("primaryClassroomCode")) == null ? null : tmp_6_0.touched) && ((tmp_6_0 = ctx_r7.classroomForm.get("primaryClassroomCode")) == null ? null : tmp_6_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", ctx_r7.classroomForm.invalid || ctx_r7.classroomForm.pristine);
  }
}
function StaffComponent_ng_template_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StaffComponent_ng_template_41_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r48);
      const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r47.deleteProductsDialog = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "button", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StaffComponent_ng_template_41_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r48);
      const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r49.confirmDeleteSelected());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
const _c3 = () => ["staff.firstName", "country.name", "representative.name", "status"];
const _c4 = () => [10, 20, 30];
const _c5 = () => ({
  width: "450px",
  overflow: "visible"
});
const _c6 = () => ({
  overflow: "visible"
});
const _c7 = () => ({
  width: "480px"
});
const _c8 = () => ({
  width: "450px"
});
class StaffComponent {
  toggleMenu(classroomName) {
    this.menuOpen = this.menuOpen === classroomName ? null : classroomName;
  }
  constructor(_classroomService, _staffService, _schoolService, productService, messageService, confirmationService, _formBuilder, _changeDetectorRef) {
    this._classroomService = _classroomService;
    this._staffService = _staffService;
    this._schoolService = _schoolService;
    this.productService = productService;
    this.messageService = messageService;
    this.confirmationService = confirmationService;
    this._formBuilder = _formBuilder;
    this._changeDetectorRef = _changeDetectorRef;
    this.roles = ['ADMIN', 'STAFF'];
    this.dateRange = null;
    this.school = {};
    this.staff = {};
    this.staffWithStockRequests = [];
    this.staffWithStockRequest = {};
    this.staffList = [];
    this.selectedstaff = {};
    this.selectedStaffWithRequests = {};
    this.isStaffLoading = true; // Add this property
    this.filteredStaffWithStockRequests = [];
    this.classrooms = [];
    this.filteredClassrooms = [];
    this.isRefreshCount = false;
    this.userDialog = false;
    this.editUserDialog = false;
    this.classroomDialog = false;
    this.deleteUserDialog = false;
    this.deleteProductsDialog = false;
    this.products = [];
    this.product = {};
    this.selectedProducts = [];
    this.submitted = false;
    this.cols = [];
    this.statuses = [];
    this.rowsPerPageOptions = [5, 10, 20];
    // Add these properties
    this.sortField = '';
    this.sortOrder = 1;
    this.menuOpen = null;
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------
  /**
   * On init
   */
  ngOnInit() {
    this.userForm = this._formBuilder.group({
      firstName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      lastName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      phoneNumber: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.pattern(/^(\+1\s?)?(\([2-9][0-9]{2}\)|[2-9][0-9]{2})[\s.-]?[0-9]{3}[\s.-]?[0-9]{4}$/)]],
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.email]],
      role: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      allowedClassroomCodes: [[], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      primaryClassroomCode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
    }, {
      validators: this.primaryClassroomInAllowedValidator
    });
    this.classroomForm = this._formBuilder.group({
      allowedClassroomCodes: [[], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      primaryClassroomCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
    });
    this.productService.getProducts().then(data => this.products = data);
    this.cols = [{
      field: 'name',
      header: 'Name'
    }, {
      field: 'classrooms',
      header: 'Classrooms'
    }, {
      field: 'role',
      header: 'Role'
    }, {
      field: 'requestsPending',
      header: 'Requests Pending'
    }, {
      field: 'requestsCompleted',
      header: 'Requests Completed'
    }, {
      field: 'consumptions',
      header: 'Consumptions'
    }];
    this.roles = [{
      label: 'Staff',
      value: 'STAFF'
    }, {
      label: 'Admin',
      value: 'ADMIN'
    }];
    // Subscribe to school updates
    this._schoolService.school$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this._unsubscribeAll)).subscribe(response => {
      if (response) {
        // Store the school data
        this.school = response;
        // Load staff members for this school if needed
        if (this.school.code) {
          this._staffService.getStaffsWithStokeRequestsBySchool(this.school.code).subscribe();
        }
        console.log('school', this.school);
      }
      // Mark for check
      this._changeDetectorRef.markForCheck();
    });
    // Get the brands
    this._classroomService.classrooms$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this._unsubscribeAll)).subscribe(classrooms => {
      console.log('classrooms', classrooms);
      // Update the classroom list
      // If the classrooms exist, assign them to the local variable
      if (classrooms) {
        this.classrooms = classrooms;
      }
      // Mark for check
      this._changeDetectorRef.markForCheck();
    });
    this._staffService.staffWithStockRequests$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this._unsubscribeAll)).subscribe(staffWithStockRequests => {
      // Update the staff list
      if (staffWithStockRequests) {
        this.staffWithStockRequests = staffWithStockRequests;
        this.filteredStaffWithStockRequests = staffWithStockRequests; // Show all by default
      }

      this.isStaffLoading = false;
      // Mark for check
      this._changeDetectorRef.markForCheck();
    });
    // Update filteredClassrooms whenever allowedClassroomCodes changes
    this.userForm.get('allowedClassroomCodes')?.valueChanges.subscribe(codes => {
      this.filteredClassrooms = this.classrooms.filter(c => c.code && codes?.includes(c.code));
      // Optionally reset primaryClassroomCode if not in allowed
      const primary = this.userForm.get('primaryClassroomCode')?.value;
      if (primary && !codes?.includes(primary)) {
        this.userForm.get('primaryClassroomCode')?.setValue(null);
      }
    });
    // Initialize filteredClassrooms on load
    const codes = this.userForm.get('allowedClassroomCodes')?.value || [];
    this.filteredClassrooms = this.classrooms.filter(c => codes.includes(c.code));
  }
  /**
   * On destroy
   */
  ngOnDestroy() {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------
  onStaffFilterChanged(type) {
    if (type === 'ALL') {
      this.filteredStaffWithStockRequests = this.staffWithStockRequests;
    } else if (type === 'STAFF') {
      this.filteredStaffWithStockRequests = this.staffWithStockRequests.filter(s => s.staff?.role === 'STAFF');
    } else if (type === 'ADMIN') {
      this.filteredStaffWithStockRequests = this.staffWithStockRequests.filter(s => s.staff?.role === 'ADMIN');
    }
  }
  // Custom validator function
  primaryClassroomInAllowedValidator(group) {
    const allowed = group.get('allowedClassroomCodes')?.value || [];
    const primary = group.get('primaryClassroomCode')?.value;
    if (primary && allowed && !allowed.includes(primary)) {
      return {
        primaryNotAllowed: true
      };
    }
    return null;
  }
  // Helper method to get classroom data from code
  getClassroomByCode(code) {
    return this.classrooms.find(classroom => classroom.code === code);
  }
  // Helper method to get classroom names for display
  getClassroomNames(codes) {
    return codes?.map(code => {
      const classroom = this.getClassroomByCode(code);
      return classroom?.name || code;
    }).join(', ') || '';
  }
  /**
   * Gets the classroom name from classroom code
   */
  getClassroomName(code) {
    if (!code) return '';
    const classroom = this.classrooms.find(c => c.code === code);
    return classroom?.name || code;
  }
  /**
   * Gets comma separated list of allowed classroom names
   */
  getAllowedClassroomNames(codes) {
    if (!codes?.length) return '';
    return codes.map(code => this.getClassroomName(code)).join('\n');
  }
  /**
   * Gets initials from classroom name
   * Examples:
   * "Pre School" -> "PS"
   * "Day-Care" -> "DC"
   * "Room 1A" -> "R"
   */
  getClassroomInitials(name) {
    if (!name) return '';
    // Split by space or hyphen and filter out numbers
    return name.split(/[\s-]+/).filter(word => /[a-zA-Z]/.test(word)).map(word => word.charAt(0).toUpperCase()).join('').substring(0, 2);
  }
  /**
   * Gets background color for classroom initials
   * Matches specific colors in name or returns a random color
   */
  getInitialBgColor(name) {
    const colorMap = {
      'orange': {
        bg: '#FDA758',
        text: '#FFFFFF'
      },
      'pink': {
        bg: '#F67EAF',
        text: '#FFFFFF'
      },
      'blue': {
        bg: '#80A3DC',
        text: '#FFFFFF'
      },
      'violet': {
        bg: '#9C84F',
        text: '#FFFFFF'
      },
      'purple': {
        bg: '#CB9AFC',
        text: '#FFFFFF'
      },
      'yellow': {
        bg: '#FDCD16',
        text: '#FFFFFF'
      }
    };
    // Convert name to lowercase for case-insensitive matching
    const lowercaseName = name.toLowerCase();
    // Check if classroom name contains any of the color names
    for (const [color, values] of Object.entries(colorMap)) {
      if (lowercaseName.includes(color)) {
        return values.bg;
      }
    }
    // If no color match found, return random color
    const colors = Object.values(colorMap);
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    return randomColor.bg;
  }
  getActionItems(staff) {
    return [{
      label: 'Edit',
      // icon: 'pi pi-pencil',
      command: () => {
        this.onEdit(staff);
      }
    }, {
      label: 'Delete',
      // icon: 'pi pi-trash',
      command: () => {
        this.deleteUser(staff);
      }
    }];
  }
  onEdit1(classroom) {
    console.log('Edit clicked for:', classroom);
    console.log('Edit clicked for:', classroom);
    // this.selectedClassroom = { ...classroom }; // Clone to avoid directly mutating the list
    // this.classroomName = classroom.name || '';
    // this.displayDialog = true;
  }

  hideEditDialog() {
    this.editUserDialog = false;
    this.userForm.reset();
    this.staff = {};
  }
  onEdit(staff) {
    this.staff = {
      ...staff
    };
    this.userForm.patchValue({
      firstName: staff.firstName,
      lastName: staff.lastName,
      email: staff.email,
      phoneNumber: staff.phoneNumber,
      role: staff.role,
      allowedClassroomCodes: staff.allowedClassroomCodes,
      primaryClassroomCode: staff.primaryClassroomCode
    });
    this.editUserDialog = true;
    // Set initial dialog height
    setTimeout(() => {
      const dialog = document.querySelector('.p-dialog-content');
      if (dialog) {
        dialog.style.maxHeight = 'none';
      }
    });
  }
  updateStaff() {
    if (this.userForm.valid && this.staff.code) {
      const updatedStaff = {
        ...this.userForm.getRawValue(),
        code: this.staff.code,
        schoolCode: this.school.code,
        status: this.staff.status
      };
      this.submitted = true;
      this._staffService.updateStaff(updatedStaff).subscribe({
        next: response => {
          if (response.success) {
            // Update the row in staffWithStockRequests array
            const index = this.staffWithStockRequests.findIndex(item => item.staff?.code === updatedStaff.code);
            if (index !== -1) {
              this.staffWithStockRequests[index] = {
                ...this.staffWithStockRequests[index],
                staff: response.data
              };
            }
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Staff member updated successfully'
            });
            this.submitted = false;
            this.hideEditDialog();
          } else {
            this.submitted = false;
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: response.message
            });
          }
        },
        error: error => {
          this.submitted = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to update staff member'
          });
        }
      });
    }
  }
  /**
   * Opens classroom dialog for editing
   */
  openClassroomDialog(staff) {
    this.staff = {
      ...staff
    };
    // Set form values
    this.classroomForm.patchValue({
      allowedClassroomCodes: staff.allowedClassroomCodes || [],
      primaryClassroomCode: staff.primaryClassroomCode || ''
    });
    this.classroomDialog = true;
  }
  onSubmit() {
    if (this.userForm.valid) {
      console.log(this.userForm.value);
    } else {
      this.userForm.markAllAsTouched();
    }
  }
  saveStaff() {
    if (this.userForm.valid) {
      this.submitted = true;
      const newStaff = this.userForm.getRawValue();
      newStaff.schoolCode = this.school.code;
      newStaff.status = 'ACTIVE';
      this._staffService.createStaff(newStaff).subscribe({
        next: response => {
          if (response.success) {
            // Show success message
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Staff member created successfully'
            });
            // Reset form
            this.userForm.reset();
            // Close dialog
            this.userDialog = false;
            // Mark as not submitted
            this.submitted = false;
            this.isRefreshCount = true;
            setTimeout(() => this.isRefreshCount = false, 0);
          } else {
            this.submitted = false;
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: response.message
            });
          }
        },
        error: error => {
          this.submitted = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message
          });
        }
      });
    } else {
      // Mark all fields as touched to trigger validation messages
      this.userForm.markAllAsTouched();
    }
  }
  resetForm() {
    this.userForm.reset();
  }
  createNewUser() {
    this.staff = {};
    this.submitted = false;
    this.userDialog = true;
    // Set initial dialog height
    setTimeout(() => {
      const dialog = document.querySelector('.p-dialog-content');
      if (dialog) {
        dialog.style.maxHeight = 'none';
      }
    });
  }
  deleteUser(staff) {
    this.deleteUserDialog = true;
    this.staff = {
      ...staff
    };
  }
  deleteSelectedProducts() {
    this.deleteProductsDialog = true;
  }
  editProduct(product) {
    this.product = {
      ...product
    };
    this.userDialog = true;
  }
  confirmDeleteSelected() {
    this.deleteProductsDialog = false;
    this.products = this.products.filter(val => !this.selectedProducts.includes(val));
    this.messageService.add({
      severity: 'success',
      summary: 'Successful',
      detail: 'Products Deleted',
      life: 3000
    });
    this.selectedProducts = [];
  }
  /**
   * Confirms and executes staff deletion
   */
  confirmDelete() {
    if (this.staff?.code) {
      this.submitted = true;
      this._staffService.deleteStaff(this.staff.code).subscribe({
        next: response => {
          if (response.success) {
            // Close dialog
            this.deleteUserDialog = false;
            // Clear selected staff
            this.filteredStaffWithStockRequests = this.filteredStaffWithStockRequests.filter(val => val.staff?.code !== this.staff.code);
            this.staffWithStockRequests = this.staffWithStockRequests.filter(val => val.staff?.code !== this.staff.code);
            // Show success message
            this.messageService.add({
              severity: 'success',
              summary: 'Successful',
              detail: 'Staff member deleted successfully',
              life: 3000
            });
            this.isRefreshCount = true;
            setTimeout(() => this.isRefreshCount = false, 0);
          } else {
            this.submitted = false;
            // Show error message from API
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: response.message,
              life: 3000
            });
          }
        },
        error: error => {
          // Show error message
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to delete staff member',
            life: 3000
          });
        }
      });
    }
  }
  hideDialog() {
    this.userDialog = false;
    this.submitted = false;
  }
  /**
  * Updates staff classrooms
  */
  updateClassrooms() {
    if (this.classroomForm.valid && this.staff?.code) {
      const updatedStaff = {
        ...this.staff,
        allowedClassroomCodes: this.classroomForm.get('allowedClassroomCodes')?.value,
        primaryClassroomCode: this.classroomForm.get('primaryClassroomCode')?.value
      };
      this._staffService.updateStaff(updatedStaff).subscribe({
        next: response => {
          if (response.success) {
            // Update the row in staffWithStockRequests array
            const index = this.staffWithStockRequests.findIndex(item => item.staff?.code === updatedStaff.code);
            if (index !== -1) {
              this.staffWithStockRequests[index] = {
                ...this.staffWithStockRequests[index],
                staff: response.data
              };
            }
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Classrooms updated successfully'
            });
            this.hideClassroomDialog();
          } else {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: response.message
            });
          }
        },
        error: error => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to update classrooms'
          });
        }
      });
    }
  }
  /**
   * Hides classroom dialog
   */
  hideClassroomDialog() {
    this.classroomDialog = false;
    this.classroomForm.reset();
    this.staff = {};
  }
  onDelete(classroomName) {
    console.log('Delete clicked for:', classroomName);
    // this.displayDeleteDialog = true;
    // this.selectedClassroomName = classroomName.name;
  }

  findIndexById(id) {
    let index = -1;
    for (let i = 0; i < this.products.length; i++) {
      if (this.products[i].id === id) {
        index = i;
        break;
      }
    }
    return index;
  }
  createId() {
    let id = '';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < 5; i++) {
      id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return id;
  }
  onGlobalFilter(table, event) {
    table.filterGlobal(event.target.value, 'contains');
  }
  clearFilters(table) {
    this.dateRange = null;
    table.clear();
  }
  /**
   * Handles table sort
   */
  onSort(event) {
    this.sortField = event.field;
    this.sortOrder = event.order;
    this.staffWithStockRequests.sort((a, b) => {
      let valueA = this.getPropertyValue(a, event.field);
      let valueB = this.getPropertyValue(b, event.field);
      if (valueA == null) return this.sortOrder;
      if (valueB == null) return -this.sortOrder;
      if (typeof valueA === 'string') {
        return valueA.localeCompare(valueB) * this.sortOrder;
      }
      return (valueA - valueB) * this.sortOrder;
    });
  }
  /**
   * Gets nested property value using dot notation
   */
  getPropertyValue(obj, path) {
    return path.split('.').reduce((o, i) => o?.[i], obj);
  }
  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index, item) {
    return item.id || index;
  }
  static #_ = this.ɵfac = function StaffComponent_Factory(t) {
    return new (t || StaffComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_classroom_classroom_shared_service__WEBPACK_IMPORTED_MODULE_0__.ClassroomSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_staff_service__WEBPACK_IMPORTED_MODULE_1__.StaffService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_2__.SchoolSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_demo_service_product_service__WEBPACK_IMPORTED_MODULE_3__.ProductService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_9__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: StaffComponent,
    selectors: [["ng-component"]],
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵProvidersFeature"]([primeng_api__WEBPACK_IMPORTED_MODULE_9__.MessageService, primeng_api__WEBPACK_IMPORTED_MODULE_9__.ConfirmationService])],
    decls: 42,
    vars: 51,
    consts: [[1, "grid"], [1, "col-12"], [1, "flex", "align-items-center", "justify-content-start", "mb-3"], [2, "color", "#573353 !important", "line-height", "14px", "font-size", "16px !important"], [1, "flex", "justify-content-between", "align-items-center", "flex-wrap", "w-full"], [3, "isRefreshCount", "filterChanged"], ["pButton", "", 1, "flex", "align-items-center", "gap-2", "border-none", 2, "width", "136px", "height", "40px", "border-radius", "12px", "padding-left", "8px", "padding-right", "16px", "background", "linear-gradient(\n                        90deg,\n                        #5978f7 0%,\n                        #9c84ff 100%\n                    )", "color", "white", "font-weight", "500", "margin-left", "auto", 3, "click"], [1, "pi", "pi-plus", 2, "margin-right", "6px"], [1, "card", "px-3"], ["responsiveLayout", "scroll", "currentPageReportTemplate", "Showing {first} to {last} of {totalRecords} entries", "selectionMode", "multiple", "dataKey", "id", 3, "value", "columns", "rows", "globalFilterFields", "paginator", "rowsPerPageOptions", "showCurrentPageReport", "selection", "rowHover", "sortField", "sortOrder", "selectionChange", "onSort"], ["dt", ""], ["pTemplate", "caption"], ["pTemplate", "header"], ["pTemplate", "body"], ["pTemplate", "emptymessage"], ["header", "Add User", 1, "p-fluid", "user-dialog", 3, "visible", "contentStyle", "modal", "visibleChange"], ["pTemplate", "content"], ["header", "Edit User", 1, "p-fluid", "user-dialog", 3, "visible", "contentStyle", "modal", "visibleChange"], ["header", "Delete User", "styleClass", "delete-dialog", 3, "visible", "modal", "showHeader", "visibleChange"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", "gap-3"], [1, "delete-icon-container"], [1, "pi", "pi-trash"], [1, "delete-message", "text-center"], [1, "flex", "align-items-center", "gap-2", "mt-4"], ["pButton", "", "pRipple", "", "label", "Cancel", 1, "p-button-outlined", "cancel-button", 3, "click"], ["pButton", "", "pRipple", "", 1, "delete-confirm-button", 3, "label", "icon", "click"], ["header", "Edit Classrooms", 1, "p-fluid", "classroom-dialog", 3, "visible", "contentStyle", "modal", "visibleChange"], ["header", "Confirm", 3, "visible", "modal", "visibleChange"], [1, "flex", "align-items-center", "justify-content-center"], [1, "pi", "pi-exclamation-triangle", "mr-3", 2, "font-size", "2rem"], ["pTemplate", "footer"], [1, "flex", "flex-column", "md:flex-row", "md:align-items-center", "gap-5"], [1, "block", "mt-2", "md:mt-0", "p-input-icon-left"], [1, "pi", "pi-search"], ["pInputText", "", "type", "text", "placeholder", "Search...", 1, "w-full", "sm:w-auto", 3, "input"], ["selectionMode", "range", "dateFormat", "mm/dd/yy", "placeholder", "Select date range", 1, "custom-calendar", 3, "ngModel", "showIcon", "showOnFocus", "readonlyInput", "appendTo", "ngModelChange"], ["pButton", "", "type", "button", "label", "Clear", 1, "p-button-secondary", "clear-button", 3, "click"], ["pSortableColumn", "staff.firstName", 2, "min-width", "191px", "border-top-left-radius", "8px"], ["field", "staff.firstName"], ["pSortableColumn", "staff.primaryClassroomCode", 2, "min-width", "228px"], ["field", "staff.primaryClassroomCode"], ["pSortableColumn", "staff.role", 2, "min-width", "156px"], ["field", "staff.role"], ["pSortableColumn", "requestsPending", 2, "min-width", "165px"], ["field", "requestsPending"], ["pSortableColumn", "requestsCompleted", 2, "min-width", "178px"], ["field", "requestsCompleted"], ["pSortableColumn", "consumptions", 2, "min-width", "167px"], ["field", "consumptions"], [2, "width", "10%", "border-top-right-radius", "8px"], [1, "flex", "gap-2", "font-medium", "align-items-center"], [1, "classroom-initial"], [1, "classroom-count-wrapper"], ["class", "classroom-count", "tooltipPosition", "top", 3, "pTooltip", 4, "ngIf"], ["pTooltip", "Edit Classrooms", "tooltipPosition", "top", 1, "pi", "pi-pencil", "edit-icon", 3, "click"], [1, "text-center"], [1, "table-cell"], ["type", "button", "pButton", "", "icon", "pi pi-ellipsis-v", 1, "p-button-text", "p-button-plain", "action-button", 3, "click"], ["menuButton", ""], ["styleClass", "custom-action-menu", 3, "popup", "model", "appendTo"], ["menu", ""], ["tooltipPosition", "top", 1, "classroom-count", 3, "pTooltip"], ["colspan", "7"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", 2, "padding", "2rem"], [4, "ngIf", "ngIfElse"], ["noStaff", ""], [1, "pi", "pi-spin", "pi-spinner", 2, "font-size", "2.5rem", "color", "#5978f7", "margin-bottom", "1rem"], [2, "font-size", "1.1rem", "color", "#666"], [1, "pi", "pi-users", 2, "font-size", "3rem", "color", "#ccc", "margin-bottom", "1rem"], [2, "font-size", "1.2rem", "color", "#666"], [2, "color", "#888", "margin-top", "0.5rem"], [1, "p-fluid", "p-formgrid", "grid", 3, "formGroup", "ngSubmit"], [1, "col-12", "md:col-6", "pb-0"], ["for", "firstName"], ["pInputText", "", "id", "firstName", "formControlName", "firstName"], ["class", "p-error", 4, "ngIf"], ["for", "lastName"], ["pInputText", "", "id", "lastName", "formControlName", "lastName"], [1, "col-12", "pb-0"], ["for", "email"], ["pInputText", "", "id", "email", "formControlName", "email", 2, "height", "33px", "border-radius", "8px", "border", "1px solid #57335366"], [1, "col-12", "md:col-6", "pb-1"], ["for", "phoneNumber"], ["pInputText", "", "id", "phoneNumber", "formControlName", "phoneNumber"], ["for", "role"], ["id", "role", "formControlName", "role", "placeholder", "Select Role", 3, "options"], [1, "col-12", "pb-1"], ["for", "allowedClassrooms"], ["id", "allowedClassrooms", "optionLabel", "name", "optionValue", "code", "formControlName", "allowedClassroomCodes", "placeholder", "Select Classrooms", 3, "options"], ["for", "primaryClassroom"], ["id", "primaryClassroom", "optionLabel", "name", "optionValue", "code", "formControlName", "primaryClassroomCode", "placeholder", "Select Primary Classroom", 3, "options"], [1, "col-12", "flex", "justify-content-center", "gap-2"], ["pButton", "", "type", "submit", 1, "add-button", "p-button", 3, "label", "icon", "disabled"], [1, "p-error"], ["pInputText", "", "id", "email", "formControlName", "email"], [1, "col-12", "pb-2"], ["pButton", "", "type", "submit", 1, "update-button", 3, "label", "icon", "disabled"], ["pButton", "", "type", "submit", "label", "Update", 1, "update-button", 3, "disabled"], ["pButton", "", "pRipple", "", "icon", "pi pi-times", "label", "No", 1, "p-button-text", 3, "click"], ["pButton", "", "pRipple", "", "icon", "pi pi-check", "label", "Yes", 1, "p-button-text", 3, "click"]],
    template: function StaffComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4, " Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "div", 4)(6, "app-staff-count-card", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("filterChanged", function StaffComponent_Template_app_staff_count_card_filterChanged_6_listener($event) {
          return ctx.onStaffFilterChanged($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StaffComponent_Template_button_click_7_listener() {
          return ctx.createNewUser();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](8, "i", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9, " Add User ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](11, "p-toast");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "p-table", 9, 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("selectionChange", function StaffComponent_Template_p_table_selectionChange_12_listener($event) {
          return ctx.selectedProducts = $event;
        })("onSort", function StaffComponent_Template_p_table_onSort_12_listener($event) {
          return ctx.onSort($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, StaffComponent_ng_template_14_Template, 6, 5, "ng-template", 11)(15, StaffComponent_ng_template_15_Template, 21, 0, "ng-template", 12)(16, StaffComponent_ng_template_16_Template, 24, 17, "ng-template", 13)(17, StaffComponent_ng_template_17_Template, 6, 2, "ng-template", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "p-dialog", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function StaffComponent_Template_p_dialog_visibleChange_18_listener($event) {
          return ctx.userDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, StaffComponent_ng_template_19_Template, 39, 33, "ng-template", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](20, "p-dialog", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function StaffComponent_Template_p_dialog_visibleChange_20_listener($event) {
          return ctx.editUserDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](21, StaffComponent_ng_template_21_Template, 38, 35, "ng-template", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](22, "p-dialog", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function StaffComponent_Template_p_dialog_visibleChange_22_listener($event) {
          return ctx.deleteUserDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "div", 19)(24, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](25, "i", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div", 22)(27, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "Do you want to delete this user -");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](30);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "div", 23)(32, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StaffComponent_Template_button_click_32_listener() {
          return ctx.deleteUserDialog = false;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](33, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StaffComponent_Template_button_click_33_listener() {
          return ctx.confirmDelete();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](34, "p-dialog", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function StaffComponent_Template_p_dialog_visibleChange_34_listener($event) {
          return ctx.classroomDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](35, StaffComponent_ng_template_35_Template, 13, 12, "ng-template", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](36, "p-dialog", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("visibleChange", function StaffComponent_Template_p_dialog_visibleChange_36_listener($event) {
          return ctx.deleteProductsDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](37, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](38, "i", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](39, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](40, "Are you sure you want to delete selected products?");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](41, StaffComponent_ng_template_41_Template, 2, 0, "ng-template", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("isRefreshCount", ctx.isRefreshCount);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", ctx.filteredStaffWithStockRequests)("columns", ctx.cols)("rows", 10)("globalFilterFields", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](41, _c3))("rows", 10)("paginator", true)("rowsPerPageOptions", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](42, _c4))("showCurrentPageReport", true)("selection", ctx.selectedProducts)("rowHover", true)("sortField", ctx.sortField)("sortOrder", ctx.sortOrder);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](43, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.userDialog)("contentStyle", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](44, _c6))("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](45, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.editUserDialog)("contentStyle", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](46, _c6))("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](47, _c7));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.deleteUserDialog)("modal", true)("showHeader", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate2"]("\"", ctx.staff == null ? null : ctx.staff.firstName, " ", ctx.staff == null ? null : ctx.staff.lastName, "\"?");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("label", ctx.submitted ? "" : "Delete")("icon", ctx.submitted ? "pi pi-spinner pi-spin" : "");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](48, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.classroomDialog)("contentStyle", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](49, _c6))("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](50, _c8));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("visible", ctx.deleteProductsDialog)("modal", true);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName, primeng_table__WEBPACK_IMPORTED_MODULE_11__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_9__.PrimeTemplate, primeng_table__WEBPACK_IMPORTED_MODULE_11__.SortableColumn, primeng_table__WEBPACK_IMPORTED_MODULE_11__.SortIcon, primeng_button__WEBPACK_IMPORTED_MODULE_12__.ButtonDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgModel, primeng_menu__WEBPACK_IMPORTED_MODULE_13__.Menu, primeng_tooltip__WEBPACK_IMPORTED_MODULE_14__.Tooltip, primeng_calendar__WEBPACK_IMPORTED_MODULE_15__.Calendar, primeng_ripple__WEBPACK_IMPORTED_MODULE_16__.Ripple, primeng_toast__WEBPACK_IMPORTED_MODULE_17__.Toast, primeng_inputtext__WEBPACK_IMPORTED_MODULE_18__.InputText, primeng_dropdown__WEBPACK_IMPORTED_MODULE_19__.Dropdown, primeng_dialog__WEBPACK_IMPORTED_MODULE_20__.Dialog, primeng_multiselect__WEBPACK_IMPORTED_MODULE_21__.MultiSelect, _staff_count_cards_staff_count_cards_component__WEBPACK_IMPORTED_MODULE_4__.StaffCountCardComponent],
    styles: ["\n\n.flex[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  \n\n}\n\n\n\n.search-input[_ngcontent-%COMP%] {\n  width: 246px;\n  \n\n  height: 40px;\n  \n\n  padding-left: 10px;\n  \n\n  border-radius: 4px;\n  \n\n}\n\n\n\n.clear-button[_ngcontent-%COMP%] {\n  width: 63px;\n  height: 23px;\n  gap: 6px;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 3px;\n  padding-top: 4px;\n  padding-right: 8px;\n  padding-bottom: 4px;\n  padding-left: 8px;\n}\n.clear-button[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n\n\n\n.clear-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  margin-right: 4px;\n  \n\n}\n\n  .add-button {\n  width: 11.5rem;\n  height: 3rem;\n  font-weight: 600;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 6px;\n  padding: 0.5rem 1rem;\n  transition: background 0.3s ease;\n  margin-bottom: 1rem;\n}\n  .add-button:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n  .add-button:disabled {\n  cursor: not-allowed !important;\n}\n\n.table-cell[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.action-container[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.plain-dots[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  cursor: pointer;\n  padding: 5px;\n}\n\n.custom-dropdown[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 100%;\n  background: white;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  border-radius: 4px;\n  z-index: 1000;\n}\n\n.dropdown-item[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  padding: 8px 16px;\n  border: none;\n  background: none;\n  text-align: left;\n  cursor: pointer;\n}\n.dropdown-item[_ngcontent-%COMP%]:hover {\n  background-color: #f5f5f5;\n}\n\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td {\n  background: #fff;\n  text-align: center;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i {\n  transition: color 0.2s;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i:hover {\n  color: #999 !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=role], [_nghost-%COMP%]     th[pSortableColumn=requestsPending], [_nghost-%COMP%]     th[pSortableColumn=requestsCompleted], [_nghost-%COMP%]     th[pSortableColumn=consumptions] {\n  text-align: center !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=role] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=requestsPending] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=requestsCompleted] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=consumptions] .p-sortable-column-icon {\n  margin-left: 4px;\n}\n\n[_nghost-%COMP%]     .custom-calendar .p-calendar {\n  min-width: 247px;\n  display: inline-flex;\n  position: relative;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar input {\n  width: 100%;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 8px 0 0 8px;\n  padding: 0.5rem;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger {\n  width: 40px;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 0 8px 8px 0;\n  color: #666;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:enabled:hover {\n  background: rgba(177, 175, 233, 0.1019607843);\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker {\n  min-width: 247px;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker.p-datepicker-inline {\n  position: absolute;\n  top: 100%;\n  left: 0;\n  z-index: 1000;\n}\n\n[_nghost-%COMP%]     .update-button {\n  width: 11.5rem;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .update-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .update-button:disabled {\n  opacity: 0.6;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  cursor: not-allowed;\n}\n\n.classroom-initial[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  background: #E6E8F3;\n  color: #FFFFFF;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.classroom-count[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 23px;\n  gap: 16px;\n  padding: 4px 8px;\n  border-radius: 3px;\n  background-color: rgba(217, 255, 203, 0.4);\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  color: #333333;\n}\n\n  .p-tooltip .p-tooltip-text {\n  background-color: #F0FFEA !important;\n  color: #333333 !important;\n  border: 1px solid #E6E6E6;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  font-size: 11px;\n}\n  .p-tooltip .p-tooltip-arrow {\n  border-top-color: #F0FFEA !important;\n}\n\n.classroom-count-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #6E6E6E;\n  cursor: pointer;\n  opacity: 0.7;\n  transition: opacity 0.2s;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%]:hover {\n  opacity: 1;\n}\n\n[_nghost-%COMP%]     .p-menu {\n  background: none !important;\n  border: none !important;\n  box-shadow: none !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay {\n  margin: 0;\n  padding: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu {\n  width: 73px !important;\n  min-height: 80px !important;\n  padding: 16px !important;\n  border-radius: 8px !important;\n  border: 1px solid #E6E6E6 !important;\n  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.05) !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu * {\n  background: #FFFFFF !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list {\n  gap: 16px;\n  display: flex;\n  flex-direction: column;\n  padding: 0;\n  margin: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem {\n  margin: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link {\n  padding: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link:hover .p-menuitem-text, [_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link:hover .p-menuitem-icon {\n  color: #5978F7 !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link .p-menuitem-icon {\n  font-size: 12px;\n  margin-right: 8px;\n  color: #6C757D !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link .p-menuitem-text {\n  font-size: 12px;\n  color: #495057 !important;\n}\n\n[_nghost-%COMP%]     .delete-dialog .p-dialog-content {\n  padding: 2rem;\n}\n[_nghost-%COMP%]     .delete-icon-container {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background-color: #D92D20;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 1rem;\n}\n[_nghost-%COMP%]     .delete-icon-container .pi-trash {\n  font-size: 24px;\n  color: #FFFFFF;\n}\n[_nghost-%COMP%]     .delete-message {\n  font-size: 14px;\n  color: #344054;\n  line-height: 1.5;\n}\n[_nghost-%COMP%]     .delete-message strong {\n  color: #101828;\n}\n\n[_nghost-%COMP%]     .delete-confirm-button {\n  width: 177px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .delete-confirm-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .delete-confirm-button:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .cancel-button {\n  color: #6C757D;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n  color: #495057;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .cancel-button {\n  width: 177.21px;\n  height: 48px;\n  border-radius: 6.96px;\n  gap: 8.7px;\n  background: transparent;\n  position: relative;\n}\n[_nghost-%COMP%]     .cancel-button::before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  border-radius: 6.96px;\n  border: 1px solid transparent;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%) border-box;\n  -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);\n  -webkit-mask-composite: destination-out;\n  mask-composite: exclude;\n}\n[_nghost-%COMP%]     .cancel-button .p-button-label {\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n}\n[_nghost-%COMP%]     .cancel-button:hover::before {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%) border-box;\n}\n[_nghost-%COMP%]     .cancel-button:hover .p-button-label {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .p-dialog.p-fluid {\n  height: auto;\n}\n[_nghost-%COMP%]     .p-dialog.p-fluid .p-dialog-content {\n  overflow-y: visible;\n  overflow-x: hidden;\n  max-height: none !important;\n}\n[_nghost-%COMP%]     .p-dialog .p-fluid .grid {\n  row-gap: 1.5rem;\n}\n\n[_nghost-%COMP%]     .p-dropdown {\n  display: flex;\n  align-items: center;\n}\n[_nghost-%COMP%]     .p-dropdown .p-dropdown-label {\n  padding-top: 0;\n  padding-bottom: 0;\n  line-height: 31px;\n}\n[_nghost-%COMP%]     .p-dropdown .p-dropdown-trigger {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n}\n\n[_nghost-%COMP%]     .p-multiselect {\n  display: flex;\n  align-items: center;\n  height: 40px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvc3RhZmYvc3RhZmYuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi9OZXclMjBmb2xkZXIvdmdzY2hvb2wtdGhlbWUvc3JjL2FwcC9tb2R1bGVzL2FwcC9zdGFmZi9zdGFmZi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxtREFBQTtBQUNBO0VBQ0ksYUFBQTtFQUNBLFNBQUE7RUFDQSxrQ0FBQTtBQ0NKOztBREVBLHdCQUFBO0FBQ0E7RUFDSSxZQUFBO0VBQ0Esa0NBQUE7RUFDQSxZQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLDhDQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQ0FBQTtBQ0NKOztBRElBLCtCQUFBO0FBQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVEQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQ0RKO0FER0k7RUFDSSx1REFBQTtBQ0RSOztBREtBLDBDQUFBO0FBQ0E7RUFDSSxpQkFBQTtFQUNBLHVEQUFBO0FDRko7O0FET0k7RUFDSSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSx1REFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQ0FBQTtFQUNBLG1CQUFBO0FDSlI7QURNUTtFQUNJLHVEQUFBO0FDSlo7QURPUTtFQUVJLDhCQUFBO0FDTlo7O0FEWUE7RUFDSSxrQkFBQTtBQ1RKOztBRFlBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtBQ1RKOztBRFlBO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUNUSjs7QURZQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLHdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FDVEo7O0FEWUE7RUFDSSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDVEo7QURXSTtFQUNJLHlCQUFBO0FDVFI7O0FEZ0JZO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtBQ2JoQjtBRGVnQjtFQUNJLHNCQUFBO0FDYnBCO0FEZW9CO0VBQ0ksc0JBQUE7QUNieEI7QUR1Qkk7Ozs7RUFJSSw2QkFBQTtBQ3JCUjtBRHVCUTs7OztFQUNJLGdCQUFBO0FDbEJaOztBRDRCUTtFQUNJLGdCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQ3pCWjtBRDJCWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkNBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0FDekJoQjtBRDRCWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkNBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxXQUFBO0FDMUJoQjtBRDRCZ0I7RUFDSSw2Q0FBQTtBQzFCcEI7QUQ2QmdCO0VBQ0ksZ0JBQUE7QUMzQnBCO0FEZ0NRO0VBQ0ksZ0JBQUE7QUM5Qlo7QURnQ1k7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0VBQ0EsYUFBQTtBQzlCaEI7O0FEcUNJO0VBQ0ksY0FBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLDREQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDbENSO0FEb0NRO0VBQ0ksNERBQUE7QUNsQ1o7QURxQ1E7RUFDSSxZQUFBO0VBQ0EsNERBQUE7RUFDQSxtQkFBQTtBQ25DWjs7QUR3Q0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNyQ0o7O0FEd0NBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0VBQ0Esb0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUNyQ0o7O0FEeUNJO0VBQ0ksb0NBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0NBQUE7RUFDQSxlQUFBO0FDdENSO0FEeUNJO0VBQ0ksb0NBQUE7QUN2Q1I7O0FEMkNBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsUUFBQTtBQ3hDSjtBRDBDSTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSx3QkFBQTtBQ3hDUjtBRDBDUTtFQUNJLFVBQUE7QUN4Q1o7O0FEZ0RJO0VBQ0ksMkJBQUE7RUFDQSx1QkFBQTtFQUNBLDJCQUFBO0FDN0NSO0FEa0RRO0VBQ0ksU0FBQTtFQUNBLFVBQUE7QUNoRFo7QURrRFk7RUFDSSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0Esd0JBQUE7RUFDQSw2QkFBQTtFQUNBLG9DQUFBO0VBQ0Esc0RBQUE7QUNoRGhCO0FEa0RnQjtFQUNJLDhCQUFBO0FDaERwQjtBRG1EZ0I7RUFDSSxTQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7QUNqRHBCO0FEbURvQjtFQUNJLFNBQUE7QUNqRHhCO0FEbUR3QjtFQUNJLFVBQUE7QUNqRDVCO0FEcURnQzs7RUFFSSx5QkFBQTtBQ25EcEM7QUR1RDRCO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7QUNyRGhDO0FEd0Q0QjtFQUNJLGVBQUE7RUFDQSx5QkFBQTtBQ3REaEM7O0FEa0VRO0VBQ0ksYUFBQTtBQy9EWjtBRG1FSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNqRVI7QURtRVE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtBQ2pFWjtBRHFFSTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUNuRVI7QURxRVE7RUFDSSxjQUFBO0FDbkVaOztBRHlFSTtFQUNJLFlBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSw0REFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ3RFUjtBRHdFUTtFQUNJLDREQUFBO0FDdEVaO0FEeUVRO0VBQ0ksZ0JBQUE7QUN2RVo7QUQyRUk7RUFDSSxjQUFBO0FDekVSO0FEMkVRO0VBQ0ksdUJBQUE7RUFDQSxjQUFBO0FDekVaO0FENEVRO0VBQ0ksZ0JBQUE7QUMxRVo7O0FEZ0ZJO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0FDN0VSO0FEZ0ZRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLHFCQUFBO0VBQ0EsNkJBQUE7RUFDQSx1RUFBQTtFQUNBLDhFQUNJO0VBRUosdUNBQUE7RUFDQSx1QkFBQTtBQ2hGWjtBRG9GUTtFQUNJLDREQUFBO0VBQ0EsNkJBQUE7RUFDQSxxQkFBQTtFQUNBLG9DQUFBO0VBQ0EsZ0JBQUE7QUNsRlo7QURxRlE7RUFDSSx1QkFBQTtBQ25GWjtBRHFGWTtFQUNJLHVFQUFBO0FDbkZoQjtBRHNGWTtFQUNJLDREQUFBO0VBQ0EsNkJBQUE7RUFDQSxxQkFBQTtBQ3BGaEI7QUR3RlE7RUFDSSxnQkFBQTtBQ3RGWjs7QUQrRlE7RUFDSSxZQUFBO0FDNUZaO0FEOEZZO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0FDNUZoQjtBRHVHWTtFQUNJLGVBQUE7QUNyR2hCOztBRDZHSTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQzFHUjtBRDRHUTtFQUNJLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FDMUdaO0FENkdRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0FDM0daOztBRGdIQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUM3R0oiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBHZW5lcmFsIEZsZXggTGF5b3V0OiAxMnB4IGdhcCBiZXR3ZWVuIGNvbnRyb2xzICovXHJcbi5mbGV4IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBnYXA6IDEycHg7XHJcbiAgICAvKiAxMnB4IGdhcCBiZXR3ZWVuIGVhY2ggY29udHJvbCAqL1xyXG59XHJcblxyXG4vKiBTZWFyY2ggSW5wdXQgc3R5bGVzICovXHJcbi5zZWFyY2gtaW5wdXQge1xyXG4gICAgd2lkdGg6IDI0NnB4O1xyXG4gICAgLyogTWF0Y2hpbmcgdGhlIHdpZHRoIGZyb20gRmlnbWEgKi9cclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIC8qIE1hdGNoaW5nIHRoZSBoZWlnaHQgZnJvbSBGaWdtYSAqL1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgLyogT3B0aW9uYWw6IFNwYWNlIGJldHdlZW4gdGhlIGljb24gYW5kIHRleHQgKi9cclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIC8qIFJvdW5kZWQgY29ybmVycyBmb3IgdGhlIGlucHV0ICovXHJcbn1cclxuXHJcblxyXG5cclxuLyogQ2xlYXIgQnV0dG9uIGN1c3RvbSBzdHlsZXMgKi9cclxuLmNsZWFyLWJ1dHRvbiB7XHJcbiAgICB3aWR0aDogNjNweDtcclxuICAgIGhlaWdodDogMjNweDtcclxuICAgIGdhcDogNnB4O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpOyAvLyBJbmRpZ28gNTAwIHRvIDYwMFxyXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgcGFkZGluZy10b3A6IDRweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDhweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA0cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDhweDtcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0QjY4RTEsICM4QjZFRkYpOyAvLyBEYXJrZXIgb24gaG92ZXJcclxuICAgIH1cclxufVxyXG5cclxuLyogT3B0aW9uYWw6IFN0eWxlIGZvciB0aGUgYnV0dG9uJ3MgaWNvbiAqL1xyXG4uY2xlYXItYnV0dG9uIGkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbiAgICAvKiBBZGp1c3QgaWYgeW91IHdhbnQgc3BhY2UgYmV0d2VlbiB0aGUgaWNvbiBhbmQgdGV4dCAqL1xyXG59XHJcblxyXG5cclxuOjpuZy1kZWVwIHtcclxuICAgIC5hZGQtYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMTEuNXJlbTtcclxuICAgICAgICBoZWlnaHQ6IDNyZW07XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNTk3OEY3LCAjOUM4NEZGKTsgLy8gSW5kaWdvIDUwMCB0byA2MDBcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICAgICAgcGFkZGluZzogMC41cmVtIDFyZW07XHJcbiAgICAgICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjNzIGVhc2U7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzRCNjhFMSwgIzhCNkVGRik7IC8vIERhcmtlciBvbiBob3ZlclxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpkaXNhYmxlZCB7XHJcbiAgICAgICAgICAgIC8vIG9wYWNpdHk6IDAuNiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBjdXJzb3I6IG5vdC1hbGxvd2VkICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuLnRhYmxlLWNlbGwge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4uYWN0aW9uLWNvbnRhaW5lciB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuXHJcbi5wbGFpbi1kb3RzIHtcclxuICAgIGJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbn1cclxuXHJcbi5jdXN0b20tZHJvcGRvd24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICB6LWluZGV4OiAxMDAwO1xyXG59XHJcblxyXG4uZHJvcGRvd24taXRlbSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogOHB4IDE2cHg7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLnAtZGF0YXRhYmxlIHtcclxuICAgICAgICAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHtcclxuICAgICAgICAgICAgdGQge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbiAgICAgICAgICAgICAgICBpIHtcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBjb2xvciAwLjJzO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM5OTkgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRW5zdXJlIGhlYWRlciBjZWxscyBhcmUgYWxzbyBjZW50ZXJlZFxyXG4gICAgLy8gdGhbcFNvcnRhYmxlQ29sdW1uPVwibmFtZVwiXSxcclxuICAgIC8vIHRoW3BTb3J0YWJsZUNvbHVtbj1cImNsYXNzcm9vbXNcIl0sXHJcbiAgICB0aFtwU29ydGFibGVDb2x1bW49XCJyb2xlXCJdLFxyXG4gICAgdGhbcFNvcnRhYmxlQ29sdW1uPVwicmVxdWVzdHNQZW5kaW5nXCJdLFxyXG4gICAgdGhbcFNvcnRhYmxlQ29sdW1uPVwicmVxdWVzdHNDb21wbGV0ZWRcIl0sXHJcbiAgICB0aFtwU29ydGFibGVDb2x1bW49XCJjb25zdW1wdGlvbnNcIl0ge1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xyXG5cclxuICAgICAgICAucC1zb3J0YWJsZS1jb2x1bW4taWNvbiB7XHJcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiA0cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbn1cclxuXHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLmN1c3RvbS1jYWxlbmRhciB7XHJcbiAgICAgICAgLnAtY2FsZW5kYXIge1xyXG4gICAgICAgICAgICBtaW4td2lkdGg6IDI0N3B4O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgICAgICAgICAgaW5wdXQge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjQjFBRkU5MUE7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHggMCAwIDhweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAuNXJlbTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLnAtZGF0ZXBpY2tlci10cmlnZ2VyIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0IxQUZFOTFBO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMCA4cHggOHB4IDA7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzY2NjtcclxuXHJcbiAgICAgICAgICAgICAgICAmOmVuYWJsZWQ6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNCMUFGRTkxQTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAmOmZvY3VzIHtcclxuICAgICAgICAgICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAucC1kYXRlcGlja2VyIHtcclxuICAgICAgICAgICAgbWluLXdpZHRoOiAyNDdweDtcclxuXHJcbiAgICAgICAgICAgICYucC1kYXRlcGlja2VyLWlubGluZSB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICB0b3A6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICAgICAgei1pbmRleDogMTAwMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC51cGRhdGUtYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMTEuNXJlbTtcclxuICAgICAgICBoZWlnaHQ6IDQ4cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNi45NnB4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcclxuICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6ZGlzYWJsZWQge1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAwLjY7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcclxuICAgICAgICAgICAgY3Vyc29yOiBub3QtYWxsb3dlZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jbGFzc3Jvb20taW5pdGlhbCB7XHJcbiAgICB3aWR0aDogMjRweDtcclxuICAgIGhlaWdodDogMjRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGJhY2tncm91bmQ6ICNFNkU4RjM7XHJcbiAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4uY2xhc3Nyb29tLWNvdW50IHtcclxuICAgIHdpZHRoOiAzMnB4O1xyXG4gICAgaGVpZ2h0OiAyM3B4O1xyXG4gICAgZ2FwOiAxNnB4O1xyXG4gICAgcGFkZGluZzogNHB4IDhweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNEOUZGQ0I2NjtcclxuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICMzMzMzMzM7XHJcbn1cclxuXHJcbjo6bmctZGVlcCAucC10b29sdGlwIHtcclxuICAgIC5wLXRvb2x0aXAtdGV4dCB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0YwRkZFQSAhaW1wb3J0YW50O1xyXG4gICAgICAgIGNvbG9yOiAjMzMzMzMzICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNjtcclxuICAgICAgICBib3gtc2hhZG93OiAwIDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIH1cclxuXHJcbiAgICAucC10b29sdGlwLWFycm93IHtcclxuICAgICAgICBib3JkZXItdG9wLWNvbG9yOiAjRjBGRkVBICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5jbGFzc3Jvb20tY291bnQtd3JhcHBlciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGdhcDogOHB4O1xyXG5cclxuICAgIC5lZGl0LWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBjb2xvcjogIzZFNkU2RTtcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgb3BhY2l0eTogMC43O1xyXG4gICAgICAgIHRyYW5zaXRpb246IG9wYWNpdHkgMC4ycztcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDE7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG5cclxuICAgIC8vIFJlc2V0IGFuZCBvdmVycmlkZSBhbGwgbWVudSBzdHlsZXNcclxuICAgIC5wLW1lbnUge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gU3R5bGUgdGhlIHNwZWNpZmljIG1lbnUgb3ZlcmxheVxyXG4gICAgLmN1c3RvbS1hY3Rpb24tbWVudSB7XHJcbiAgICAgICAgJi5wLW1lbnUtb3ZlcmxheSB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuXHJcbiAgICAgICAgICAgIC5wLW1lbnUge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDczcHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDgwcHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDE2cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjA1KSAhaW1wb3J0YW50O1xyXG5cclxuICAgICAgICAgICAgICAgICoge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNGRkZGRkYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAucC1tZW51LWxpc3Qge1xyXG4gICAgICAgICAgICAgICAgICAgIGdhcDogMTZweDtcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC5wLW1lbnVpdGVtIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnAtbWVudWl0ZW0tbGluayB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICY6aG92ZXIge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbS10ZXh0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5wLW1lbnVpdGVtLWljb24ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzU5NzhGNyAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbS1pY29uIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA4cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM2Qzc1N0QgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbS10ZXh0IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM0OTUwNTcgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5kZWxldGUtZGlhbG9nIHtcclxuICAgICAgICAucC1kaWFsb2ctY29udGVudCB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDJyZW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5kZWxldGUtaWNvbi1jb250YWluZXIge1xyXG4gICAgICAgIHdpZHRoOiA2NHB4O1xyXG4gICAgICAgIGhlaWdodDogNjRweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0Q5MkQyMDtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAgICAgLnBpLXRyYXNoIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogI0ZGRkZGRjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmRlbGV0ZS1tZXNzYWdlIHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgY29sb3I6ICMzNDQwNTQ7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDEuNTtcclxuXHJcbiAgICAgICAgc3Ryb25nIHtcclxuICAgICAgICAgICAgY29sb3I6ICMxMDE4Mjg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDE3N3B4O1xyXG4gICAgICAgIGhlaWdodDogNDhweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xyXG4gICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpmb2N1cyB7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5jYW5jZWwtYnV0dG9uIHtcclxuICAgICAgICBjb2xvcjogIzZDNzU3RDtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICBjb2xvcjogIzQ5NTA1NztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5jYW5jZWwtYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMTc3LjIxcHg7XHJcbiAgICAgICAgaGVpZ2h0OiA0OHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcclxuICAgICAgICBnYXA6IDguN3B4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAgICAgLy8gQ3JlYXRlIGdyYWRpZW50IGJvcmRlclxyXG4gICAgICAgICY6OmJlZm9yZSB7XHJcbiAgICAgICAgICAgIGNvbnRlbnQ6ICcnO1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDogMDtcclxuICAgICAgICAgICAgbGVmdDogMDtcclxuICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgIGJvdHRvbTogMDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNi45NnB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpIGJvcmRlci1ib3g7XHJcbiAgICAgICAgICAgIC13ZWJraXQtbWFzazpcclxuICAgICAgICAgICAgICAgIGxpbmVhci1ncmFkaWVudCgjZmZmIDAgMCkgcGFkZGluZy1ib3gsXHJcbiAgICAgICAgICAgICAgICBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApO1xyXG4gICAgICAgICAgICAtd2Via2l0LW1hc2stY29tcG9zaXRlOiBkZXN0aW5hdGlvbi1vdXQ7XHJcbiAgICAgICAgICAgIG1hc2stY29tcG9zaXRlOiBleGNsdWRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gR3JhZGllbnQgdGV4dFxyXG4gICAgICAgIC5wLWJ1dHRvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcclxuICAgICAgICAgICAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY2xpcDogdGV4dDtcclxuICAgICAgICAgICAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cclxuICAgICAgICAgICAgJjo6YmVmb3JlIHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKSBib3JkZXItYm94O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAucC1idXR0b24tbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xyXG4gICAgICAgICAgICAgICAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuXHJcbiAgICAvLyBBZGQgdGhpcyBuZXcgc2VjdGlvblxyXG4gICAgLnAtZGlhbG9nIHtcclxuICAgICAgICAmLnAtZmx1aWQge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IGF1dG87XHJcblxyXG4gICAgICAgICAgICAucC1kaWFsb2ctY29udGVudCB7XHJcbiAgICAgICAgICAgICAgICBvdmVyZmxvdy15OiB2aXNpYmxlO1xyXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgICAgICAgICAgICAgbWF4LWhlaWdodDogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgLy8gcGFkZGluZzogMnJlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnAtZGlhbG9nLWhlYWRlciB7XHJcbiAgICAgICAgICAgIC8vIHBhZGRpbmc6IDJyZW0gMnJlbSAwIDJyZW07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBBZGp1c3QgZm9ybSBzcGFjaW5nXHJcbiAgICAgICAgLnAtZmx1aWQge1xyXG4gICAgICAgICAgICAuZ3JpZCB7XHJcbiAgICAgICAgICAgICAgICByb3ctZ2FwOiAxLjVyZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8vIEFkZCB0aGlzIHRvIHlvdXIgZXhpc3RpbmcgOmhvc3QgOjpuZy1kZWVwIHNlY3Rpb25cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5wLWRyb3Bkb3duIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgICAgIC5wLWRyb3Bkb3duLWxhYmVsIHtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDA7XHJcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAwO1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMzFweDsgLy8gQWRqdXN0IHRoaXMgdG8gbWF0Y2ggeW91ciBoZWlnaHQgLSAycHggZm9yIGJvcmRlcnNcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5wLWRyb3Bkb3duLXRyaWdnZXIge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIC5wLW11bHRpc2VsZWN0IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcbiIsIi8qIEdlbmVyYWwgRmxleCBMYXlvdXQ6IDEycHggZ2FwIGJldHdlZW4gY29udHJvbHMgKi9cbi5mbGV4IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZ2FwOiAxMnB4O1xuICAvKiAxMnB4IGdhcCBiZXR3ZWVuIGVhY2ggY29udHJvbCAqL1xufVxuXG4vKiBTZWFyY2ggSW5wdXQgc3R5bGVzICovXG4uc2VhcmNoLWlucHV0IHtcbiAgd2lkdGg6IDI0NnB4O1xuICAvKiBNYXRjaGluZyB0aGUgd2lkdGggZnJvbSBGaWdtYSAqL1xuICBoZWlnaHQ6IDQwcHg7XG4gIC8qIE1hdGNoaW5nIHRoZSBoZWlnaHQgZnJvbSBGaWdtYSAqL1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIC8qIE9wdGlvbmFsOiBTcGFjZSBiZXR3ZWVuIHRoZSBpY29uIGFuZCB0ZXh0ICovXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgLyogUm91bmRlZCBjb3JuZXJzIGZvciB0aGUgaW5wdXQgKi9cbn1cblxuLyogQ2xlYXIgQnV0dG9uIGN1c3RvbSBzdHlsZXMgKi9cbi5jbGVhci1idXR0b24ge1xuICB3aWR0aDogNjNweDtcbiAgaGVpZ2h0OiAyM3B4O1xuICBnYXA6IDZweDtcbiAgY29sb3I6ICNmZmY7XG4gIGJvcmRlcjogbm9uZTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNTk3OEY3LCAjOUM4NEZGKTtcbiAgYm9yZGVyLXJhZGl1czogM3B4O1xuICBwYWRkaW5nLXRvcDogNHB4O1xuICBwYWRkaW5nLXJpZ2h0OiA4cHg7XG4gIHBhZGRpbmctYm90dG9tOiA0cHg7XG4gIHBhZGRpbmctbGVmdDogOHB4O1xufVxuLmNsZWFyLWJ1dHRvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzRCNjhFMSwgIzhCNkVGRik7XG59XG5cbi8qIE9wdGlvbmFsOiBTdHlsZSBmb3IgdGhlIGJ1dHRvbidzIGljb24gKi9cbi5jbGVhci1idXR0b24gaSB7XG4gIG1hcmdpbi1yaWdodDogNHB4O1xuICAvKiBBZGp1c3QgaWYgeW91IHdhbnQgc3BhY2UgYmV0d2VlbiB0aGUgaWNvbiBhbmQgdGV4dCAqL1xufVxuXG46Om5nLWRlZXAgLmFkZC1idXR0b24ge1xuICB3aWR0aDogMTEuNXJlbTtcbiAgaGVpZ2h0OiAzcmVtO1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyOiBub25lO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpO1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIHBhZGRpbmc6IDAuNXJlbSAxcmVtO1xuICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuM3MgZWFzZTtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbn1cbjo6bmctZGVlcCAuYWRkLWJ1dHRvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzRCNjhFMSwgIzhCNkVGRik7XG59XG46Om5nLWRlZXAgLmFkZC1idXR0b246ZGlzYWJsZWQge1xuICBjdXJzb3I6IG5vdC1hbGxvd2VkICFpbXBvcnRhbnQ7XG59XG5cbi50YWJsZS1jZWxsIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4uYWN0aW9uLWNvbnRhaW5lciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4ucGxhaW4tZG90cyB7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG4gIGJvcmRlcjogbm9uZTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBwYWRkaW5nOiA1cHg7XG59XG5cbi5jdXN0b20tZHJvcGRvd24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAwO1xuICB0b3A6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3gtc2hhZG93OiAwIDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIHotaW5kZXg6IDEwMDA7XG59XG5cbi5kcm9wZG93bi1pdGVtIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nOiA4cHggMTZweDtcbiAgYm9yZGVyOiBub25lO1xuICBiYWNrZ3JvdW5kOiBub25lO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG4uZHJvcGRvd24taXRlbTpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWY1ZjU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1kYXRhdGFibGUgLnAtZGF0YXRhYmxlLWVtcHR5bWVzc2FnZSB0ZCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kYXRhdGFibGUgLnAtZGF0YXRhYmxlLWVtcHR5bWVzc2FnZSB0ZCBpIHtcbiAgdHJhbnNpdGlvbjogY29sb3IgMC4ycztcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kYXRhdGFibGUgLnAtZGF0YXRhYmxlLWVtcHR5bWVzc2FnZSB0ZCBpOmhvdmVyIHtcbiAgY29sb3I6ICM5OTkgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cm9sZV0sXG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPXJlcXVlc3RzUGVuZGluZ10sXG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPXJlcXVlc3RzQ29tcGxldGVkXSxcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49Y29uc3VtcHRpb25zXSB7XG4gIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yb2xlXSAucC1zb3J0YWJsZS1jb2x1bW4taWNvbixcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cmVxdWVzdHNQZW5kaW5nXSAucC1zb3J0YWJsZS1jb2x1bW4taWNvbixcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cmVxdWVzdHNDb21wbGV0ZWRdIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1jb25zdW1wdGlvbnNdIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uIHtcbiAgbWFyZ2luLWxlZnQ6IDRweDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIge1xuICBtaW4td2lkdGg6IDI0N3B4O1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIgaW5wdXQge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA0MHB4O1xuICBiYWNrZ3JvdW5kOiByZ2JhKDE3NywgMTc1LCAyMzMsIDAuMTAxOTYwNzg0Myk7XG4gIGJvcmRlcjogbm9uZTtcbiAgYm9yZGVyLXJhZGl1czogOHB4IDAgMCA4cHg7XG4gIHBhZGRpbmc6IDAuNXJlbTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXItdHJpZ2dlciB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTc3LCAxNzUsIDIzMywgMC4xMDE5NjA3ODQzKTtcbiAgYm9yZGVyOiBub25lO1xuICBib3JkZXItcmFkaXVzOiAwIDhweCA4cHggMDtcbiAgY29sb3I6ICM2NjY7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciAucC1kYXRlcGlja2VyLXRyaWdnZXI6ZW5hYmxlZDpob3ZlciB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTc3LCAxNzUsIDIzMywgMC4xMDE5NjA3ODQzKTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXItdHJpZ2dlcjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1kYXRlcGlja2VyIHtcbiAgbWluLXdpZHRoOiAyNDdweDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXIucC1kYXRlcGlja2VyLWlubGluZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAxMDAlO1xuICBsZWZ0OiAwO1xuICB6LWluZGV4OiAxMDAwO1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLnVwZGF0ZS1idXR0b24ge1xuICB3aWR0aDogMTEuNXJlbTtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xufVxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uOmRpc2FibGVkIHtcbiAgb3BhY2l0eTogMC42O1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XG59XG5cbi5jbGFzc3Jvb20taW5pdGlhbCB7XG4gIHdpZHRoOiAyNHB4O1xuICBoZWlnaHQ6IDI0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZDogI0U2RThGMztcbiAgY29sb3I6ICNGRkZGRkY7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXNpemU6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5jbGFzc3Jvb20tY291bnQge1xuICB3aWR0aDogMzJweDtcbiAgaGVpZ2h0OiAyM3B4O1xuICBnYXA6IDE2cHg7XG4gIHBhZGRpbmc6IDRweCA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyMTcsIDI1NSwgMjAzLCAwLjQpO1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICMzMzMzMzM7XG59XG5cbjo6bmctZGVlcCAucC10b29sdGlwIC5wLXRvb2x0aXAtdGV4dCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcbiAgY29sb3I6ICMzMzMzMzMgIWltcG9ydGFudDtcbiAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNjtcbiAgYm94LXNoYWRvdzogMCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgZm9udC1zaXplOiAxMXB4O1xufVxuOjpuZy1kZWVwIC5wLXRvb2x0aXAgLnAtdG9vbHRpcC1hcnJvdyB7XG4gIGJvcmRlci10b3AtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcbn1cblxuLmNsYXNzcm9vbS1jb3VudC13cmFwcGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZ2FwOiA4cHg7XG59XG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIgLmVkaXQtaWNvbiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM2RTZFNkU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgb3BhY2l0eTogMC43O1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuMnM7XG59XG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIgLmVkaXQtaWNvbjpob3ZlciB7XG4gIG9wYWNpdHk6IDE7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1tZW51IHtcbiAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xuICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkge1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IHtcbiAgd2lkdGg6IDczcHggIWltcG9ydGFudDtcbiAgbWluLWhlaWdodDogODBweCAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAxNnB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDhweCAhaW1wb3J0YW50O1xuICBib3JkZXI6IDFweCBzb2xpZCAjRTZFNkU2ICFpbXBvcnRhbnQ7XG4gIGJveC1zaGFkb3c6IDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4wNSkgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgKiB7XG4gIGJhY2tncm91bmQ6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IHtcbiAgZ2FwOiAxNnB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IC5wLW1lbnUtbGlzdCAucC1tZW51aXRlbSB7XG4gIG1hcmdpbjogMDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IC5wLW1lbnVpdGVtIC5wLW1lbnVpdGVtLWxpbmsge1xuICBwYWRkaW5nOiAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3QgLnAtbWVudWl0ZW0gLnAtbWVudWl0ZW0tbGluazpob3ZlciAucC1tZW51aXRlbS10ZXh0LFxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3QgLnAtbWVudWl0ZW0gLnAtbWVudWl0ZW0tbGluazpob3ZlciAucC1tZW51aXRlbS1pY29uIHtcbiAgY29sb3I6ICM1OTc4RjcgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IC5wLW1lbnVpdGVtIC5wLW1lbnVpdGVtLWxpbmsgLnAtbWVudWl0ZW0taWNvbiB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XG4gIGNvbG9yOiAjNkM3NTdEICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IC5wLW1lbnUtbGlzdCAucC1tZW51aXRlbSAucC1tZW51aXRlbS1saW5rIC5wLW1lbnVpdGVtLXRleHQge1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjNDk1MDU3ICFpbXBvcnRhbnQ7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLWRpYWxvZyAucC1kaWFsb2ctY29udGVudCB7XG4gIHBhZGRpbmc6IDJyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciB7XG4gIHdpZHRoOiA2NHB4O1xuICBoZWlnaHQ6IDY0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0Q5MkQyMDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciAucGktdHJhc2gge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtbWVzc2FnZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICMzNDQwNTQ7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1tZXNzYWdlIHN0cm9uZyB7XG4gIGNvbG9yOiAjMTAxODI4O1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbiB7XG4gIHdpZHRoOiAxNzdweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtY29uZmlybS1idXR0b246aG92ZXIge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSk7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b24ge1xuICBjb2xvcjogIzZDNzU3RDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBjb2xvcjogIzQ5NTA1Nztcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbiB7XG4gIHdpZHRoOiAxNzcuMjFweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGdhcDogOC43cHg7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246OmJlZm9yZSB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgYm90dG9tOiAwO1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSkgYm9yZGVyLWJveDtcbiAgLXdlYmtpdC1tYXNrOiBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApIHBhZGRpbmctYm94LCBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApO1xuICAtd2Via2l0LW1hc2stY29tcG9zaXRlOiBkZXN0aW5hdGlvbi1vdXQ7XG4gIG1hc2stY29tcG9zaXRlOiBleGNsdWRlO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uIC5wLWJ1dHRvbi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246aG92ZXI6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKSBib3JkZXItYm94O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIC5wLWJ1dHRvbi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cucC1mbHVpZCB7XG4gIGhlaWdodDogYXV0bztcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cucC1mbHVpZCAucC1kaWFsb2ctY29udGVudCB7XG4gIG92ZXJmbG93LXk6IHZpc2libGU7XG4gIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgbWF4LWhlaWdodDogbm9uZSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRpYWxvZyAucC1mbHVpZCAuZ3JpZCB7XG4gIHJvdy1nYXA6IDEuNXJlbTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5wLWRyb3Bkb3duIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kcm9wZG93biAucC1kcm9wZG93bi1sYWJlbCB7XG4gIHBhZGRpbmctdG9wOiAwO1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgbGluZS1oZWlnaHQ6IDMxcHg7XG59XG46aG9zdCA6Om5nLWRlZXAgLnAtZHJvcGRvd24gLnAtZHJvcGRvd24tdHJpZ2dlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1tdWx0aXNlbGVjdCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGhlaWdodDogNDBweDtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 87277:
/*!***************************************************!*\
  !*** ./src/app/modules/app/staff/staff.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StaffModule: () => (/* binding */ StaffModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/fileupload */ 88285);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_toolbar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/toolbar */ 39177);
/* harmony import */ var primeng_rating__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/rating */ 85583);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/inputtextarea */ 30652);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/dropdown */ 94553);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/radiobutton */ 63313);
/* harmony import */ var primeng_inputnumber__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/inputnumber */ 65362);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var _staff_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./staff-routing.module */ 59643);
/* harmony import */ var _staff_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./staff.component */ 17764);
/* harmony import */ var _staff_count_cards_staff_count_cards_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./staff-count-cards/staff-count-cards.component */ 40957);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/calendar */ 57411);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/multiselect */ 77524);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/tooltip */ 31251);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/splitbutton */ 64323);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61699);
























class StaffModule {
  static #_ = this.ɵfac = function StaffModule_Factory(t) {
    return new (t || StaffModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: StaffModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule, _staff_routing_module__WEBPACK_IMPORTED_MODULE_0__.StaffRoutingModule, primeng_table__WEBPACK_IMPORTED_MODULE_6__.TableModule, primeng_fileupload__WEBPACK_IMPORTED_MODULE_7__.FileUploadModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_8__.ButtonModule, primeng_menu__WEBPACK_IMPORTED_MODULE_9__.MenuModule, primeng_calendar__WEBPACK_IMPORTED_MODULE_10__.CalendarModule, primeng_splitbutton__WEBPACK_IMPORTED_MODULE_11__.SplitButtonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_12__.RippleModule, primeng_toast__WEBPACK_IMPORTED_MODULE_13__.ToastModule, primeng_toolbar__WEBPACK_IMPORTED_MODULE_14__.ToolbarModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_15__.TooltipModule, primeng_rating__WEBPACK_IMPORTED_MODULE_16__.RatingModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_17__.InputTextModule, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_18__.InputTextareaModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_19__.DropdownModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_20__.RadioButtonModule, primeng_inputnumber__WEBPACK_IMPORTED_MODULE_21__.InputNumberModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.DialogModule, primeng_multiselect__WEBPACK_IMPORTED_MODULE_23__.MultiSelectModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](StaffModule, {
    declarations: [_staff_component__WEBPACK_IMPORTED_MODULE_1__.StaffComponent, _staff_count_cards_staff_count_cards_component__WEBPACK_IMPORTED_MODULE_2__.StaffCountCardComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule, _staff_routing_module__WEBPACK_IMPORTED_MODULE_0__.StaffRoutingModule, primeng_table__WEBPACK_IMPORTED_MODULE_6__.TableModule, primeng_fileupload__WEBPACK_IMPORTED_MODULE_7__.FileUploadModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_8__.ButtonModule, primeng_menu__WEBPACK_IMPORTED_MODULE_9__.MenuModule, primeng_calendar__WEBPACK_IMPORTED_MODULE_10__.CalendarModule, primeng_splitbutton__WEBPACK_IMPORTED_MODULE_11__.SplitButtonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_12__.RippleModule, primeng_toast__WEBPACK_IMPORTED_MODULE_13__.ToastModule, primeng_toolbar__WEBPACK_IMPORTED_MODULE_14__.ToolbarModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_15__.TooltipModule, primeng_rating__WEBPACK_IMPORTED_MODULE_16__.RatingModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_17__.InputTextModule, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_18__.InputTextareaModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_19__.DropdownModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_20__.RadioButtonModule, primeng_inputnumber__WEBPACK_IMPORTED_MODULE_21__.InputNumberModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.DialogModule, primeng_multiselect__WEBPACK_IMPORTED_MODULE_23__.MultiSelectModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_modules_app_staff_staff_module_ts.js.map