"use strict";
(self["webpackChunkverona_ng"] = self["webpackChunkverona_ng"] || []).push([["main"],{

/***/ 23966:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRoutingModule: () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _layout_app_layout_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./layout/app.layout.component */ 79206);
/* harmony import */ var _app_resolvers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.resolvers */ 29224);
/* harmony import */ var _guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./guards/auth.guard */ 1391);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61699);






const routes = [{
  path: '',
  redirectTo: 'login',
  pathMatch: 'full'
}, {
  path: 'login',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_demo_components_auth_login_login_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/auth/login/login.module */ 3957)).then(m => m.LoginModule)
}, {
  path: '',
  component: _layout_app_layout_component__WEBPACK_IMPORTED_MODULE_0__.AppLayoutComponent,
  canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.AuthGuard],
  canActivateChild: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.AuthGuard],
  resolve: {
    initialData: _app_resolvers__WEBPACK_IMPORTED_MODULE_1__.initialDataResolver
  },
  children: [{
    path: 'dashboard',
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_dashboards_dashboards_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/dashboards/dashboards.module */ 82887)).then(m => m.DashboardsModule)
  }, {
    path: 'users',
    data: {
      breadcrumb: 'Users'
    },
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputnumber_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-calendar_mjs-node_modules_primeng_fesm2022_prim-7a3c9e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-progressbar_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-paginator_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-icons-exclamationtriangle_mjs-node_modules_prim-39e02f"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-icons-arrowdown_mjs-node_modules_primeng_fesm20-515138"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-selectbutton_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-toast_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-messages_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-fileupload_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-multiselect_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tieredmenu_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-rating_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-splitbutton_mjs"), __webpack_require__.e("default-src_app_core_classroom_classroom-shared_service_ts-node_modules_primeng_fesm2022_prim-39eecf"), __webpack_require__.e("common"), __webpack_require__.e("src_app_modules_app_staff_staff_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/app/staff/staff.module */ 87277)).then(m => m.StaffModule)
  }, {
    path: 'classrooms',
    data: {
      breadcrumb: 'Classrooms'
    },
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputnumber_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-calendar_mjs-node_modules_primeng_fesm2022_prim-7a3c9e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-progressbar_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-paginator_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-icons-exclamationtriangle_mjs-node_modules_prim-39e02f"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-icons-arrowdown_mjs-node_modules_primeng_fesm20-515138"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-selectbutton_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-toast_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-messages_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-fileupload_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tieredmenu_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-rating_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-splitbutton_mjs"), __webpack_require__.e("default-src_app_core_classroom_classroom-shared_service_ts-node_modules_primeng_fesm2022_prim-39eecf"), __webpack_require__.e("src_app_modules_app_classroom_classroom_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/app/classroom/classroom.module */ 90307)).then(m => m.ClassroomModule)
  }, {
    path: 'vendors',
    data: {
      breadcrumb: 'Vendors'
    },
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputnumber_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-calendar_mjs-node_modules_primeng_fesm2022_prim-7a3c9e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-progressbar_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-paginator_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-icons-exclamationtriangle_mjs-node_modules_prim-39e02f"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-icons-arrowdown_mjs-node_modules_primeng_fesm20-515138"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-selectbutton_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-toast_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-messages_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-fileupload_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-multiselect_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tieredmenu_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-rating_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-splitbutton_mjs"), __webpack_require__.e("src_app_modules_app_inventory_vendor_vendor_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/app/inventory/vendor/vendor.module */ 42657)).then(m => m.VendorModule)
  }, {
    path: 'uikit',
    data: {
      breadcrumb: 'menu.UI_KIT'
    },
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_uikit_uikit_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/uikit/uikit.module */ 83250)).then(m => m.UIkitModule)
  }, {
    path: 'utilities',
    data: {
      breadcrumb: 'menu.UTILITIES'
    },
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_utilities_utilities_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/utilities/utilities.module */ 91178)).then(m => m.UtilitiesModule)
  }, {
    path: 'pages',
    data: {
      breadcrumb: 'menu.PAGES'
    },
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_pages_pages_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/pages/pages.module */ 4586)).then(m => m.PagesModule)
  }, {
    path: 'profile',
    data: {
      breadcrumb: 'menu.USER_MANAGEMENT'
    },
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_profile_profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/profile/profile.module */ 82670)).then(m => m.ProfileModule)
  }, {
    path: 'documentation',
    data: {
      breadcrumb: 'menu.DOCUMENTATION'
    },
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_documentation_documentation_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/documentation/documentation.module */ 73482)).then(m => m.DocumentationModule)
  }, {
    path: 'blocks',
    data: {
      breadcrumb: 'menu.PRIME_BLOCKS'
    },
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-chip_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-password_mjs"), __webpack_require__.e("src_app_demo_components_primeblocks_primeblocks_module_ts-node_modules_primeng_fesm2022_prime-6dbc98")]).then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/primeblocks/primeblocks.module */ 7232)).then(m => m.PrimeBlocksModule)
  }, {
    path: 'ecommerce',
    data: {
      breadcrumb: 'menu.E_COMMERCE'
    },
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_ecommerce_ecommerce_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/ecommerce/ecommerce.module */ 10414)).then(m => m.EcommerceModule)
  }, {
    path: 'apps',
    data: {
      breadcrumb: 'menu.APPS'
    },
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_apps_apps_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/apps/apps.module */ 44953)).then(m => m.AppsModule)
  }]
}, {
  path: '',
  component: _layout_app_layout_component__WEBPACK_IMPORTED_MODULE_0__.AppLayoutComponent,
  canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.SuperAuthGuard],
  canActivateChild: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.SuperAuthGuard],
  resolve: {
    initialData: _app_resolvers__WEBPACK_IMPORTED_MODULE_1__.initialDataResolver
  },
  children: [{
    path: 'schools',
    data: {
      breadcrumb: 'School'
    },
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputnumber_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-calendar_mjs-node_modules_primeng_fesm2022_prim-7a3c9e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-progressbar_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-paginator_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-icons-exclamationtriangle_mjs-node_modules_prim-39e02f"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-icons-arrowdown_mjs-node_modules_primeng_fesm20-515138"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-selectbutton_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-toast_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-messages_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-fileupload_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-multiselect_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tieredmenu_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-rating_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-splitbutton_mjs"), __webpack_require__.e("default-src_app_core_classroom_classroom-shared_service_ts-node_modules_primeng_fesm2022_prim-39eecf"), __webpack_require__.e("common"), __webpack_require__.e("src_app_modules_app_school_school_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/app/school/school.module */ 95467)).then(m => m.SchoolModule)
  }]
}, {
  path: 'auth',
  data: {
    breadcrumb: 'menu.AUTH'
  },
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_auth_auth_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/auth/auth.module */ 66205)).then(m => m.AuthModule)
}, {
  path: 'landing',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_landing_landing_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/landing/landing.module */ 96010)).then(m => m.LandingModule)
}, {
  path: 'notfound',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_components_notfound_notfound_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/components/notfound/notfound.module */ 32076)).then(m => m.NotfoundModule)
}, {
  path: '**',
  redirectTo: '/notfound'
}];
class AppRoutingModule {
  static #_ = this.ɵfac = function AppRoutingModule_Factory(t) {
    return new (t || AppRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: AppRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forRoot(routes), _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 66401:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/api */ 98026);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 27947);



class AppComponent {
  constructor(primengConfig) {
    this.primengConfig = primengConfig;
  }
  ngOnInit() {
    this.primengConfig.ripple = true;
  }
  static #_ = this.ɵfac = function AppComponent_Factory(t) {
    return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_1__.PrimeNGConfig));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: AppComponent,
    selectors: [["app-root"]],
    decls: 1,
    vars: 0,
    template: function AppComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterOutlet],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 78629:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppModule: () => (/* binding */ AppModule),
/* harmony export */   HttpLoaderFactory: () => (/* binding */ HttpLoaderFactory)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 23966);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 66401);
/* harmony import */ var _layout_app_layout_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./layout/app.layout.module */ 84295);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 54860);
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/http-loader */ 70614);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61699);









function HttpLoaderFactory(http) {
  return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_3__.TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class AppModule {
  static #_ = this.ɵfac = function AppModule_Factory(t) {
    return new (t || AppModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
    type: AppModule,
    bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent]
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    providers: [{
      provide: _angular_common__WEBPACK_IMPORTED_MODULE_5__.LocationStrategy,
      useClass: _angular_common__WEBPACK_IMPORTED_MODULE_5__.PathLocationStrategy
    }],
    imports: [_layout_app_layout_module__WEBPACK_IMPORTED_MODULE_2__.AppLayoutModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule.forRoot({
      loader: {
        provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient]
      }
    })]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent],
    imports: [_layout_app_layout_module__WEBPACK_IMPORTED_MODULE_2__.AppLayoutModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule]
  });
})();

/***/ }),

/***/ 29224:
/*!**********************************!*\
  !*** ./src/app/app.resolvers.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initialDataResolver: () => (/* binding */ initialDataResolver)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 16290);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 81891);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 74300);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 84980);
/* harmony import */ var _core_school_school_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/school/school.service */ 62915);
/* harmony import */ var _core_users_user_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./core/users/user.service */ 50090);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 27947);





const initialDataResolver = () => {
  const schoolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_core_school_school_service__WEBPACK_IMPORTED_MODULE_0__.SchoolSharedService);
  const userService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_core_users_user_service__WEBPACK_IMPORTED_MODULE_1__.UserSharedService);
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router);
  // Use the userCode set after login
  // Check for user code in localStorage
  const userCode = localStorage.getItem('userCode');
  const userRole = localStorage.getItem('userRole');
  if (!userCode) {
    router.navigate(['/login']);
    return rxjs__WEBPACK_IMPORTED_MODULE_4__.EMPTY; // Prevents route activation
  }

  userService.userCode = userCode;
  // 1. Load user details first
  return userService.getUserByCode(userCode).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(userResponse => {
    if (userRole === 'admin') {
      // If the user is not an admin or superadmin, redirect to the dashboard
      const user = userResponse.data;
      // Try to get selected school code from localStorage
      let schoolCode = localStorage.getItem('selectedSchoolCode');
      // If not found or not in user's schools, fallback to first
      if (!schoolCode || !user?.schools?.some(s => s.code === schoolCode)) {
        schoolCode = user?.schools && user.schools.length > 0 && user.schools[0].code !== undefined ? user.schools[0].code : null;
        // Store selected school code in localStorage
        if (schoolCode) {
          localStorage.setItem('selectedSchoolCode', schoolCode);
        }
      }
      // 3. Load the default school details
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.forkJoin)([schoolService.getSchoolByCode(schoolCode || ''), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(userResponse) // pass user details as well
      ]);
    } else if (userRole === 'super-admin') {
      const defaultSchool = [{
        code: userCode,
        name: 'Super Admin'
      }];
      // Add to userResponse.data.schools as well
      if (userResponse.data) {
        userResponse.data.schools = defaultSchool;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.forkJoin)([(0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(defaultSchool), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(userResponse)]);
    } else {
      // For any other case, return EMPTY to satisfy Observable return type
      return rxjs__WEBPACK_IMPORTED_MODULE_4__.EMPTY;
    }
  }));
};

/***/ }),

/***/ 62915:
/*!***********************************************!*\
  !*** ./src/app/core/school/school.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolSharedService: () => (/* binding */ SchoolSharedService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 58071);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 33252);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 13738);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 2389);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 81527);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 81891);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 20553);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 54860);





class SchoolSharedService {
  /**
   * Constructor
   */
  constructor(_httpClient) {
    this._httpClient = _httpClient;
    /**
     * Private API URL
     */
    this.API_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl;
    /**
     * Private BehaviorSubjects for state management
     */
    this._school = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this._schools = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    /**
     * Public Observables for components to subscribe to
     */
    this.school$ = this._school.asObservable();
    this.schools$ = this._schools.asObservable();
  }
  /**
   * Get all schools
   */
  getSchools() {
    return this._httpClient.get(`${this.API_URL}/api/v1/schools`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._schools.next(response.data);
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError));
  }
  /**
   * Get all schools
   */
  getUserSchools() {
    return this._httpClient.get(`${this.API_URL}/api/v1/schools`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._schools.next(response.data);
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError));
  }
  /**
   * Get school by code
   */
  getSchoolByCode(code) {
    return this._httpClient.get(`${this.API_URL}/schools/${code}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._school.next(response.data);
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError));
  }
  /**
   * Create new school
   */
  createSchool(school) {
    return this.schools$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.switchMap)(schools => this._httpClient.post(`${this.API_URL}/api/v1/schools`, school).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._schools.next([response.data, ...(schools || [])]);
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError))));
  }
  /**
   * Update school
   */
  updateSchool(code, school) {
    return this.schools$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.switchMap)(schools => this._httpClient.put(`${this.API_URL}/api/v1/schools/${code}`, school).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data && schools) {
        const index = schools.findIndex(item => item.code === code);
        if (index !== -1) {
          schools[index] = response.data;
          this._schools.next([...schools]);
          this._school.next(response.data);
        }
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError))));
  }
  /**
   * Update school status
   */
  updateSchoolStatus(code, status) {
    return this.schools$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.switchMap)(schools => this._httpClient.patch(`${this.API_URL}/api/v1/schools/${code}/status`, {
      status
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data && schools) {
        const index = schools.findIndex(item => item.code === code);
        if (index !== -1) {
          schools[index] = response.data;
          this._schools.next([...schools]);
          this._school.next(response.data);
        }
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError))));
  }
  /**
   * Delete school
   */
  deleteSchool(code) {
    return this.schools$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.switchMap)(schools => this._httpClient.delete(`${this.API_URL}/api/v1/schools/${code}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && schools) {
        const index = schools.findIndex(item => item.code === code);
        if (index !== -1) {
          schools.splice(index, 1);
          this._schools.next([...schools]);
        }
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError))));
  }
  /**
   * Error handler
   */
  handleError(error) {
    console.error('An error occurred:', error);
    const errorResponse = error?.error || {
      success: 0,
      message: 'An unexpected error occurred',
      data: null,
      timestamp: new Date()
    };
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)(() => errorResponse);
  }
  static #_ = this.ɵfac = function SchoolSharedService_Factory(t) {
    return new (t || SchoolSharedService)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjectable"]({
    token: SchoolSharedService,
    factory: SchoolSharedService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 50090:
/*!********************************************!*\
  !*** ./src/app/core/users/user.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserSharedService: () => (/* binding */ UserSharedService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 58071);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 13738);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2389);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 33252);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 81527);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 79736);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 84980);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 20553);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 54860);




class UserSharedService {
  constructor(_httpClient) {
    this._httpClient = _httpClient;
    // Base URLs
    this.BASE_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl;
    this.USERS_URL = `${this.BASE_URL}/api/v1/users`;
    // BehaviorSubjects
    this._user = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this._users = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Accessors
  // -----------------------------------------------------------------------------------------------------
  /**
   * Setter & getter for access token
   */
  set userCode(code) {
    localStorage.setItem('userCode', code);
  }
  get userCode() {
    return localStorage.getItem('userCode') ?? '';
  }
  /**
   * Setter & getter for access token
   */
  set accessToken(token) {
    localStorage.setItem('accessToken', token);
  }
  get accessToken() {
    return localStorage.getItem('accessToken') ?? '';
  }
  set refreshToken(token) {
    localStorage.setItem('refreshToken', token);
  }
  get refreshToken() {
    return localStorage.getItem('refreshToken') ?? '';
  }
  // Accessors
  get user$() {
    return this._user.asObservable();
  }
  get users$() {
    return this._users.asObservable();
  }
  // Public Methods
  /**
   * Get all users
   */
  getUsers() {
    return this._httpClient.get(`${this.USERS_URL}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._users.next(response.data);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to fetch users:', error);
      const errorResponse = error?.error || {
        success: false,
        message: error.message || 'Failed to fetch users',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }));
  }
  /**
   * Get user by code
   */
  getUserByCode(code) {
    return this._httpClient.get(`${this.USERS_URL}/${code}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._user.next(response.data);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to fetch user:', error);
      const errorResponse = error?.error || {
        success: false,
        message: error.message || 'Failed to fetch user',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }));
  }
  /**
   * Get user counts (example: total users, users with admin role, etc.)
   */
  getUserCounts() {
    return this.users$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(users => {
      const counts = {
        total: users?.length || 0,
        admins: users?.filter(u => u.roles?.includes('ADMIN')).length || 0,
        staffs: users?.filter(u => u.roles?.includes('STAFF')).length || 0
      };
      return {
        success: true,
        data: counts,
        message: 'User counts retrieved successfully',
        timestamp: new Date()
      };
    }));
  }
  /**
   * Check the authentication status
   */
  check() {
    // Check if the user is logged in
    const usercCode = localStorage.getItem('userCode');
    if (usercCode) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(true);
    }
    // If the user is not logged in, return false
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(false);
  }
  static #_ = this.ɵfac = function UserSharedService_Factory(t) {
    return new (t || UserSharedService)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjectable"]({
    token: UserSharedService,
    factory: UserSharedService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 1391:
/*!**************************************!*\
  !*** ./src/app/guards/auth.guard.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthGuard: () => (/* binding */ AuthGuard),
/* harmony export */   SuperAuthGuard: () => (/* binding */ SuperAuthGuard)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 81891);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 84980);
/* harmony import */ var _core_users_user_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/users/user.service */ 50090);




const SuperAuthGuard = (route, state) => {
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router);
  // Check the authentication status
  return (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_core_users_user_service__WEBPACK_IMPORTED_MODULE_0__.UserSharedService).check().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.switchMap)(authenticate => {
    // If the user is not authenticated...
    if (authenticate) {
      // Redirect to the sign-in page with a redirectUrl param
      const usercCode = localStorage.getItem('userCode');
      const userRole = localStorage.getItem('userRole');
      if (usercCode && userRole) {
        if (userRole === 'super-admin') {
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(true);
        } else {
          router.navigate(['/login']);
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(false);
        }
      }
    }
    // Allow the access
    const redirectURL = state.url === '/login' ? '' : `redirectURL=${state.url}`;
    const urlTree = router.parseUrl(`sign-in?${redirectURL}`);
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(urlTree);
  }));
};
const AuthGuard = (route, state) => {
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router);
  // Check the authentication status
  return (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_core_users_user_service__WEBPACK_IMPORTED_MODULE_0__.UserSharedService).check().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.switchMap)(authenticate => {
    // If the user is not authenticated...
    if (authenticate) {
      // Redirect to the sign-in page with a redirectUrl param
      const usercCode = localStorage.getItem('userCode');
      const userRole = localStorage.getItem('userRole');
      if (usercCode && userRole) {
        if (userRole === 'admin') {
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(true);
        } else {
          router.navigate(['/login']);
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(false);
        }
      }
    }
    // Allow the access
    const redirectURL = state.url === '/login' ? '' : `redirectURL=${state.url}`;
    const urlTree = router.parseUrl(`sign-in?${redirectURL}`);
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(urlTree);
  }));
};

/***/ }),

/***/ 70549:
/*!****************************************************!*\
  !*** ./src/app/layout/app.breadcrumb.component.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppBreadcrumbComponent: () => (/* binding */ AppBreadcrumbComponent)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 58071);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 74520);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 5939);







function AppBreadcrumbComponent_ng_template_7_li_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, ">");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function AppBreadcrumbComponent_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, AppBreadcrumbComponent_ng_template_7_li_3_Template, 2, 0, "li", 4);
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const last_r2 = ctx.last;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, item_r1.label));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !last_r2);
  }
}
const _c0 = () => ["/dashboard"];
class AppBreadcrumbComponent {
  constructor(router) {
    this.router = router;
    this._breadcrumbs$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
    this.breadcrumbs$ = this._breadcrumbs$.asObservable();
  }
  ngOnInit() {
    // Build breadcrumb on initial load
    this.buildBreadcrumb(this.router.routerState.snapshot.root);
    // Listen for navigation events to update breadcrumb
    this.router.events.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.filter)(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_3__.NavigationEnd)).subscribe(() => {
      this.buildBreadcrumb(this.router.routerState.snapshot.root);
    });
  }
  buildBreadcrumb(route) {
    const breadcrumbs = [];
    this.addBreadcrumb(route, [], breadcrumbs);
    this._breadcrumbs$.next(breadcrumbs);
  }
  addBreadcrumb(route, parentUrl, breadcrumbs) {
    const routeUrl = parentUrl.concat(route.url.map(url => url.path));
    const breadcrumb = route.data['breadcrumb'];
    const parentBreadcrumb = route.parent && route.parent.data ? route.parent.data['breadcrumb'] : null;
    if (breadcrumb && breadcrumb !== parentBreadcrumb) {
      breadcrumbs.push({
        label: breadcrumb,
        url: '/' + routeUrl.join('/')
      });
    }
    if (route.firstChild) {
      this.addBreadcrumb(route.firstChild, routeUrl, breadcrumbs);
    }
  }
  static #_ = this.ɵfac = function AppBreadcrumbComponent_Factory(t) {
    return new (t || AppBreadcrumbComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: AppBreadcrumbComponent,
    selectors: [["app-breadcrumb"]],
    decls: 9,
    vars: 5,
    consts: [[1, "layout-breadcrumb"], [3, "routerLink"], [1, "layout-breadcrumb-chevron"], ["ngFor", "", 3, "ngForOf"], ["class", "layout-breadcrumb-chevron", 4, "ngIf"]],
    template: function AppBreadcrumbComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nav", 0)(1, "ol")(2, "li")(3, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, " Home ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "li", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, ">");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, AppBreadcrumbComponent_ng_template_7_Template, 4, 4, "ng-template", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](4, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](8, 2, ctx.breadcrumbs$));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_4__.AsyncPipe],
    encapsulation: 2
  });
}

/***/ }),

/***/ 57133:
/*!************************************************!*\
  !*** ./src/app/layout/app.footer.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppFooterComponent: () => (/* binding */ AppFooterComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service/app.layout.service */ 43859);


class AppFooterComponent {
  constructor(layoutService) {
    this.layoutService = layoutService;
  }
  get colorScheme() {
    return this.layoutService.config().colorScheme;
  }
  static #_ = this.ɵfac = function AppFooterComponent_Factory(t) {
    return new (t || AppFooterComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__.LayoutService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: AppFooterComponent,
    selectors: [["app-footer"]],
    decls: 8,
    vars: 1,
    consts: [[1, "layout-footer"], [1, "footer-start"], ["alt", "logo", 3, "src"], [1, "app-name"], [1, "footer-end"]],
    template: function AppFooterComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Verona");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 4)(6, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7, "\u00A9 Your Organization");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", "assets/layout/images/logo-" + (ctx.colorScheme === "light" ? "dark" : "light") + ".png", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
      }
    },
    encapsulation: 2
  });
}

/***/ }),

/***/ 79206:
/*!************************************************!*\
  !*** ./src/app/layout/app.layout.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppLayoutComponent: () => (/* binding */ AppLayoutComponent)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 74520);
/* harmony import */ var _app_sidebar_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.sidebar.component */ 65196);
/* harmony import */ var _app_topbar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.topbar.component */ 67707);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _app_menu_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.menu.service */ 60704);
/* harmony import */ var _service_app_layout_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./service/app.layout.service */ 43859);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _config_app_config_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./config/app.config.component */ 1111);
/* harmony import */ var _app_footer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.footer.component */ 57133);
/* harmony import */ var _app_breadcrumb_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.breadcrumb.component */ 70549);















function AppLayoutComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 1)(1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](2, "app-topbar")(3, "app-sidebar");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "div", 3)(5, "div", 4)(6, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](7, "app-breadcrumb")(8, "router-outlet")(9, "app-footer");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](10, "app-config");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", ctx_r0.containerClass);
  }
}
class AppLayoutComponent {
  constructor(menuService, layoutService, renderer, router, translate) {
    this.menuService = menuService;
    this.layoutService = layoutService;
    this.renderer = renderer;
    this.router = router;
    this.translate = translate;
    this.userloaded = true;
    this.translate.setDefaultLang('mr');
    this.overlayMenuOpenSubscription = this.layoutService.overlayOpen$.subscribe(() => {
      if (!this.menuOutsideClickListener) {
        this.menuOutsideClickListener = this.renderer.listen('document', 'click', event => {
          const isOutsideClicked = !(this.appSidebar.el.nativeElement.isSameNode(event.target) || this.appSidebar.el.nativeElement.contains(event.target) || this.appTopbar.menuButton.nativeElement.isSameNode(event.target) || this.appTopbar.menuButton.nativeElement.contains(event.target));
          if (isOutsideClicked) {
            this.hideMenu();
          }
        });
      }
      if ((this.layoutService.isSlim() || this.layoutService.isSlimPlus()) && !this.menuScrollListener) {
        this.menuScrollListener = this.renderer.listen(this.appSidebar.menuContainer.nativeElement, 'scroll', event => {
          if (this.layoutService.isDesktop()) {
            this.hideMenu();
          }
        });
      }
      if (this.layoutService.state.staticMenuMobileActive) {
        this.blockBodyScroll();
      }
    });
    this.router.events.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.filter)(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_9__.NavigationEnd)).subscribe(() => {
      this.hideMenu();
    });
    this.tabOpenSubscription = this.layoutService.tabOpen$.subscribe(tab => {
      this.router.navigate(tab.routerLink);
      this.layoutService.openTab(tab);
    });
    this.tabCloseSubscription = this.layoutService.tabClose$.subscribe(event => {
      if (this.router.isActive(event.tab.routerLink[0], {
        paths: 'subset',
        queryParams: 'subset',
        fragment: 'ignored',
        matrixParams: 'ignored'
      })) {
        const tabs = this.layoutService.tabs;
        if (tabs.length > 1) {
          if (event.index === tabs.length - 1) this.router.navigate(tabs[tabs.length - 2].routerLink);else this.router.navigate(tabs[event.index + 1].routerLink);
        } else {
          this.router.navigate(['/']);
        }
      }
      this.layoutService.closeTab(event.index);
    });
  }
  blockBodyScroll() {
    if (document.body.classList) {
      document.body.classList.add('blocked-scroll');
    } else {
      document.body.className += ' blocked-scroll';
    }
  }
  unblockBodyScroll() {
    if (document.body.classList) {
      document.body.classList.remove('blocked-scroll');
    } else {
      document.body.className = document.body.className.replace(new RegExp('(^|\\b)' + 'blocked-scroll'.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
    }
  }
  hideMenu() {
    this.layoutService.state.overlayMenuActive = false;
    this.layoutService.state.staticMenuMobileActive = false;
    this.layoutService.state.menuHoverActive = false;
    this.menuService.reset();
    if (this.menuOutsideClickListener) {
      this.menuOutsideClickListener();
      this.menuOutsideClickListener = null;
    }
    if (this.menuScrollListener) {
      this.menuScrollListener();
      this.menuScrollListener = null;
    }
    this.unblockBodyScroll();
  }
  get containerClass() {
    return {
      'layout-slim': this.layoutService.config().menuMode === 'slim',
      'layout-slim-plus': this.layoutService.config().menuMode === 'slim-plus',
      'layout-static': this.layoutService.config().menuMode === 'static',
      'layout-overlay': this.layoutService.config().menuMode === 'overlay',
      'layout-overlay-active': this.layoutService.state.overlayMenuActive,
      'layout-mobile-active': this.layoutService.state.staticMenuMobileActive,
      'layout-static-inactive': this.layoutService.state.staticMenuDesktopInactive && this.layoutService.config().menuMode === 'static',
      'p-input-filled': this.layoutService.config().inputStyle === 'filled',
      'p-ripple-disabled': !this.layoutService.config().ripple,
      'layout-light': this.layoutService.config().layoutTheme === 'colorScheme' && this.layoutService.config().colorScheme === 'light',
      'layout-dark': this.layoutService.config().layoutTheme === 'colorScheme' && this.layoutService.config().colorScheme === 'dark',
      'layout-primary': this.layoutService.config().colorScheme !== 'dark' && this.layoutService.config().layoutTheme === 'primaryColor'
    };
  }
  ngOnDestroy() {
    if (this.overlayMenuOpenSubscription) {
      this.overlayMenuOpenSubscription.unsubscribe();
    }
    if (this.menuOutsideClickListener) {
      this.menuOutsideClickListener();
    }
    if (this.tabOpenSubscription) {
      this.tabOpenSubscription.unsubscribe();
    }
    if (this.tabCloseSubscription) {
      this.tabCloseSubscription.unsubscribe();
    }
  }
  static #_ = this.ɵfac = function AppLayoutComponent_Factory(t) {
    return new (t || AppLayoutComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_app_menu_service__WEBPACK_IMPORTED_MODULE_2__.MenuService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_service_app_layout_service__WEBPACK_IMPORTED_MODULE_3__.LayoutService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_7__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
    type: AppLayoutComponent,
    selectors: [["app-layout"]],
    viewQuery: function AppLayoutComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_app_sidebar_component__WEBPACK_IMPORTED_MODULE_0__.AppSidebarComponent, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_app_topbar_component__WEBPACK_IMPORTED_MODULE_1__.AppTopBarComponent, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.appSidebar = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.appTopbar = _t.first);
      }
    },
    decls: 1,
    vars: 1,
    consts: [["style", "background: url('assets/layout/images/bgflower.svg') no-repeat right center,\n    linear-gradient(178deg, rgba(255,255,255,1) 0%, rgba(251,238,250,1) 100%);\n    background-size: contain;\n    height: 100vh;", 4, "ngIf"], [2, "background", "url('assets/layout/images/bgflower.svg') no-repeat right center,\n    linear-gradient(178deg, rgba(255,255,255,1) 0%, rgba(251,238,250,1) 100%)", "background-size", "contain", "height", "100vh"], [1, "layout-container", 3, "ngClass"], [1, "layout-content-wrapper"], [1, "layout-content"], [1, "layout-content-inner"]],
    template: function AppLayoutComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](0, AppLayoutComponent_div_0_Template, 11, 1, "div", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.userloaded == true);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterOutlet, _config_app_config_component__WEBPACK_IMPORTED_MODULE_4__.AppConfigComponent, _app_topbar_component__WEBPACK_IMPORTED_MODULE_1__.AppTopBarComponent, _app_sidebar_component__WEBPACK_IMPORTED_MODULE_0__.AppSidebarComponent, _app_footer_component__WEBPACK_IMPORTED_MODULE_5__.AppFooterComponent, _app_breadcrumb_component__WEBPACK_IMPORTED_MODULE_6__.AppBreadcrumbComponent],
    encapsulation: 2
  });
}

/***/ }),

/***/ 84295:
/*!*********************************************!*\
  !*** ./src/app/layout/app.layout.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppLayoutModule: () => (/* binding */ AppLayoutModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ 36480);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ 54860);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/platform-browser/animations */ 24987);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/sidebar */ 5026);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/badge */ 67650);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/radiobutton */ 63313);
/* harmony import */ var primeng_inputswitch__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/inputswitch */ 81763);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var _app_menu_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.menu.component */ 57037);
/* harmony import */ var _app_menuitem_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.menuitem.component */ 6093);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _app_topbar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.topbar.component */ 67707);
/* harmony import */ var _app_sidebar_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.sidebar.component */ 65196);
/* harmony import */ var _app_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.footer.component */ 57133);
/* harmony import */ var _config_config_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./config/config.module */ 92913);
/* harmony import */ var _app_layout_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.layout.component */ 79206);
/* harmony import */ var _app_breadcrumb_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.breadcrumb.component */ 70549);
/* harmony import */ var primeng_styleclass__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/styleclass */ 30152);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/tooltip */ 31251);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dropdown */ 94553);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/common */ 26575);



























class AppLayoutModule {
  static #_ = this.ɵfac = function AppLayoutModule_Factory(t) {
    return new (t || AppLayoutModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
    type: AppLayoutModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({
    imports: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.BrowserModule, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpClientModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__.BrowserAnimationsModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_14__.InputTextModule, primeng_inputswitch__WEBPACK_IMPORTED_MODULE_15__.InputSwitchModule, primeng_menu__WEBPACK_IMPORTED_MODULE_16__.MenuModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__.DropdownModule, primeng_sidebar__WEBPACK_IMPORTED_MODULE_19__.SidebarModule, primeng_styleclass__WEBPACK_IMPORTED_MODULE_20__.StyleClassModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.DialogModule, primeng_badge__WEBPACK_IMPORTED_MODULE_22__.BadgeModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_23__.RadioButtonModule, primeng_inputswitch__WEBPACK_IMPORTED_MODULE_15__.InputSwitchModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_24__.RippleModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_25__.TooltipModule, _config_config_module__WEBPACK_IMPORTED_MODULE_5__.AppConfigModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](AppLayoutModule, {
    declarations: [_app_menuitem_component__WEBPACK_IMPORTED_MODULE_1__.AppMenuitemComponent, _app_topbar_component__WEBPACK_IMPORTED_MODULE_2__.AppTopBarComponent, _app_sidebar_component__WEBPACK_IMPORTED_MODULE_3__.AppSidebarComponent, _app_footer_component__WEBPACK_IMPORTED_MODULE_4__.AppFooterComponent, _app_menu_component__WEBPACK_IMPORTED_MODULE_0__.AppMenuComponent, _app_layout_component__WEBPACK_IMPORTED_MODULE_6__.AppLayoutComponent, _app_breadcrumb_component__WEBPACK_IMPORTED_MODULE_7__.AppBreadcrumbComponent],
    imports: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.BrowserModule, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_12__.HttpClientModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__.BrowserAnimationsModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_14__.InputTextModule, primeng_inputswitch__WEBPACK_IMPORTED_MODULE_15__.InputSwitchModule, primeng_menu__WEBPACK_IMPORTED_MODULE_16__.MenuModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__.DropdownModule, primeng_sidebar__WEBPACK_IMPORTED_MODULE_19__.SidebarModule, primeng_styleclass__WEBPACK_IMPORTED_MODULE_20__.StyleClassModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_21__.DialogModule, primeng_badge__WEBPACK_IMPORTED_MODULE_22__.BadgeModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_23__.RadioButtonModule, primeng_inputswitch__WEBPACK_IMPORTED_MODULE_15__.InputSwitchModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_24__.RippleModule, _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouterModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_25__.TooltipModule, _config_config_module__WEBPACK_IMPORTED_MODULE_5__.AppConfigModule],
    exports: [_app_layout_component__WEBPACK_IMPORTED_MODULE_6__.AppLayoutComponent]
  });
})();
_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetComponentScope"](_app_menu_component__WEBPACK_IMPORTED_MODULE_0__.AppMenuComponent, [_angular_common__WEBPACK_IMPORTED_MODULE_26__.NgForOf, _app_menuitem_component__WEBPACK_IMPORTED_MODULE_1__.AppMenuitemComponent], []);

/***/ }),

/***/ 57037:
/*!**********************************************!*\
  !*** ./src/app/layout/app.menu.component.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppMenuComponent: () => (/* binding */ AppMenuComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service/app.layout.service */ 43859);


function AppMenuComponent_li_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "li", 2);
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("item", item_r1)("index", i_r2)("root", true);
  }
}
class AppMenuComponent {
  constructor(layoutService) {
    this.layoutService = layoutService;
    this.model = [];
    this.model_tm = [];
  }
  ngOnInit() {
    this.model = [{
      label: 'Dashboard',
      icon: 'wow wow-dashboard',
      routerLink: ['/'],
      items: [{
        label: 'Dashboard',
        icon: '',
        routerLink: ['/']
      }]
    }, {
      label: 'Schools',
      icon: 'wow wow-classroom',
      visible: localStorage.getItem('userRole') === null,
      routerLink: ['/schools']
    }, {
      label: 'Classrooms',
      icon: 'wow wow-classroom',
      visible: localStorage.getItem('userRole') === 'admin',
      routerLink: ['/classrooms']
    }, {
      label: 'Users',
      icon: 'wow wow-staff',
      visible: localStorage.getItem('userRole') === 'admin',
      routerLink: ['/users']
    }, {
      label: 'Vendors',
      icon: 'wow wow-wowcare-shopping-bag',
      visible: localStorage.getItem('userRole') === 'admin',
      routerLink: ['/'],
      items: [{
        label: 'Category',
        icon: 'pi pi-fw pi-list',
        routerLink: ['/vendors/category-list']
      }, {
        label: 'Vendors',
        icon: 'pi pi-building',
        routerLink: ['/vendors/vendor-list']
      }]
    }];
    this.model_tm = [{
      label: 'menu.DASHBOARD',
      icon: 'pi pi-home',
      items: [{
        label: 'menu.SAAS',
        icon: 'pi pi-desktop',
        routerLink: ['/dashboard']
      }, {
        label: 'menu.SALES',
        icon: 'pi pi-chart-bar',
        routerLink: ['/dashboard/dashboard-sales']
      }]
    }, {
      label: 'menu.UI_KIT',
      icon: 'pi pi-star',
      routerLink: ['/uikit'],
      items: [{
        label: 'menu.FORM_LAYOUT',
        icon: 'pi pi-id-card',
        routerLink: ['/uikit/formlayout']
      }, {
        label: 'menu.INPUT',
        icon: 'pi pi-check-square',
        routerLink: ['/uikit/input']
      }, {
        label: 'menu.FLOAT_LABEL',
        icon: 'pi pi-bookmark',
        routerLink: ['/uikit/floatlabel']
      }, {
        label: 'menu.INVALID_STATE',
        icon: 'pi pi-exclamation-circle',
        routerLink: ['/uikit/invalidstate']
      }, {
        label: 'menu.BUTTON',
        icon: 'pi pi-box',
        routerLink: ['/uikit/button']
      }, {
        label: 'menu.TABLE',
        icon: 'pi pi-table',
        routerLink: ['/uikit/table']
      }, {
        label: 'menu.LIST',
        icon: 'pi pi-list',
        routerLink: ['/uikit/list']
      }, {
        label: 'menu.TREE',
        icon: 'pi pi-share-alt',
        routerLink: ['/uikit/tree']
      }, {
        label: 'menu.PANEL',
        icon: 'pi pi-tablet',
        routerLink: ['/uikit/panel']
      }, {
        label: 'menu.OVERLAY',
        icon: 'pi pi-clone',
        routerLink: ['/uikit/overlay']
      }, {
        label: 'menu.MEDIA',
        icon: 'pi pi-image',
        routerLink: ['/uikit/media']
      }, {
        label: 'menu.MENU',
        icon: 'pi pi-bars',
        routerLink: ['/uikit/menu']
      }, {
        label: 'menu.MESSAGE',
        icon: 'pi pi-comment',
        routerLink: ['/uikit/message']
      }, {
        label: 'menu.FILE',
        icon: 'pi pi-file',
        routerLink: ['/uikit/file']
      }, {
        label: 'menu.CHART',
        icon: 'pi pi-chart-bar',
        routerLink: ['/uikit/charts']
      }, {
        label: 'menu.MISC',
        icon: 'pi pi-circle-off',
        routerLink: ['/uikit/misc']
      }]
    }, {
      label: 'menu.APPS',
      icon: 'pi pi-th-large',
      items: [{
        label: 'menu.BLOG',
        icon: 'pi pi-fw pi-comment',
        items: [{
          label: 'menu.LIST',
          icon: 'pi pi-fw pi-image',
          routerLink: ['/apps/blog/list']
        }, {
          label: 'menu.DETAIL',
          icon: 'pi pi-fw pi-list',
          routerLink: ['/apps/blog/detail']
        }, {
          label: 'menu.EDIT',
          icon: 'pi pi-fw pi-pencil',
          routerLink: ['/apps/blog/edit']
        }]
      }, {
        label: 'menu.CALENDAR',
        icon: 'pi pi-fw pi-calendar',
        routerLink: ['/apps/calendar']
      }, {
        label: 'menu.CHAT',
        icon: 'pi pi-fw pi-comments',
        routerLink: ['/apps/chat']
      }, {
        label: 'menu.FILES',
        icon: 'pi pi-fw pi-folder',
        routerLink: ['/apps/files']
      }, {
        label: 'menu.KANBAN',
        icon: 'pi pi-fw pi-sliders-v',
        routerLink: ['/apps/kanban']
      }, {
        label: 'menu.MAIL',
        icon: 'pi pi-fw pi-envelope',
        items: [{
          label: 'menu.INBOX',
          icon: 'pi pi-fw pi-inbox',
          routerLink: ['/apps/mail/inbox']
        }, {
          label: 'menu.COMPOSE',
          icon: 'pi pi-fw pi-pencil',
          routerLink: ['/apps/mail/compose']
        }, {
          label: 'menu.DETAIL',
          icon: 'pi pi-fw pi-comment',
          routerLink: ['/apps/mail/detail/1000']
        }]
      }, {
        label: 'menu.TASK_LIST',
        icon: 'pi pi-fw pi-check-square',
        routerLink: ['/apps/tasklist']
      }]
    }, {
      label: 'menu.PRIME_BLOCKS',
      icon: 'pi pi-fw pi-prime',
      routerLink: ['/blocks'],
      items: [{
        label: 'menu.FREE_BLOCKS',
        icon: 'pi pi-fw pi-eye',
        routerLink: ['/blocks']
      }, {
        label: 'menu.ALL_BLOCKS',
        icon: 'pi pi-fw pi-globe',
        url: 'https://www.primefaces.org/primeblocks-ng',
        target: '_blank'
      }]
    }, {
      label: 'menu.UTILITIES',
      icon: 'pi pi-fw pi-compass',
      routerLink: ['/utilities'],
      items: [{
        label: 'menu.PRIMEICONS',
        icon: 'pi pi-fw pi-prime',
        routerLink: ['utilities/icons']
      }, {
        label: 'menu.COLORS',
        icon: 'pi pi-fw pi-palette',
        routerLink: ['utilities/colors']
      }, {
        label: 'menu.PRIMEFLEX',
        icon: 'pi pi-fw pi-desktop',
        url: 'https://www.primefaces.org/primeflex/',
        target: '_blank'
      }, {
        label: 'menu.FIGMA',
        icon: 'pi pi-fw pi-pencil',
        url: 'https://www.figma.com/file/PgQXX4HXMPeCkT74tGajod/Preview-%7C-Verona-2022?node-id=1303%3A750',
        target: '_blank'
      }]
    }, {
      label: 'menu.PAGES',
      icon: 'pi pi-fw pi-briefcase',
      items: [{
        label: 'menu.LANDING',
        icon: 'pi pi-fw pi-globe',
        routerLink: ['/landing'],
        data: {
          'fullPage': true
        }
      }, {
        label: 'menu.AUTH',
        icon: 'pi pi-fw pi-user',
        items: [{
          label: 'menu.LOGIN',
          icon: 'pi pi-fw pi-sign-in',
          routerLink: ['/auth/login'],
          data: {
            'fullPage': true
          }
        }, {
          label: 'menu.ERROR',
          icon: 'pi pi-fw pi-times-circle',
          routerLink: ['/auth/error'],
          data: {
            'fullPage': true
          }
        }, {
          label: 'menu.ACCESS_DENIED',
          icon: 'pi pi-fw pi-lock',
          routerLink: ['/auth/access'],
          data: {
            'fullPage': true
          }
        }, {
          label: 'menu.REGISTER',
          icon: 'pi pi-fw pi-user-plus',
          routerLink: ['/auth/register'],
          data: {
            'fullPage': true
          }
        }, {
          label: 'menu.FORGOT_PASSWORD',
          icon: 'pi pi-fw pi-question',
          routerLink: ['/auth/forgotpassword'],
          data: {
            'fullPage': true
          }
        }, {
          label: 'menu.NEW_PASSWORD',
          icon: 'pi pi-fw pi-cog',
          routerLink: ['/auth/newpassword'],
          data: {
            'fullPage': true
          }
        }, {
          label: 'menu.VERIFICATION',
          icon: 'pi pi-fw pi-envelope',
          routerLink: ['/auth/verification'],
          data: {
            'fullPage': true
          }
        }, {
          label: 'menu.LOCK_SCREEN',
          icon: 'pi pi-fw pi-eye-slash',
          routerLink: ['/auth/lockscreen'],
          data: {
            'fullPage': true
          }
        }]
      }, {
        label: 'menu.CRUD',
        icon: 'pi pi-fw pi-pencil',
        routerLink: ['/pages/crud']
      }, {
        label: 'menu.TIMELINE',
        icon: 'pi pi-fw pi-calendar',
        routerLink: ['/pages/timeline']
      }, {
        label: 'menu.INVOICE',
        icon: 'pi pi-fw pi-dollar',
        routerLink: ['/pages/invoice']
      }, {
        label: 'menu.ABOUT_US',
        icon: 'pi pi-fw pi-user',
        routerLink: ['/pages/aboutus']
      }, {
        label: 'menu.HELP',
        icon: 'pi pi-fw pi-question-circle',
        routerLink: ['/pages/help']
      }, {
        label: 'menu.NOT_FOUND',
        icon: 'pi pi-fw pi-exclamation-circle',
        routerLink: ['/pages/notfound']
      }, {
        label: 'menu.EMPTY',
        icon: 'pi pi-fw pi-circle-off',
        routerLink: ['/pages/empty']
      }, {
        label: 'menu.FAQ',
        icon: 'pi pi-fw pi-question',
        routerLink: ['/pages/faq']
      }, {
        label: 'menu.CONTACT_US',
        icon: 'pi pi-fw pi-phone',
        routerLink: ['/pages/contact']
      }]
    }, {
      label: 'menu.E_COMMERCE',
      icon: 'pi pi-fw pi-wallet',
      items: [{
        label: 'menu.PRODUCT_OVERVIEW',
        icon: 'pi pi-fw pi-image',
        routerLink: ['ecommerce/product-overview']
      }, {
        label: 'menu.PRODUCT_LIST',
        icon: 'pi pi-fw pi-list',
        routerLink: ['ecommerce/product-list']
      }, {
        label: 'menu.NEW_PRODUCT',
        icon: 'pi pi-fw pi-plus',
        routerLink: ['ecommerce/new-product']
      }, {
        label: 'menu.SHOPPING_CART',
        icon: 'pi pi-fw pi-shopping-cart',
        routerLink: ['ecommerce/shopping-cart']
      }, {
        label: 'menu.CHECKOUT_FORM',
        icon: 'pi pi-fw pi-check-square',
        routerLink: ['ecommerce/checkout-form']
      }, {
        label: 'menu.ORDER_HISTORY',
        icon: 'pi pi-fw pi-history',
        routerLink: ['ecommerce/order-history']
      }, {
        label: 'menu.ORDER_SUMMARY',
        icon: 'pi pi-fw pi-file',
        routerLink: ['ecommerce/order-summary']
      }]
    }, {
      label: 'menu.USER_MANAGEMENT',
      icon: 'pi pi-fw pi-user',
      items: [{
        label: 'menu.LIST',
        icon: 'pi pi-fw pi-list',
        routerLink: ['profile/list']
      }, {
        label: 'menu.CREATE',
        icon: 'pi pi-fw pi-plus',
        routerLink: ['profile/create']
      }]
    }, {
      label: 'menu.HIERARCHY',
      icon: 'pi pi-align-left',
      items: [{
        label: 'menu.SUBMENU_1',
        icon: 'pi pi-align-left',
        items: [{
          label: 'menu.SUBMENU_1_1',
          icon: 'pi pi-align-left',
          items: [{
            label: 'menu.SUBMENU_1_1_1',
            icon: 'pi pi-align-left'
          }, {
            label: 'menu.SUBMENU_1_1_2',
            icon: 'pi pi-align-left'
          }, {
            label: 'menu.SUBMENU_1_1_3',
            icon: 'pi pi-align-left'
          }]
        }, {
          label: 'menu.SUBMENU_1_2',
          icon: 'pi pi-align-left',
          items: [{
            label: 'menu.SUBMENU_1_2_1',
            icon: 'pi pi-align-left'
          }]
        }]
      }, {
        label: 'menu.SUBMENU_2',
        icon: 'pi pi-align-left',
        items: [{
          label: 'menu.SUBMENU_2_1',
          icon: 'pi pi-align-left',
          items: [{
            label: 'menu.SUBMENU_2_1_1',
            icon: 'pi pi-align-left'
          }, {
            label: 'menu.SUBMENU_2_1_2',
            icon: 'pi pi-align-left'
          }]
        }, {
          label: 'menu.SUBMENU_2_2',
          icon: 'pi pi-align-left',
          items: [{
            label: 'menu.SUBMENU_2_2_1',
            icon: 'pi pi-align-left'
          }]
        }]
      }]
    }, {
      label: 'menu.START',
      icon: 'pi pi-download',
      items: [{
        label: 'menu.BUY_NOW',
        icon: 'pi pi-shopping-cart',
        url: 'https://www.primefaces.org/store'
      }, {
        label: 'menu.DOCUMENTATION',
        icon: 'pi pi-info-circle',
        routerLink: ['/documentation']
      }]
    }];
  }
  static #_ = this.ɵfac = function AppMenuComponent_Factory(t) {
    return new (t || AppMenuComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__.LayoutService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: AppMenuComponent,
    selectors: [["app-menu"]],
    decls: 2,
    vars: 1,
    consts: [[1, "layout-menu"], ["app-menuitem", "", 3, "item", "index", "root", 4, "ngFor", "ngForOf"], ["app-menuitem", "", 3, "item", "index", "root"]],
    template: function AppMenuComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ul", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, AppMenuComponent_li_1_Template, 1, 3, "li", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.model);
      }
    },
    encapsulation: 2
  });
}

/***/ }),

/***/ 60704:
/*!********************************************!*\
  !*** ./src/app/layout/app.menu.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MenuService: () => (/* binding */ MenuService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61699);


class MenuService {
  constructor() {
    this.menuSource = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this.resetSource = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this.menuSource$ = this.menuSource.asObservable();
    this.resetSource$ = this.resetSource.asObservable();
  }
  onMenuStateChange(event) {
    this.menuSource.next(event);
  }
  reset() {
    this.resetSource.next(true);
  }
  static #_ = this.ɵfac = function MenuService_Factory(t) {
    return new (t || MenuService)();
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: MenuService,
    factory: MenuService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 6093:
/*!**************************************************!*\
  !*** ./src/app/layout/app.menuitem.component.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppMenuitemComponent: () => (/* binding */ AppMenuitemComponent)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/animations */ 12501);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 74520);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service/app.layout.service */ 43859);
/* harmony import */ var _app_sidebar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.sidebar.component */ 65196);
/* harmony import */ var _app_menu_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.menu.service */ 60704);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/tooltip */ 31251);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 5939);












const _c0 = ["submenu"];
const _c1 = ["app-menuitem", ""];
function AppMenuitemComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r0.item.label));
  }
}
function AppMenuitemComponent_a_2_i_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "i", 9);
  }
}
function AppMenuitemComponent_a_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "a", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function AppMenuitemComponent_a_2_Template_a_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r5.itemClick($event));
    })("mouseenter", function AppMenuitemComponent_a_2_Template_a_mouseenter_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r7.onMouseEnter());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "i", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, AppMenuitemComponent_a_2_i_6_Template, 1, 0, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r1.item.class)("pTooltip", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](1, 8, ctx_r1.item.label))("tooltipDisabled", !(ctx_r1.isSlim && ctx_r1.root && !ctx_r1.active));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("href", ctx_r1.item.url, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"])("target", ctx_r1.item.target);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r1.item.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 10, ctx_r1.item.label));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.item.items);
  }
}
function AppMenuitemComponent_a_3_i_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "i", 9);
  }
}
const _c2 = () => ({
  paths: "exact",
  queryParams: "ignored",
  matrixParams: "ignored",
  fragment: "ignored"
});
function AppMenuitemComponent_a_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "a", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function AppMenuitemComponent_a_3_Template_a_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r9.itemClick($event));
    })("mouseenter", function AppMenuitemComponent_a_3_Template_a_mouseenter_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r10);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r11.onMouseEnter());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "i", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, AppMenuitemComponent_a_3_i_6_Template, 1, 0, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r2.item.class)("routerLink", ctx_r2.item.routerLink)("routerLinkActiveOptions", ctx_r2.item.routerLinkActiveOptions || _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](20, _c2))("fragment", ctx_r2.item.fragment)("queryParamsHandling", ctx_r2.item.queryParamsHandling)("preserveFragment", ctx_r2.item.preserveFragment)("skipLocationChange", ctx_r2.item.skipLocationChange)("replaceUrl", ctx_r2.item.replaceUrl)("state", ctx_r2.item.state)("queryParams", ctx_r2.item.queryParams)("pTooltip", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](1, 16, ctx_r2.item.label))("tooltipDisabled", !(ctx_r2.isSlim && ctx_r2.root));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("target", ctx_r2.item.target);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r2.item.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 18, ctx_r2.item.label));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.item.items);
  }
}
function AppMenuitemComponent_ul_4_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "li", 13);
  }
  if (rf & 2) {
    const child_r14 = ctx.$implicit;
    const i_r15 = ctx.index;
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"](child_r14.badgeClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("item", child_r14)("index", i_r15)("parentKey", ctx_r13.key);
  }
}
function AppMenuitemComponent_ul_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ul", null, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("@children.done", function AppMenuitemComponent_ul_4_Template_ul_animation_children_done_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r16.onSubmenuAnimated($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, AppMenuitemComponent_ul_4_ng_template_2_Template, 1, 5, "ng-template", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("@children", ctx_r3.submenuAnimation);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r3.item.items);
  }
}
class AppMenuitemComponent {
  constructor(layoutService, cd, appSidebar, router, menuService) {
    this.layoutService = layoutService;
    this.cd = cd;
    this.appSidebar = appSidebar;
    this.router = router;
    this.menuService = menuService;
    this.active = false;
    this.key = "";
    this.menuSourceSubscription = this.menuService.menuSource$.subscribe(value => {
      Promise.resolve(null).then(() => {
        if (value.routeEvent) {
          this.active = value.key === this.key || value.key.startsWith(this.key + '-') ? true : false;
        } else {
          if (value.key !== this.key && !value.key.startsWith(this.key + '-')) {
            this.active = false;
          }
        }
      });
    });
    this.menuResetSubscription = this.menuService.resetSource$.subscribe(() => {
      this.active = false;
    });
    this.router.events.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.filter)(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_5__.NavigationEnd)).subscribe(params => {
      if (this.isSlimPlus || this.isSlim) {
        this.active = false;
      } else {
        if (this.item.routerLink) {
          this.updateActiveStateFromRoute();
        }
      }
    });
  }
  ngOnInit() {
    this.key = this.parentKey ? this.parentKey + '-' + this.index : String(this.index);
    if (!this.isSlim && this.item.routerLink) {
      this.updateActiveStateFromRoute();
    }
  }
  ngAfterViewChecked() {
    if (this.root && this.active && this.layoutService.isDesktop() && (this.layoutService.isSlim() || this.layoutService.isSlimPlus())) {
      this.calculatePosition(this.submenu?.nativeElement, this.submenu?.nativeElement.parentElement);
    }
  }
  onSubmenuAnimated(event) {
    if (event.toState === 'visible' && this.layoutService.isDesktop() && (this.layoutService.isSlim() || this.layoutService.isSlimPlus())) {
      const el = event.element;
      const elParent = el.parentElement;
      this.calculatePosition(el, elParent);
    }
  }
  calculatePosition(overlay, target) {
    if (overlay) {
      const {
        left,
        top
      } = target.getBoundingClientRect();
      const vHeight = window.innerHeight;
      const oHeight = overlay.offsetHeight;
      const topbarEl = document.querySelector('.layout-topbar');
      const topbarHeight = topbarEl?.offsetHeight || 0;
      // reset
      overlay.style.top = '';
      overlay.style.left = '';
      if (this.layoutService.isSlim() || this.layoutService.isSlimPlus()) {
        const topOffset = top - topbarHeight;
        const height = topOffset + oHeight + topbarHeight;
        overlay.style.top = vHeight < height ? `${topOffset - (height - vHeight)}px` : `${topOffset}px`;
      }
    }
  }
  updateActiveStateFromRoute() {
    let activeRoute = this.router.isActive(this.item.routerLink[0], this.item.routerLinkActiveOptions || {
      paths: 'exact',
      queryParams: 'ignored',
      matrixParams: 'ignored',
      fragment: 'ignored'
    });
    if (activeRoute) {
      this.menuService.onMenuStateChange({
        key: this.key,
        routeEvent: true
      });
    }
  }
  itemClick(event) {
    // avoid processing disabled items
    if (this.item.disabled) {
      event.preventDefault();
      return;
    }
    // navigate with hover
    if (this.root && this.isSlim || this.isSlimPlus) {
      this.layoutService.state.menuHoverActive = !this.layoutService.state.menuHoverActive;
    }
    // execute command
    if (this.item.command) {
      this.item.command({
        originalEvent: event,
        item: this.item
      });
    }
    // add tab
    if (event.metaKey && this.item.routerLink && (!this.item.data || !this.item.data.fullPage)) {
      this.layoutService.onTabOpen(this.item);
      event.preventDefault();
    }
    // toggle active state
    if (this.item.items) {
      this.active = !this.active;
      if (this.root && this.active && (this.isSlim || this.isSlimPlus)) {
        this.layoutService.onOverlaySubmenuOpen();
      }
    } else {
      if (this.layoutService.isMobile()) {
        this.layoutService.state.staticMenuMobileActive = false;
      }
      if (this.isSlim || this.isSlimPlus) {
        this.menuService.reset();
        this.layoutService.state.menuHoverActive = false;
      }
    }
    this.menuService.onMenuStateChange({
      key: this.key
    });
  }
  onMouseEnter() {
    // activate item on hover
    if (this.root && (this.isSlim || this.isSlimPlus) && this.layoutService.isDesktop()) {
      if (this.layoutService.state.menuHoverActive) {
        this.active = true;
        this.menuService.onMenuStateChange({
          key: this.key
        });
      }
    }
  }
  get submenuAnimation() {
    if (this.layoutService.isDesktop() && (this.layoutService.isSlim() || this.layoutService.isSlimPlus())) return this.active ? 'visible' : 'hidden';else return this.root ? 'expanded' : this.active ? 'expanded' : 'collapsed';
  }
  get isSlim() {
    return this.layoutService.isSlim();
  }
  get isSlimPlus() {
    return this.layoutService.isSlimPlus();
  }
  get isMobile() {
    return this.layoutService.isMobile();
  }
  get activeClass() {
    return this.active && !this.root;
  }
  ngOnDestroy() {
    if (this.menuSourceSubscription) {
      this.menuSourceSubscription.unsubscribe();
    }
    if (this.menuResetSubscription) {
      this.menuResetSubscription.unsubscribe();
    }
  }
  static #_ = this.ɵfac = function AppMenuitemComponent_Factory(t) {
    return new (t || AppMenuitemComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__.LayoutService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_app_sidebar_component__WEBPACK_IMPORTED_MODULE_1__.AppSidebarComponent), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_app_menu_service__WEBPACK_IMPORTED_MODULE_2__.MenuService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: AppMenuitemComponent,
    selectors: [["", "app-menuitem", ""]],
    viewQuery: function AppMenuitemComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.submenu = _t.first);
      }
    },
    hostVars: 4,
    hostBindings: function AppMenuitemComponent_HostBindings(rf, ctx) {
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("layout-root-menuitem", ctx.root)("active-menuitem", ctx.activeClass);
      }
    },
    inputs: {
      item: "item",
      index: "index",
      root: "root",
      parentKey: "parentKey"
    },
    attrs: _c1,
    decls: 5,
    vars: 4,
    consts: [["class", "layout-menuitem-root-text", 4, "ngIf"], ["tabindex", "0", "pRipple", "", 3, "ngClass", "pTooltip", "tooltipDisabled", "click", "mouseenter", 4, "ngIf"], ["routerLinkActive", "active-route", "tabindex", "0", "pRipple", "", 3, "ngClass", "routerLink", "routerLinkActiveOptions", "fragment", "queryParamsHandling", "preserveFragment", "skipLocationChange", "replaceUrl", "state", "queryParams", "pTooltip", "tooltipDisabled", "click", "mouseenter", 4, "ngIf"], [4, "ngIf"], [1, "layout-menuitem-root-text"], ["tabindex", "0", "pRipple", "", 3, "ngClass", "pTooltip", "tooltipDisabled", "click", "mouseenter"], [1, "layout-menuitem-icon", 3, "ngClass"], [1, "layout-menuitem-text"], ["class", "pi pi-fw pi-angle-down layout-submenu-toggler", 4, "ngIf"], [1, "pi", "pi-fw", "pi-angle-down", "layout-submenu-toggler"], ["routerLinkActive", "active-route", "tabindex", "0", "pRipple", "", 3, "ngClass", "routerLink", "routerLinkActiveOptions", "fragment", "queryParamsHandling", "preserveFragment", "skipLocationChange", "replaceUrl", "state", "queryParams", "pTooltip", "tooltipDisabled", "click", "mouseenter"], ["submenu", ""], ["ngFor", "", 3, "ngForOf"], ["app-menuitem", "", 3, "item", "index", "parentKey"]],
    template: function AppMenuitemComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, AppMenuitemComponent_div_1_Template, 3, 3, "div", 0)(2, AppMenuitemComponent_a_2_Template, 7, 12, "a", 1)(3, AppMenuitemComponent_a_3_Template, 7, 21, "a", 2)(4, AppMenuitemComponent_ul_4_Template, 3, 2, "ul", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.root && ctx.item.visible !== false);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (!ctx.item.routerLink || ctx.item.items) && ctx.item.visible !== false);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.item.routerLink && !ctx.item.items && ctx.item.visible !== false);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.item.items && ctx.item.visible !== false);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterLink, _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterLinkActive, primeng_tooltip__WEBPACK_IMPORTED_MODULE_7__.Tooltip, primeng_ripple__WEBPACK_IMPORTED_MODULE_8__.Ripple, AppMenuitemComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe],
    encapsulation: 2,
    data: {
      animation: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.trigger)('children', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.state)('collapsed', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.style)({
        height: '0'
      })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.state)('expanded', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.style)({
        height: '*'
      })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.state)('hidden', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.style)({
        display: 'none'
      })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.state)('visible', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.style)({
        display: 'block'
      })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.transition)('collapsed <=> expanded', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.animate)('400ms cubic-bezier(0.86, 0, 0.07, 1)'))])]
    }
  });
}

/***/ }),

/***/ 65196:
/*!*************************************************!*\
  !*** ./src/app/layout/app.sidebar.component.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppSidebarComponent: () => (/* binding */ AppSidebarComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service/app.layout.service */ 43859);
/* harmony import */ var _app_menu_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.menu.component */ 57037);



const _c0 = ["menuContainer"];
class AppSidebarComponent {
  constructor(layoutService, el) {
    this.layoutService = layoutService;
    this.el = el;
  }
  static #_ = this.ɵfac = function AppSidebarComponent_Factory(t) {
    return new (t || AppSidebarComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__.LayoutService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.ElementRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: AppSidebarComponent,
    selectors: [["app-sidebar"]],
    viewQuery: function AppSidebarComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.menuContainer = _t.first);
      }
    },
    decls: 4,
    vars: 0,
    consts: [[1, "layout-sidebar"], [1, "layout-menu-container"], ["menuContainer", ""]],
    template: function AppSidebarComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0)(1, "div", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "app-menu");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      }
    },
    dependencies: [_app_menu_component__WEBPACK_IMPORTED_MODULE_1__.AppMenuComponent],
    encapsulation: 2
  });
}

/***/ }),

/***/ 67707:
/*!************************************************!*\
  !*** ./src/app/layout/app.topbar.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppTopBarComponent: () => (/* binding */ AppTopBarComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service/app.layout.service */ 43859);
/* harmony import */ var _core_school_school_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../core/school/school.service */ 62915);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/api */ 98026);
/* harmony import */ var primeng_styleclass__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/styleclass */ 30152);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/ripple */ 51339);










const _c0 = ["searchinput"];
const _c1 = ["menubutton"];
const _c2 = () => ({
  paths: "exact",
  queryParams: "ignored",
  fragment: "ignored",
  matrixParams: "ignored"
});
function AppTopBarComponent_li_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "li")(1, "a", 44)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "i", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppTopBarComponent_li_15_Template_i_click_4_listener($event) {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r9);
      const item_r6 = restoredCtx.$implicit;
      const i_r7 = restoredCtx.index;
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r8.removeTab($event, item_r6, i_r7));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("routerLink", item_r6.routerLink)("routerLinkActiveOptions", item_r6.routerLinkActiveOptions || _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](10, _c2))("fragment", item_r6.fragment)("queryParamsHandling", item_r6.queryParamsHandling)("preserveFragment", item_r6.preserveFragment)("skipLocationChange", item_r6.skipLocationChange)("replaceUrl", item_r6.replaceUrl)("state", item_r6.state)("queryParams", item_r6.queryParams);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r6.label);
  }
}
function AppTopBarComponent_li_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "li", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Use (cmd + click) to open a tab ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
function AppTopBarComponent_li_60_hr_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "hr", 52);
  }
}
const _c3 = a0 => ({
  "selected-school": a0
});
function AppTopBarComponent_li_60_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "li", 47)(1, "a", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppTopBarComponent_li_60_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r14);
      const school_r10 = restoredCtx.$implicit;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      ctx_r13.onSchoolChange(school_r10);
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r13.schoolDialogVisible = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "span", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](6, AppTopBarComponent_li_60_hr_6_Template, 1, 0, "hr", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const school_r10 = ctx.$implicit;
    const last_r11 = ctx.last;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](4, _c3, (ctx_r4.selectedSchool == null ? null : ctx_r4.selectedSchool.code) === school_r10.code));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", school_r10.name == null ? null : school_r10.name.charAt(0), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](school_r10.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !last_r11);
  }
}
function AppTopBarComponent_ng_template_61_Template(rf, ctx) {}
const _c4 = a0 => ({
  "topbar-search-active": a0
});
const _c5 = () => ({
  width: "400px"
});
class AppTopBarComponent {
  constructor(layoutService, schoolService, router, _route) {
    this.layoutService = layoutService;
    this.schoolService = schoolService;
    this.router = router;
    this._route = _route;
    this.menu = [];
    this.schools = [];
    this.selectedSchool = null;
    this.schoolDialogVisible = false;
    this.user = null;
    this.userRole = null;
    this.searchActive = true;
  }
  ngOnInit() {
    const initialData = this._route.snapshot.data['initialData'];
    this.user = initialData?.[1]?.data;
    this.schools = this.user?.schools || [];
    // Try to get selected school code from localStorage
    let selectedCode = localStorage.getItem('selectedSchoolCode');
    if (!selectedCode || !this.schools.some(s => s.code === selectedCode)) {
      selectedCode = this.schools.length > 0 ? this.schools[0].code ?? null : null;
    }
    this.selectedSchool = this.schools.find(s => s.code === selectedCode) || null;
    this.schoolService.school$.subscribe(school => {
      if (school) {
        const found = this.schools.find(s => s.code === school.code);
        this.selectedSchool = found || this.selectedSchool;
      }
    });
  }
  onSchoolChange(school) {
    this.selectedSchool = school;
    if (this.selectedSchool?.code) {
      // Store selected school code in localStorage
      localStorage.setItem('selectedSchoolCode', this.selectedSchool.code);
      this.schoolService.getSchoolByCode(this.selectedSchool.code).subscribe(response => {
        if (response.success && response.data) {
          console.log('School data:', response.data);
        } else {
          console.error('Failed to fetch school data');
        }
      });
    }
  }
  onMenuButtonClick() {
    this.layoutService.onMenuToggle();
  }
  activateSearch() {
    this.searchActive = true;
    setTimeout(() => {
      this.searchInput.nativeElement.focus();
    }, 100);
  }
  deactivateSearch() {
    this.searchActive = true;
  }
  removeTab(event, item, index) {
    this.layoutService.onTabClose(item, index);
    event.preventDefault();
  }
  get layoutTheme() {
    return this.layoutService.config().layoutTheme;
  }
  get colorScheme() {
    return this.layoutService.config().colorScheme;
  }
  get logo() {
    const path = 'assets/layout/images/logo-';
    const logo = this.layoutTheme === 'primaryColor' && !(this.layoutService.config().theme == "yellow") ? 'light.svg' : this.colorScheme === 'light' ? 'dark.svg' : 'light.svg';
    return path + logo;
  }
  get tabs() {
    return this.layoutService.tabs;
  }
  Logout() {
    // Clear userCode and accessToken from localStorage
    localStorage.removeItem('userCode');
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('selectedSchoolCode');
    this.router.navigate(['/login']);
  }
  static #_ = this.ɵfac = function AppTopBarComponent_Factory(t) {
    return new (t || AppTopBarComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__.LayoutService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_core_school_school_service__WEBPACK_IMPORTED_MODULE_1__.SchoolSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: AppTopBarComponent,
    selectors: [["app-topbar"]],
    viewQuery: function AppTopBarComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.searchInput = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.menuButton = _t.first);
      }
    },
    decls: 62,
    vars: 18,
    consts: [[1, "layout-topbar"], ["routerLink", "/", 1, "app-logo"], ["alt", "app logo", 1, "rounded-full", "w-7", "h-7", "object-cover", "shadow-4", "border-circle", "border-2", "border-primary", "flex-shrink-0", "enlarge-on-hover", 3, "src"], [1, "app-name"], ["type", "button", 1, "topbar-menubutton", "p-link", 3, "click"], ["menubutton", ""], [1, "topbar-profile"], ["type", "button", 1, "topbar-profile-button", "p-link", 3, "click"], [1, "profile-details"], [1, "schools-selection"], [1, "pi", "pi-angle-down"], [1, "topbar-menu"], [4, "ngFor", "ngForOf"], ["class", "topbar-menu-empty", 4, "ngIf"], [1, "topbar-search", "hide-on-mobile", "topbar-search-active", 3, "ngClass"], [1, "search-input-wrapper"], [1, "p-input-icon-left"], [1, "pi", "pi-search"], ["type", "text", "pInputText", "", "placeholder", "Search", 3, "blur", "keydown.escape"], ["searchinput", ""], [1, "mobile-search", "show-on-mobile"], ["type", "button", 1, "mobile-search-button", "p-link", 3, "click"], [1, "topbar-right"], [1, "add-button-wrapper"], ["pButton", "", "type", "button", "label", "+ Add", 1, "custom-add-button"], [1, "topbar-notification"], ["type", "button", 1, "notification-button", "p-link"], [1, "wow", "wow-bell"], [1, "notification-badge"], ["type", "button", "pStyleClass", "@next", "enterClass", "hidden", "enterActiveClass", "scalein", "leaveToClass", "hidden", "leaveActiveClass", "fadeout", 1, "topbar-profile-button", "p-link", 3, "hideOnOutsideClick"], ["alt", "avatar", "src", "assets/layout/images/avatar.png"], [1, "profile-name"], [1, "profile-job"], [1, "list-none", "p-3", "m-0", "border-round", "shadow-2", "hidden", "absolute", "surface-overlay", "origin-top", "w-full", "sm:w-12rem", "mt-2", "right-0", "top-auto"], ["pRipple", "", 1, "flex", "p-2", "border-round", "align-items-center", "hover:surface-hover", "transition-colors", "transition-duration-150", "cursor-pointer"], [1, "pi", "pi-user", "mr-3", 2, "color", "#fff"], [2, "color", "#fff"], [1, "pi", "pi-cog", "mr-3", 2, "color", "#fff"], ["pRipple", "", 1, "flex", "p-2", "border-round", "align-items-center", "hover:surface-hover", "transition-colors", "transition-duration-150", "cursor-pointer", 3, "click"], [1, "pi", "pi-power-off", "mr-3", 2, "color", "#fff"], ["header", "Select School", 3, "visible", "modal", "closable", "dismissableMask", "visibleChange"], [1, "school-list", "list-none", "p-0", "m-0"], ["class", "school-list-item", 4, "ngFor", "ngForOf"], ["pTemplate", "footer"], ["routerLinkActive", "active-route", 3, "routerLink", "routerLinkActiveOptions", "fragment", "queryParamsHandling", "preserveFragment", "skipLocationChange", "replaceUrl", "state", "queryParams"], [1, "pi", "pi-times", 3, "click"], [1, "topbar-menu-empty"], [1, "school-list-item"], ["pRipple", "", 1, "flex", "gap-3", "py-3", "px-3", "border-round", "align-items-center", "hover:", "transition-colors", "transition-duration-150", "cursor-pointer", 3, "ngClass", "click"], [2, "display", "inline-flex", "align-items", "center", "justify-content", "center", "width", "32px", "height", "32px", "border-radius", "50%", "background", "#80A3DC", "color", "#fff", "font-weight", "bold", "font-size", "1.1rem", "margin-right", "12px", "text-transform", "uppercase"], [1, "school-name"], ["class", "school-separator my-0", 4, "ngIf"], [1, "school-separator", "my-0"]],
    template: function AppTopBarComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0)(1, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4, "WoWInventory");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "button", 4, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppTopBarComponent_Template_button_click_5_listener() {
          return ctx.onMenuButtonClick();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](7, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "div", 6)(9, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppTopBarComponent_Template_button_click_9_listener() {
          return ctx.schoolDialogVisible = true;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "span", 8)(11, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](13, "i", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "ul", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](15, AppTopBarComponent_li_15_Template, 5, 11, "li", 12)(16, AppTopBarComponent_li_16_Template, 2, 0, "li", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "div", 14)(18, "div", 15)(19, "span", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](20, "i", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "input", 18, 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("blur", function AppTopBarComponent_Template_input_blur_21_listener() {
          return ctx.deactivateSearch();
        })("keydown.escape", function AppTopBarComponent_Template_input_keydown_escape_21_listener() {
          return ctx.deactivateSearch();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "div", 20)(24, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppTopBarComponent_Template_button_click_24_listener() {
          return ctx.activateSearch();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](25, "i", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](26, "div", 22)(27, "div", 23)(28, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](29, " + Add ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](30, "div", 25)(31, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](32, "i", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](33, "span", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](34, "5");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](35, "div", 6)(36, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](37, "img", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "span", 8)(39, "span", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](40);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](41, "span", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](42, "Admin");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](43, "i", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](44, "ul", 33)(45, "li")(46, "a", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](47, "i", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](48, "span", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](49, "Profile");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](50, "a", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](51, "i", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](52, "span", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](53, "Settings");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](54, "a", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppTopBarComponent_Template_a_click_54_listener() {
          return ctx.Logout();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](55, "i", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](56, "span", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](57, "Sign Out");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](58, "p-dialog", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("visibleChange", function AppTopBarComponent_Template_p_dialog_visibleChange_58_listener($event) {
          return ctx.schoolDialogVisible = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](59, "ul", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](60, AppTopBarComponent_li_60_Template, 7, 6, "li", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](61, AppTopBarComponent_ng_template_61_Template, 0, 0, "ng-template", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("src", ctx.logo, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx.selectedSchool == null ? null : ctx.selectedSchool.name);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.tabs);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.tabs || ctx.tabs.length === 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](15, _c4, ctx.searchActive));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("hideOnOutsideClick", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate2"]("", ctx.user == null ? null : ctx.user.firstName, " ", ctx.user == null ? null : ctx.user.lastName, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](17, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("visible", ctx.schoolDialogVisible)("modal", true)("closable", true)("dismissableMask", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.schools);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, primeng_inputtext__WEBPACK_IMPORTED_MODULE_5__.InputText, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLinkActive, primeng_api__WEBPACK_IMPORTED_MODULE_6__.PrimeTemplate, primeng_styleclass__WEBPACK_IMPORTED_MODULE_7__.StyleClass, primeng_dialog__WEBPACK_IMPORTED_MODULE_8__.Dialog, primeng_ripple__WEBPACK_IMPORTED_MODULE_9__.Ripple],
    styles: [".enlarge-on-hover[_ngcontent-%COMP%] {\n  transition: transform 0.3s;\n}\n\n.enlarge-on-hover[_ngcontent-%COMP%]:hover {\n  transform: scale(1.5);\n  cursor: pointer;\n}\n\n.selected-school[_ngcontent-%COMP%] {\n  background-image: linear-gradient(to right, #5978F7, #9C84FF) !important;\n  color: #fff !important;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbGF5b3V0L2FwcC50b3BiYXIuY29tcG9uZW50LnRzIiwid2VicGFjazovLy4vLi4vLi4vTmV3JTIwZm9sZGVyL3Znc2Nob29sLXRoZW1lL3NyYy9hcHAvbGF5b3V0L2FwcC50b3BiYXIuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNZO0VBQ0ksMEJBQUE7QUNBaEI7O0FER1k7RUFDSSxxQkFBQTtFQUNBLGVBQUE7QUNBaEI7O0FER1k7RUFDSSx3RUFBQTtFQUNBLHNCQUFBO0FDQWhCIiwic291cmNlc0NvbnRlbnQiOlsiXG4gICAgICAgICAgICAuZW5sYXJnZS1vbi1ob3ZlciB7XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3M7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5lbmxhcmdlLW9uLWhvdmVyOmhvdmVyIHtcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuNSk7XG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuc2VsZWN0ZWQtc2Nob29sIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgIiwiLmVubGFyZ2Utb24taG92ZXIge1xuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4zcztcbn1cblxuLmVubGFyZ2Utb24taG92ZXI6aG92ZXIge1xuICB0cmFuc2Zvcm06IHNjYWxlKDEuNSk7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLnNlbGVjdGVkLXNjaG9vbCB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzU5NzhGNywgIzlDODRGRikgIWltcG9ydGFudDtcbiAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 1111:
/*!*******************************************************!*\
  !*** ./src/app/layout/config/app.config.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppConfigComponent: () => (/* binding */ AppConfigComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../service/app.layout.service */ 43859);
/* harmony import */ var _app_menu_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app.menu.service */ 60704);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/sidebar */ 5026);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/radiobutton */ 63313);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_inputswitch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/inputswitch */ 81763);









function AppConfigComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, "Menu Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 22)(4, "div", 23)(5, "p-radioButton", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_ng_container_3_Template_p_radioButton_ngModelChange_5_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r4.menuMode = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "label", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, "Static");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "div", 26)(9, "p-radioButton", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_ng_container_3_Template_p_radioButton_ngModelChange_9_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r6.menuMode = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "label", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](11, "Overlay");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "div", 23)(13, "p-radioButton", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_ng_container_3_Template_p_radioButton_ngModelChange_13_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r7.menuMode = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "label", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](15, "Slim");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div", 26)(17, "p-radioButton", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_ng_container_3_Template_p_radioButton_ngModelChange_17_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r8.menuMode = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "label", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](19, "Slim +");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](20, "hr", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx_r0.menuMode);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx_r0.menuMode);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx_r0.menuMode);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx_r0.menuMode);
  }
}
function AppConfigComponent_ng_container_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, "Layout Theme");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 33)(4, "p-radioButton", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_ng_container_15_Template_p_radioButton_ngModelChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r9.menuTheme = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "label", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Color Scheme");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 33)(8, "p-radioButton", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_ng_container_15_Template_p_radioButton_ngModelChange_8_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r10);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r11.menuTheme = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "label", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Primary Color (Light Only)");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx_r1.menuTheme);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx_r1.menuTheme)("disabled", ctx_r1.colorScheme === "dark");
  }
}
function AppConfigComponent_div_19_i_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "i", 40);
  }
}
const _c0 = (a0, a1) => ({
  "background-color": a0,
  "color": a1
});
function AppConfigComponent_div_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div")(1, "a", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppConfigComponent_div_19_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r15);
      const theme_r12 = restoredCtx.$implicit;
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r14.changeTheme(theme_r12.name));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, AppConfigComponent_div_19_i_2_Template, 1, 0, "i", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const theme_r12 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction2"](2, _c0, ctx_r2.colorScheme === "light" ? theme_r12.lightColor : theme_r12.darkColor, ctx_r2.colorScheme === "light" ? "#ffffff" : "#000000"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r2.currentTheme === theme_r12.name);
  }
}
const _c1 = a0 => ({
  "text-primary-500": a0
});
function AppConfigComponent_i_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "i", 41);
  }
  if (rf & 2) {
    const s_r16 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](1, _c1, s_r16 === ctx_r3.scale));
  }
}
class AppConfigComponent {
  get currentTheme() {
    return this.layoutService.config().theme;
  }
  set currentTheme(_val) {
    this.layoutService.config.update(config => ({
      ...config,
      theme: _val
    }));
  }
  get colorScheme() {
    return this.layoutService.config().colorScheme;
  }
  set colorScheme(_val) {
    if (_val == 'dark') {
      this.layoutService.config.update(config => ({
        ...config,
        layoutTheme: 'colorScheme'
      }));
    }
    this.layoutService.config.update(config => ({
      ...config,
      colorScheme: _val
    }));
  }
  get visible() {
    return this.layoutService.state.configSidebarVisible;
  }
  set visible(_val) {
    this.layoutService.state.configSidebarVisible = _val;
  }
  get scale() {
    return this.layoutService.config().scale;
  }
  set scale(_val) {
    this.layoutService.config.update(config => ({
      ...config,
      scale: _val
    }));
  }
  get menuTheme() {
    return this.layoutService.config().layoutTheme;
  }
  set menuTheme(_val) {
    this.layoutService.config.update(config => ({
      ...config,
      layoutTheme: _val
    }));
  }
  get menuMode() {
    return this.layoutService.config().menuMode;
  }
  set menuMode(_val) {
    this.layoutService.config.update(config => ({
      ...config,
      menuMode: _val
    }));
    if (this.layoutService.isSlimPlus() || this.layoutService.isSlim()) {
      this.menuService.reset();
    }
  }
  get inputStyle() {
    return this.layoutService.config().inputStyle;
  }
  set inputStyle(_val) {
    this.layoutService.config.update(config => ({
      ...config,
      inputStyle: _val
    }));
  }
  get ripple() {
    return this.layoutService.config().ripple;
  }
  set ripple(_val) {
    this.layoutService.config.update(config => ({
      ...config,
      menuTheme: _val
    }));
  }
  constructor(layoutService, menuService) {
    this.layoutService = layoutService;
    this.menuService = menuService;
    this.minimal = false;
    this.componentThemes = [];
    this.scales = [12, 13, 14, 15, 16];
  }
  ngOnInit() {
    this.componentThemes = [{
      name: 'indigo',
      lightColor: '#4C63B6',
      darkColor: '#6A7EC2'
    }, {
      name: 'blue',
      lightColor: '#1992D4',
      darkColor: '#3BABE8'
    }, {
      name: 'green',
      lightColor: '#27AB83',
      darkColor: '#44D4A9'
    }, {
      name: 'deeppurple',
      lightColor: '#896FF4',
      darkColor: '#B1A0F8'
    }, {
      name: 'orange',
      lightColor: '#DE911D',
      darkColor: '#E8AB4F'
    }, {
      name: 'cyan',
      lightColor: '#00B9C6',
      darkColor: '#58CDD5'
    }, {
      name: 'yellow',
      lightColor: '#F9C404',
      darkColor: '#FDDD68'
    }, {
      name: 'pink',
      lightColor: '#C74B95',
      darkColor: '#D77FB4'
    }, {
      name: 'purple',
      lightColor: '#BA6FF4',
      darkColor: '#D1A0F8'
    }, {
      name: 'lime',
      lightColor: '#84BD20',
      darkColor: '#A3D44E'
    }];
  }
  changeTheme(theme) {
    this.currentTheme = theme;
  }
  isIE() {
    return /(MSIE|Trident\/|Edge\/)/i.test(window.navigator.userAgent);
  }
  onConfigButtonClick() {
    this.layoutService.showConfigSidebar();
  }
  decrementScale() {
    this.scale--;
  }
  incrementScale() {
    this.scale++;
  }
  static #_ = this.ɵfac = function AppConfigComponent_Factory(t) {
    return new (t || AppConfigComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_service_app_layout_service__WEBPACK_IMPORTED_MODULE_0__.LayoutService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_app_menu_service__WEBPACK_IMPORTED_MODULE_1__.MenuService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: AppConfigComponent,
    selectors: [["app-config"]],
    inputs: {
      minimal: "minimal"
    },
    decls: 41,
    vars: 13,
    consts: [["type", "button", 1, "layout-config-button", "p-link", 2, "cursor", "pointer", 3, "click"], [1, "pi", "pi-cog"], ["position", "right", "styleClass", "layout-config-sidebar w-18rem", 3, "visible", "transitionOptions", "visibleChange"], [4, "ngIf"], [1, "flex"], [1, "field-radiobutton", "flex-1"], ["name", "colorScheme", "value", "light", "inputId", "scheme1", 3, "ngModel", "ngModelChange"], ["for", "scheme1"], ["name", "colorScheme", "value", "dark", "inputId", "scheme2", 3, "ngModel", "ngModelChange"], ["for", "scheme2"], [1, "flex", "flex-wrap", "gap-3"], [4, "ngFor", "ngForOf"], [1, "flex", "align-items-center"], ["icon", "pi pi-minus", "type", "button", "pButton", "", 1, "p-button-text", "p-button-rounded", "w-2rem", "h-2rem", "mr-2", 3, "disabled", "click"], [1, "flex", "gap-3", "align-items-center"], ["class", "pi pi-circle-fill text-300", 3, "ngClass", 4, "ngFor", "ngForOf"], ["icon", "pi pi-plus", "type", "button", "pButton", "", 1, "p-button-text", "p-button-rounded", "w-2rem", "h-2rem", "ml-2", 3, "disabled", "click"], ["name", "inputStyle", "value", "outlined", "inputId", "inputStyle1", 3, "ngModel", "ngModelChange"], ["for", "inputStyle1"], ["name", "inputStyle", "value", "filled", "inputId", "inputStyle2", 3, "ngModel", "ngModelChange"], ["for", "inputStyle2"], [3, "ngModel", "ngModelChange"], [1, "flex", "flex-wrap", "row-gap-3"], [1, "flex", "align-items-center", "gap-2", "w-6"], ["name", "menuMode", "value", "static", "inputId", "mode1", 3, "ngModel", "ngModelChange"], ["for", "mode1"], [1, "flex", "align-items-center", "gap-2", "w-6", "pl-2"], ["name", "menuMode", "value", "overlay", "inputId", "mode2", 3, "ngModel", "ngModelChange"], ["for", "mode2"], ["name", "menuMode", "value", "slim", "inputId", "mode3", 3, "ngModel", "ngModelChange"], ["for", "mode3"], ["name", "menuMode", "value", "slim-plus", "inputId", "mode4", 3, "ngModel", "ngModelChange"], [1, "surface-border"], [1, "field-radiobutton"], ["name", "menuTheme", "value", "colorScheme", "inputId", "menutheme-colorscheme", 3, "ngModel", "ngModelChange"], ["for", "menutheme-colorscheme"], ["name", "menuTheme", "value", "primaryColor", "inputId", "menutheme-primarycolor", 3, "ngModel", "disabled", "ngModelChange"], ["for", "menutheme-primarycolor"], [1, "inline-flex", "justify-content-center", "align-items-center", "w-2rem", "h-2rem", "border-round", 2, "cursor", "pointer", 3, "ngStyle", "click"], ["class", "pi pi-check", 4, "ngIf"], [1, "pi", "pi-check"], [1, "pi", "pi-circle-fill", "text-300", 3, "ngClass"]],
    template: function AppConfigComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppConfigComponent_Template_button_click_0_listener() {
          return ctx.onConfigButtonClick();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "i", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "p-sidebar", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("visibleChange", function AppConfigComponent_Template_p_sidebar_visibleChange_2_listener($event) {
          return ctx.visible = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, AppConfigComponent_ng_container_3_Template, 21, 4, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5, "Color Scheme");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "div", 4)(7, "div", 5)(8, "p-radioButton", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_Template_p_radioButton_ngModelChange_8_listener($event) {
          return ctx.colorScheme = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "label", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Light");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "div", 5)(12, "p-radioButton", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_Template_p_radioButton_ngModelChange_12_listener($event) {
          return ctx.colorScheme = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14, "Dark");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](15, AppConfigComponent_ng_container_15_Template, 11, 3, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](17, "Themes");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](19, AppConfigComponent_div_19_Template, 3, 5, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](21, "Scale");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 12)(23, "button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppConfigComponent_Template_button_click_23_listener() {
          return ctx.decrementScale();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](25, AppConfigComponent_i_25_Template, 1, 3, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](26, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function AppConfigComponent_Template_button_click_26_listener() {
          return ctx.incrementScale();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](27, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](28, "Input Style");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "div", 4)(30, "div", 5)(31, "p-radioButton", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_Template_p_radioButton_ngModelChange_31_listener($event) {
          return ctx.inputStyle = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](32, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](33, "Outlined");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "div", 5)(35, "p-radioButton", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_Template_p_radioButton_ngModelChange_35_listener($event) {
          return ctx.inputStyle = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "label", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](37, "Filled");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](39, "Ripple Effect");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](40, "p-inputSwitch", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function AppConfigComponent_Template_p_inputSwitch_ngModelChange_40_listener($event) {
          return ctx.ripple = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("visible", ctx.visible)("transitionOptions", ".3s cubic-bezier(0, 0, 0.2, 1)");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.minimal);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.colorScheme);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.colorScheme);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.minimal);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.componentThemes);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.scale === ctx.scales[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.scales);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.scale === ctx.scales[ctx.scales.length - 1]);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.inputStyle);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.inputStyle);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.ripple);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgModel, primeng_sidebar__WEBPACK_IMPORTED_MODULE_5__.Sidebar, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_6__.RadioButton, primeng_button__WEBPACK_IMPORTED_MODULE_7__.ButtonDirective, primeng_inputswitch__WEBPACK_IMPORTED_MODULE_8__.InputSwitch],
    encapsulation: 2
  });
}

/***/ }),

/***/ 92913:
/*!************************************************!*\
  !*** ./src/app/layout/config/config.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppConfigModule: () => (/* binding */ AppConfigModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/sidebar */ 5026);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/radiobutton */ 63313);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_inputswitch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/inputswitch */ 81763);
/* harmony import */ var _app_config_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.config.component */ 1111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61699);








class AppConfigModule {
  static #_ = this.ɵfac = function AppConfigModule_Factory(t) {
    return new (t || AppConfigModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
    type: AppConfigModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormsModule, primeng_sidebar__WEBPACK_IMPORTED_MODULE_4__.SidebarModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_5__.RadioButtonModule, primeng_button__WEBPACK_IMPORTED_MODULE_6__.ButtonModule, primeng_inputswitch__WEBPACK_IMPORTED_MODULE_7__.InputSwitchModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppConfigModule, {
    declarations: [_app_config_component__WEBPACK_IMPORTED_MODULE_0__.AppConfigComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormsModule, primeng_sidebar__WEBPACK_IMPORTED_MODULE_4__.SidebarModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_5__.RadioButtonModule, primeng_button__WEBPACK_IMPORTED_MODULE_6__.ButtonModule, primeng_inputswitch__WEBPACK_IMPORTED_MODULE_7__.InputSwitchModule],
    exports: [_app_config_component__WEBPACK_IMPORTED_MODULE_0__.AppConfigComponent]
  });
})();

/***/ }),

/***/ 43859:
/*!******************************************************!*\
  !*** ./src/app/layout/service/app.layout.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LayoutService: () => (/* binding */ LayoutService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 72513);



class LayoutService {
  constructor() {
    this._config = {
      ripple: false,
      inputStyle: 'outlined',
      menuMode: 'slim-plus',
      colorScheme: 'light',
      theme: 'indigo',
      layoutTheme: 'colorScheme',
      scale: 14
    };
    this.config = (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.signal)(this._config);
    this.state = {
      staticMenuDesktopInactive: false,
      overlayMenuActive: false,
      profileSidebarVisible: false,
      configSidebarVisible: false,
      staticMenuMobileActive: false,
      menuHoverActive: false
    };
    this.tabs = [];
    this.configUpdate = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.overlayOpen = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.tabOpen = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.tabClose = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.configUpdate$ = this.configUpdate.asObservable();
    this.overlayOpen$ = this.overlayOpen.asObservable();
    this.tabOpen$ = this.tabOpen.asObservable();
    this.tabClose$ = this.tabClose.asObservable();
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.effect)(() => {
      const config = this.config();
      if (this.updateStyle(config)) {
        this.changeTheme();
      }
      this.changeScale(config.scale);
      this.onConfigUpdate();
    });
  }
  updateStyle(config) {
    return config.theme !== this._config.theme || config.colorScheme !== this._config.colorScheme;
  }
  changeTheme() {
    const config = this.config();
    const themeLink = document.getElementById('theme-link');
    const themeLinkHref = themeLink.getAttribute('href');
    const newHref = themeLinkHref.split('/').map(el => el == this._config.theme ? el = config.theme : el == `theme-${this._config.colorScheme}` ? el = `theme-${config.colorScheme}` : el).join('/');
    this.replaceThemeLink(newHref);
  }
  replaceThemeLink(href) {
    const id = 'theme-link';
    let themeLink = document.getElementById(id);
    const cloneLinkElement = themeLink.cloneNode(true);
    cloneLinkElement.setAttribute('href', href);
    cloneLinkElement.setAttribute('id', id + '-clone');
    themeLink.parentNode.insertBefore(cloneLinkElement, themeLink.nextSibling);
    cloneLinkElement.addEventListener('load', () => {
      themeLink.remove();
      cloneLinkElement.setAttribute('id', id);
    });
  }
  onMenuToggle() {
    if (this.isOverlay()) {
      this.state.overlayMenuActive = !this.state.overlayMenuActive;
      if (this.state.overlayMenuActive) {
        this.overlayOpen.next(null);
      }
    }
    if (this.isDesktop()) {
      this.state.staticMenuDesktopInactive = !this.state.staticMenuDesktopInactive;
    } else {
      this.state.staticMenuMobileActive = !this.state.staticMenuMobileActive;
      if (this.state.staticMenuMobileActive) {
        this.overlayOpen.next(null);
      }
    }
  }
  onOverlaySubmenuOpen() {
    this.overlayOpen.next(null);
  }
  showProfileSidebar() {
    this.state.profileSidebarVisible = true;
  }
  showConfigSidebar() {
    this.state.configSidebarVisible = true;
  }
  isDesktop() {
    return window.innerWidth > 991;
  }
  isOverlay() {
    return this.config().menuMode === 'overlay';
  }
  isSlim() {
    return this.config().menuMode === 'slim';
  }
  isSlimPlus() {
    return this.config().menuMode === 'slim-plus';
  }
  isMobile() {
    return !this.isDesktop();
  }
  onConfigUpdate() {
    this._config = {
      ...this.config()
    };
    this.configUpdate.next(this.config());
  }
  onTabOpen(value) {
    this.tabOpen.next(value);
  }
  openTab(value) {
    this.tabs = [...this.tabs, value];
  }
  onTabClose(value, index) {
    this.tabClose.next({
      tab: value,
      index: index
    });
  }
  closeTab(index) {
    this.tabs.splice(index, 1);
    this.tabs = [...this.tabs];
  }
  changeScale(value) {
    document.documentElement.style.fontSize = `${value}px`;
  }
  static #_ = this.ɵfac = function LayoutService_Factory(t) {
    return new (t || LayoutService)();
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
    token: LayoutService,
    factory: LayoutService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 20553:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   environment: () => (/* binding */ environment)
/* harmony export */ });
const environment = {
  production: false,
  serviceUrl: 'https://qa.childcarewow.app/wowcare-qa/api',
  // serviceUrl: 'http://localhost:8181/api',
  useHash: false,
  configFile: 'assets/layout/config/config.qa.json',
  path: '/wowcare-qa',
  apiUrl: 'https://wow.atoconn.com/web-api',
  firebase: {
    apiKey: "AIzaSyBVxR3BIo7CQ-lzMvKp-nEfAXYhYcDELno",
    authDomain: "schoolerp-176c3.firebaseapp.com",
    projectId: "schoolerp-176c3",
    storageBucket: "schoolerp-176c3.firebasestorage.app",
    messagingSenderId: "761560068017",
    appId: "1:761560068017:web:4d335a19ac588f13939790",
    measurementId: "G-QBFS0F9LJT"
  }
};

/***/ }),

/***/ 14913:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 36480);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 78629);


_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14913)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map