"use strict";
(self["webpackChunkverona_ng"] = self["webpackChunkverona_ng"] || []).push([["src_app_modules_app_classroom_classroom_module_ts"],{

/***/ 68712:
/*!*******************************************************************!*\
  !*** ./src/app/modules/app/classroom/classroom-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClassroomRoutingModule: () => (/* binding */ ClassroomRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var _list_list_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list/list.component */ 42065);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61699);




class ClassroomRoutingModule {
  static #_ = this.ɵfac = function ClassroomRoutingModule_Factory(t) {
    return new (t || ClassroomRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
    type: ClassroomRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forChild([{
      path: '',
      component: _list_list_component__WEBPACK_IMPORTED_MODULE_0__.ClassroomListComponent,
      pathMatch: 'full'
    }]), _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](ClassroomRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
  });
})();

/***/ }),

/***/ 90307:
/*!***********************************************************!*\
  !*** ./src/app/modules/app/classroom/classroom.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClassroomModule: () => (/* binding */ ClassroomModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/fileupload */ 88285);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_toolbar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/toolbar */ 39177);
/* harmony import */ var primeng_rating__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/rating */ 85583);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/inputtextarea */ 30652);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/dropdown */ 94553);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/radiobutton */ 63313);
/* harmony import */ var primeng_inputnumber__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/inputnumber */ 65362);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var _classroom_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./classroom-routing.module */ 68712);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/splitbutton */ 64323);
/* harmony import */ var primeng_progressbar__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/progressbar */ 22506);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/calendar */ 57411);
/* harmony import */ var _list_list_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list/list.component */ 42065);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61699);






















class ClassroomModule {
  static #_ = this.ɵfac = function ClassroomModule_Factory(t) {
    return new (t || ClassroomModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
    type: ClassroomModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.ReactiveFormsModule, _classroom_routing_module__WEBPACK_IMPORTED_MODULE_0__.ClassroomRoutingModule, primeng_table__WEBPACK_IMPORTED_MODULE_5__.TableModule, primeng_fileupload__WEBPACK_IMPORTED_MODULE_6__.FileUploadModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_7__.ButtonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_8__.RippleModule, primeng_toast__WEBPACK_IMPORTED_MODULE_9__.ToastModule, primeng_toolbar__WEBPACK_IMPORTED_MODULE_10__.ToolbarModule, primeng_rating__WEBPACK_IMPORTED_MODULE_11__.RatingModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_12__.InputTextModule, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_13__.InputTextareaModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_14__.DropdownModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_15__.RadioButtonModule, primeng_inputnumber__WEBPACK_IMPORTED_MODULE_16__.InputNumberModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_17__.DialogModule, primeng_button__WEBPACK_IMPORTED_MODULE_7__.ButtonModule, primeng_splitbutton__WEBPACK_IMPORTED_MODULE_18__.SplitButtonModule, primeng_progressbar__WEBPACK_IMPORTED_MODULE_19__.ProgressBarModule, primeng_menu__WEBPACK_IMPORTED_MODULE_20__.MenuModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule, primeng_calendar__WEBPACK_IMPORTED_MODULE_21__.CalendarModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ClassroomModule, {
    declarations: [_list_list_component__WEBPACK_IMPORTED_MODULE_1__.ClassroomListComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.ReactiveFormsModule, _classroom_routing_module__WEBPACK_IMPORTED_MODULE_0__.ClassroomRoutingModule, primeng_table__WEBPACK_IMPORTED_MODULE_5__.TableModule, primeng_fileupload__WEBPACK_IMPORTED_MODULE_6__.FileUploadModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_7__.ButtonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_8__.RippleModule, primeng_toast__WEBPACK_IMPORTED_MODULE_9__.ToastModule, primeng_toolbar__WEBPACK_IMPORTED_MODULE_10__.ToolbarModule, primeng_rating__WEBPACK_IMPORTED_MODULE_11__.RatingModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_12__.InputTextModule, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_13__.InputTextareaModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_14__.DropdownModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_15__.RadioButtonModule, primeng_inputnumber__WEBPACK_IMPORTED_MODULE_16__.InputNumberModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_17__.DialogModule, primeng_button__WEBPACK_IMPORTED_MODULE_7__.ButtonModule, primeng_splitbutton__WEBPACK_IMPORTED_MODULE_18__.SplitButtonModule, primeng_progressbar__WEBPACK_IMPORTED_MODULE_19__.ProgressBarModule, primeng_menu__WEBPACK_IMPORTED_MODULE_20__.MenuModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule, primeng_calendar__WEBPACK_IMPORTED_MODULE_21__.CalendarModule]
  });
})();

/***/ }),

/***/ 61485:
/*!************************************************************!*\
  !*** ./src/app/modules/app/classroom/classroom.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClassroomService: () => (/* binding */ ClassroomService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 58071);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 13738);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2389);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 33252);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 81527);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 81891);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 20553);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 54860);




class ClassroomService {
  constructor(_httpClient) {
    this._httpClient = _httpClient;
    // Base URLs
    this.BASE_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl;
    this.CLASSROOMS_URL = `${this.BASE_URL}/classrooms`;
    // BehaviorSubjects
    this._classroom = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this._classrooms = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    // Add new BehaviorSubject
    this._classroomsWithRequests = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
  }
  // Add accessor
  get classroomsWithRequests$() {
    return this._classroomsWithRequests.asObservable();
  }
  // Accessors
  get classroom$() {
    return this._classroom.asObservable();
  }
  get classrooms$() {
    return this._classrooms.asObservable();
  }
  // Add method to fetch classrooms with requests
  getClassroomsWithRequests(schoolCode) {
    return this._httpClient.get(`${this.BASE_URL}/inventory/classroom/school/${schoolCode}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._classroomsWithRequests.next(response.data);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to fetch classrooms with requests:', error);
      const errorResponse = error?.error || {
        success: false,
        message: error.message || 'Failed to fetch classrooms with requests',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }));
  }
  createClassroom(classroom) {
    return this.classrooms$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(classrooms => this._httpClient.post(this.CLASSROOMS_URL, classroom).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this._classrooms.next([response.data, ...(classrooms || [])]);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to create classroom:', error);
      const errorResponse = error?.error || {
        success: false,
        message: error.message || 'Failed to create classroom',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  updateClassroom(classroom) {
    return this.classrooms$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(classrooms => this._httpClient.put(`${this.CLASSROOMS_URL}/${classroom.code}`, classroom).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        const index = classrooms?.findIndex(item => item.code === classroom.code) ?? -1;
        if (index !== -1 && classrooms) {
          classrooms[index] = response.data;
          this._classrooms.next(classrooms);
        }
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to update classroom:', error);
      const errorResponse = error?.error || {
        success: false,
        message: error.message || 'Failed to update classroom',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  deleteClassroom(code) {
    return this.classrooms$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(classrooms => this._httpClient.delete(`${this.CLASSROOMS_URL}/${code}`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && classrooms) {
        const filteredClassrooms = classrooms.filter(item => item.code !== code);
        this._classrooms.next(filteredClassrooms);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
      console.error('Failed to delete classroom:', error);
      const errorResponse = error?.error || {
        success: false,
        message: error.message || 'Failed to delete classroom',
        data: null,
        timestamp: new Date()
      };
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(() => errorResponse);
    }))));
  }
  static #_ = this.ɵfac = function ClassroomService_Factory(t) {
    return new (t || ClassroomService)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjectable"]({
    token: ClassroomService,
    factory: ClassroomService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 42065:
/*!**************************************************************!*\
  !*** ./src/app/modules/app/classroom/list/list.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClassroomListComponent: () => (/* binding */ ClassroomListComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/api */ 98026);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var src_app_core_classroom_classroom_shared_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/classroom/classroom-shared.types */ 16280);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var src_app_core_classroom_classroom_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/classroom/classroom-shared.service */ 20823);
/* harmony import */ var _classroom_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../classroom.service */ 61485);
/* harmony import */ var src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/school/school.service */ 62915);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/calendar */ 57411);



















function ClassroomListComponent_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 24)(1, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "i", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "input", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("input", function ClassroomListComponent_ng_template_13_Template_input_input_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](12);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.onGlobalFilter(_r0, $event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "p-calendar", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function ClassroomListComponent_ng_template_13_Template_p_calendar_ngModelChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r8.dateRange = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ClassroomListComponent_ng_template_13_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](12);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r9.clearFilters(_r0));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx_r1.dateRange)("showIcon", true)("showOnFocus", false)("readonlyInput", true)("appendTo", "body");
  }
}
function ClassroomListComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, " Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "p-sortIcon", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "th", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, " Pending Requests ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "p-sortIcon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "th", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, " Completed Requests ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "p-sortIcon", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, " Total Consumption ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](12, "p-sortIcon", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "th", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, " Status ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](15, "p-sortIcon", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "th", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, "Action");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
const _c0 = () => ({
  "min-width": "24px",
  width: "24px",
  height: "24px",
  padding: "0"
});
function ClassroomListComponent_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td")(2, "span", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "td", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "td", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "td", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "td")(11, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "td", 43)(14, "button", 44, 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ClassroomListComponent_ng_template_15_Template_button_click_14_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r14);
      const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](17);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](_r12.toggle($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](16, "p-menu", 46, 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const classroomWithRequests_r10 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleProp"]("background-color", ctx_r3.getChipColor(classroomWithRequests_r10.classroom == null ? null : classroomWithRequests_r10.classroom.name).bg)("color", ctx_r3.getChipColor(classroomWithRequests_r10.classroom == null ? null : classroomWithRequests_r10.classroom.name).text);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", classroomWithRequests_r10.classroom == null ? null : classroomWithRequests_r10.classroom.name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", (classroomWithRequests_r10.stockRequests == null ? null : classroomWithRequests_r10.stockRequests.requestPending) || 0, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", (classroomWithRequests_r10.stockRequests == null ? null : classroomWithRequests_r10.stockRequests.requestCompleted) || 0, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", (classroomWithRequests_r10.stockRequests == null ? null : classroomWithRequests_r10.stockRequests.consumption) || 0, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassMap"]("status-badge status-" + (classroomWithRequests_r10.classroom == null ? null : classroomWithRequests_r10.classroom.status == null ? null : classroomWithRequests_r10.classroom.status.toLowerCase()));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", classroomWithRequests_r10.classroom == null ? null : classroomWithRequests_r10.classroom.status, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](16, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("popup", true)("model", ctx_r3.getActionItems(classroomWithRequests_r10))("appendTo", "body");
  }
}
function ClassroomListComponent_ng_template_16_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "i", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "span", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Loading classrooms...");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }
}
function ClassroomListComponent_ng_template_16_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "i", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "span", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "No classrooms available");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "span", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, " Add new classrooms using the 'Add Classroom' button ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function ClassroomListComponent_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td", 48)(2, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, ClassroomListComponent_ng_template_16_ng_container_3_Template, 4, 0, "ng-container", 50)(4, ClassroomListComponent_ng_template_16_ng_template_4_Template, 5, 0, "ng-template", null, 51, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](5);
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r4.isClassroomLoading)("ngIfElse", _r17);
  }
}
function ClassroomListComponent_ng_template_18_small_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "small", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Name is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
const _c1 = () => ({
  height: "40px",
  border: "1px solid #57335366",
  borderRadius: "8px"
});
const _c2 = "linear-gradient(90deg, #5978F7 0%, #9C84FF 100%) !important";
const _c3 = () => ({
  width: "177.21px",
  height: "48px",
  gap: "8.7px",
  borderRadius: "6.96px",
  background: _c2,
  border: "none"
});
function ClassroomListComponent_ng_template_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 57)(1, "div", 58)(2, "label", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Classroom Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "input", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ClassroomListComponent_ng_template_18_small_5_Template, 2, 0, "small", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 62)(7, "button", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ClassroomListComponent_ng_template_18_Template_button_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r20);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r19.classroom.code ? ctx_r19.updateClassroom() : ctx_r19.saveClassroom());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    let tmp_2_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r5.classroomForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](9, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_2_0 = ctx_r5.classroomForm.get("name")) == null ? null : tmp_2_0.touched) && ((tmp_2_0 = ctx_r5.classroomForm.get("name")) == null ? null : tmp_2_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](10, _c3));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("icon", ctx_r5.submitted ? "pi pi-spinner pi-spin" : "")("label", ctx_r5.submitted ? "" : ctx_r5.classroom.code ? "Update" : "Add")("disabled", ctx_r5.classroomForm.invalid || ctx_r5.submitted);
  }
}
const _c4 = () => ["classroom.name", "classroom.status"];
const _c5 = () => ({
  width: "450px"
});
const _c6 = () => ({
  width: "480px"
});
class ClassroomListComponent {
  constructor(_classroomSharedService, _classroomService, _schoolService, _messageService, _confirmationService, _formBuilder, _changeDetectorRef) {
    this._classroomSharedService = _classroomSharedService;
    this._classroomService = _classroomService;
    this._schoolService = _schoolService;
    this._messageService = _messageService;
    this._confirmationService = _confirmationService;
    this._formBuilder = _formBuilder;
    this._changeDetectorRef = _changeDetectorRef;
    this.submitted = false;
    // Date Range
    this.dateRange = null;
    // Data
    this.school = {};
    this.classroom = {
      name: '',
      schoolCode: ''
    };
    this.classroomWithRequests = [];
    this.selectedClassroomWithRequests = {};
    this.isClassroomLoading = true; // Add this property
    // UI States
    this.classroomDialog = false;
    this.deleteClassroomDialog = false;
    // Table
    this.cols = [{
      field: 'classroom.name',
      header: 'Name'
    }, {
      field: 'stockRequests.requestPending',
      header: 'Pending Requests'
    }, {
      field: 'stockRequests.requestCompleted',
      header: 'Completed Requests'
    }, {
      field: 'stockRequests.consumption',
      header: 'Total Consumption'
    }, {
      field: 'classroom.status',
      header: 'Status'
    }];
    this.rowsPerPageOptions = [5, 10, 20];
    this.sortField = '';
    this.sortOrder = 1;
    // Color mapping for classroom name chips
    this.colorMap = {
      'orange': {
        bg: '#FDA758',
        text: '#1B237E'
      },
      'pink': {
        bg: '#F67EAF',
        text: '#1B237E'
      },
      'blue': {
        bg: '#80A3DC',
        text: '#1B237E'
      },
      'violet': {
        bg: '#9C84FF',
        text: '#1B237E'
      },
      'purple': {
        bg: '#CB9AFC',
        text: '#1B237E'
      },
      'yellow': {
        bg: '#FDCD16',
        text: '#1B237E'
      }
    };
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
  }
  ngOnInit() {
    this.initForm();
    this.subscribeToSchool();
  }
  ngOnDestroy() {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
  initForm() {
    this.classroomForm = this._formBuilder.group({
      name: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100)]],
      status: [src_app_core_classroom_classroom_shared_types__WEBPACK_IMPORTED_MODULE_0__.ClassroomStatus.ACTIVE]
    });
  }
  subscribeToSchool() {
    this._schoolService.school$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._unsubscribeAll)).subscribe(school => {
      if (school?.code) {
        this.school = school;
        this._classroomService.getClassroomsWithRequests(school.code).subscribe();
      }
      this._changeDetectorRef.markForCheck();
    });
    this.subscribeToClassrooms();
  }
  subscribeToClassrooms() {
    this._classroomService.classroomsWithRequests$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._unsubscribeAll)).subscribe(classroomWithRequests => {
      if (classroomWithRequests) {
        this.classroomWithRequests = classroomWithRequests;
      }
      this.isClassroomLoading = false; // Add this property
      this._changeDetectorRef.markForCheck();
    });
  }
  // Get background color based on classroom name
  getChipColor(name) {
    const lowerName = name?.toLowerCase() || '';
    // Check if classroom name contains any of the color keywords
    for (const [color, styles] of Object.entries(this.colorMap)) {
      if (lowerName.includes(color)) {
        return styles;
      }
    }
    // Default color if no match found
    return {
      bg: '#eeecff',
      text: '#1B237E'
    };
  }
  createNewClassroom() {
    this.classroom = {
      name: '',
      schoolCode: ''
    };
    this.submitted = false;
    this.classroomDialog = true;
  }
  saveClassroom() {
    this.submitted = true;
    if (this.classroomForm.valid) {
      const classroomData = {
        ...this.classroomForm.getRawValue(),
        schoolCode: this.school.code,
        status: src_app_core_classroom_classroom_shared_types__WEBPACK_IMPORTED_MODULE_0__.ClassroomStatus.ACTIVE
      };
      this._classroomService.createClassroom(classroomData).subscribe({
        next: response => {
          if (response.success) {
            // Add new classroom to the existing list
            if (response.data) {
              // Create a new classroom with requests entry
              const newClassroomWithRequests = {
                classroom: response.data,
                stockRequests: {
                  code: '',
                  requestPending: 0,
                  requestCompleted: 0,
                  consumption: 0
                }
              };
              // Add to the beginning of the array
              this.classroomWithRequests = [newClassroomWithRequests, ...this.classroomWithRequests];
              // Refresh the table
              this._changeDetectorRef.markForCheck();
            }
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Classroom created successfully'
            });
            this.hideDialog();
          }
          this.submitted = false;
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to create classroom'
          });
        }
      });
    } else {
      this.submitted = false;
    }
  }
  editClassroom(classroomWithRequests) {
    this.classroom = {
      name: classroomWithRequests.classroom?.name || '',
      schoolCode: classroomWithRequests.classroom?.schoolCode || '',
      ...classroomWithRequests.classroom
    };
    this.classroomForm.patchValue({
      name: classroomWithRequests.classroom?.name,
      status: classroomWithRequests.classroom?.status
    });
    this.classroomDialog = true;
  }
  updateClassroom() {
    this.submitted = true;
    if (this.classroomForm.valid && this.classroom.code) {
      const updatedClassroom = {
        ...this.classroomForm.getRawValue(),
        code: this.classroom.code,
        schoolCode: this.school.code
      };
      this._classroomService.updateClassroom(updatedClassroom).subscribe({
        next: response => {
          if (response.success && response.data) {
            // Find and update the classroom in the local array
            const index = this.classroomWithRequests.findIndex(item => item.classroom?.code === this.classroom.code);
            if (index !== -1) {
              // Create updated classroom with requests object
              const updatedClassroomWithRequests = {
                ...this.classroomWithRequests[index],
                classroom: response.data
              };
              // Update the array
              this.classroomWithRequests[index] = updatedClassroomWithRequests;
              // Create a new array reference to trigger change detection
              this.classroomWithRequests = [...this.classroomWithRequests];
              // Force refresh the view
              this._changeDetectorRef.markForCheck();
            }
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Classroom updated successfully'
            });
            this.hideDialog();
          }
          this.submitted = false;
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to update classroom'
          });
        }
      });
    } else {
      this.submitted = false;
    }
  }
  deleteClassroom(classroomWithRequests) {
    this.classroom = {
      name: classroomWithRequests.classroom?.name || '',
      schoolCode: classroomWithRequests.classroom?.schoolCode || '',
      ...classroomWithRequests.classroom
    };
    this.deleteClassroomDialog = true;
  }
  confirmDelete() {
    if (this.classroom?.code) {
      this.submitted = true;
      this._classroomService.deleteClassroom(this.classroom.code).subscribe({
        next: response => {
          if (response.success) {
            this.deleteClassroomDialog = false;
            this.submitted = false;
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Classroom deleted successfully'
            });
          }
        },
        error: error => {
          this.submitted = false;
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to delete classroom'
          });
        }
      });
    }
  }
  getActionItems(classroomWithRequests) {
    return [{
      label: 'Edit',
      command: () => this.editClassroom(classroomWithRequests)
    }, {
      label: 'Delete',
      command: () => this.deleteClassroom(classroomWithRequests)
    }];
  }
  hideDialog() {
    this.classroomDialog = false;
    this.deleteClassroomDialog = false;
    this.submitted = false;
    this.classroomForm.reset();
  }
  onGlobalFilter(table, event) {
    table.filterGlobal(event.target.value, 'contains');
  }
  clearFilters(table) {
    table.clear();
    this.dateRange = null;
  }
  onSort(event) {
    this.sortField = event.field;
    this.sortOrder = event.order;
  }
  static #_ = this.ɵfac = function ClassroomListComponent_Factory(t) {
    return new (t || ClassroomListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_classroom_classroom_shared_service__WEBPACK_IMPORTED_MODULE_1__.ClassroomSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_classroom_service__WEBPACK_IMPORTED_MODULE_2__.ClassroomService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_school_school_service__WEBPACK_IMPORTED_MODULE_3__.SchoolSharedService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: ClassroomListComponent,
    selectors: [["ng-component"]],
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵProvidersFeature"]([primeng_api__WEBPACK_IMPORTED_MODULE_8__.MessageService, primeng_api__WEBPACK_IMPORTED_MODULE_8__.ConfirmationService])],
    decls: 31,
    vars: 27,
    consts: [[1, "grid"], [1, "col-12"], [1, "flex", "justify-content-between", "align-items-center", "flex-wrap", "w-full"], [1, "flex", "align-items-center", "justify-content-start", "mb-3"], [1, "text-xl", "font-medium", "text-color-secondary", 2, "color", "#573353 !important", "line-height", "14px", "font-size", "16px !important"], ["pButton", "", 1, "flex", "align-items-center", "gap-2", "border-none", "mb-3", 2, "width", "170px", "height", "40px", "border-radius", "12px", "padding-left", "8px", "padding-right", "16px", "background", "linear-gradient(\n                        90deg,\n                        #5978f7 0%,\n                        #9c84ff 100%\n                    )", "color", "white", "font-weight", "500", 3, "click"], [1, "pi", "pi-plus", 2, "margin-right", "6px"], [1, "card", "px-3"], ["currentPageReportTemplate", "Showing {first} to {last} of {totalRecords} entries", "dataKey", "classroom.code", "responsiveLayout", "scroll", 3, "value", "columns", "rows", "paginator", "globalFilterFields", "rowsPerPageOptions", "showCurrentPageReport", "selection", "rowHover", "sortField", "sortOrder", "selectionChange", "onSort"], ["dt", ""], ["pTemplate", "caption"], ["pTemplate", "header"], ["pTemplate", "body"], ["pTemplate", "emptymessage"], [1, "p-fluid", 3, "visible", "header", "modal", "visibleChange"], ["pTemplate", "content"], ["header", "Delete Classroom", "styleClass", "delete-dialog", 3, "visible", "modal", "showHeader", "visibleChange"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", "gap-3"], [1, "delete-icon-container"], [1, "pi", "pi-trash"], [1, "delete-message", "text-center"], [1, "flex", "align-items-center", "gap-2", "mt-4"], ["pButton", "", "pRipple", "", "label", "Cancel", 1, "p-button-outlined", "cancel-button", 3, "click"], ["pButton", "", "pRipple", "", 1, "delete-confirm-button", 3, "label", "icon", "click"], [1, "flex", "flex-column", "md:flex-row", "md:align-items-center", "gap-5"], [1, "block", "mt-2", "md:mt-0", "p-input-icon-left"], [1, "pi", "pi-search"], ["pInputText", "", "type", "text", "placeholder", "Search...", 1, "w-full", "sm:w-auto", 3, "input"], ["selectionMode", "range", "dateFormat", "mm/dd/yy", "placeholder", "Select date range", 1, "custom-calendar", 3, "ngModel", "showIcon", "showOnFocus", "readonlyInput", "appendTo", "ngModelChange"], ["pButton", "", "type", "button", "label", "Clear", 1, "p-button-secondary", "clear-button", 3, "click"], ["pSortableColumn", "classroom.name"], ["field", "classroom.name"], ["pSortableColumn", "stockRequests.requestPending"], ["field", "stockRequests.requestPending"], ["pSortableColumn", "stockRequests.requestCompleted"], ["field", "stockRequests.requestCompleted"], ["pSortableColumn", "stockRequests.consumption"], ["field", "stockRequests.consumption"], ["pSortableColumn", "classroom.status"], ["field", "classroom.status"], [2, "width", "10%"], [1, "classroom-chip"], [1, "text-center"], [1, "table-cell"], ["type", "button", "pButton", "", "icon", "pi pi-ellipsis-v", 1, "p-button-text", "p-button-plain", "action-button", 3, "click"], ["menuButton", ""], ["styleClass", "custom-action-menu", 3, "popup", "model", "appendTo"], ["menu", ""], ["colspan", "6"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", 2, "padding", "2rem"], [4, "ngIf", "ngIfElse"], ["noClassroom", ""], [1, "pi", "pi-spin", "pi-spinner", 2, "font-size", "2.5rem", "color", "#5978f7", "margin-bottom", "1rem"], [2, "font-size", "1.1rem", "color", "#666"], [1, "pi", "pi-book", 2, "font-size", "3rem", "color", "#ccc", "margin-bottom", "1rem"], [2, "font-size", "1.2rem", "color", "#666"], [2, "color", "#888", "margin-top", "0.5rem"], [1, "p-fluid", "pt-0", 3, "formGroup"], [1, "col-12", "pb-3", "pt-0"], ["for", "name"], ["pInputText", "", "id", "name", "formControlName", "name"], ["class", "p-error", 4, "ngIf"], [1, "col-12", "flex", "justify-content-center", "gap-2"], ["pButton", "", "type", "submit", 1, "submit-button", 3, "icon", "label", "disabled", "click"], [1, "p-error"]],
    template: function ClassroomListComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Classrooms");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ClassroomListComponent_Template_button_click_6_listener() {
          return ctx.createNewClassroom();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, " Add Classroom ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](10, "p-toast");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "p-table", 8, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("selectionChange", function ClassroomListComponent_Template_p_table_selectionChange_11_listener($event) {
          return ctx.selectedClassroomWithRequests = $event;
        })("onSort", function ClassroomListComponent_Template_p_table_onSort_11_listener($event) {
          return ctx.onSort($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ClassroomListComponent_ng_template_13_Template, 6, 5, "ng-template", 10)(14, ClassroomListComponent_ng_template_14_Template, 18, 0, "ng-template", 11)(15, ClassroomListComponent_ng_template_15_Template, 18, 17, "ng-template", 12)(16, ClassroomListComponent_ng_template_16_Template, 6, 2, "ng-template", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "p-dialog", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function ClassroomListComponent_Template_p_dialog_visibleChange_17_listener($event) {
          return ctx.classroomDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](18, ClassroomListComponent_ng_template_18_Template, 8, 11, "ng-template", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "p-dialog", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function ClassroomListComponent_Template_p_dialog_visibleChange_19_listener($event) {
          return ctx.deleteClassroomDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "div", 17)(21, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](22, "i", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "div", 20)(24, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25, "Do you want to delete this classroom -");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "div", 21)(29, "button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ClassroomListComponent_Template_button_click_29_listener() {
          return ctx.deleteClassroomDialog = false;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](30, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ClassroomListComponent_Template_button_click_30_listener() {
          return ctx.confirmDelete();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", ctx.classroomWithRequests)("columns", ctx.cols)("rows", 10)("paginator", true)("globalFilterFields", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](24, _c4))("rowsPerPageOptions", ctx.rowsPerPageOptions)("showCurrentPageReport", true)("selection", ctx.selectedClassroomWithRequests)("rowHover", true)("sortField", ctx.sortField)("sortOrder", ctx.sortOrder);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](25, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.classroomDialog)("header", ctx.classroom.code ? "Edit Classroom" : "Add Classroom")("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](26, _c6));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.deleteClassroomDialog)("modal", true)("showHeader", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("\"", ctx.classroom == null ? null : ctx.classroom.name, "\"?");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("label", ctx.submitted ? "" : "Delete")("icon", ctx.submitted ? "pi pi-spinner pi-spin" : "");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, primeng_table__WEBPACK_IMPORTED_MODULE_10__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_8__.PrimeTemplate, primeng_table__WEBPACK_IMPORTED_MODULE_10__.SortableColumn, primeng_table__WEBPACK_IMPORTED_MODULE_10__.SortIcon, primeng_button__WEBPACK_IMPORTED_MODULE_11__.ButtonDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, primeng_ripple__WEBPACK_IMPORTED_MODULE_12__.Ripple, primeng_toast__WEBPACK_IMPORTED_MODULE_13__.Toast, primeng_inputtext__WEBPACK_IMPORTED_MODULE_14__.InputText, primeng_dialog__WEBPACK_IMPORTED_MODULE_15__.Dialog, primeng_menu__WEBPACK_IMPORTED_MODULE_16__.Menu, primeng_calendar__WEBPACK_IMPORTED_MODULE_17__.Calendar],
    styles: ["\n\n.flex[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  \n\n}\n\n\n\n.search-input[_ngcontent-%COMP%] {\n  width: 246px;\n  \n\n  height: 40px;\n  \n\n  padding-left: 10px;\n  \n\n  border-radius: 4px;\n  \n\n}\n\n\n\n.clear-button[_ngcontent-%COMP%] {\n  width: 63px;\n  height: 23px;\n  gap: 6px;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 3px;\n  padding-top: 4px;\n  padding-right: 8px;\n  padding-bottom: 4px;\n  padding-left: 8px;\n}\n.clear-button[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n\n\n\n.clear-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  margin-right: 4px;\n  \n\n}\n\n  .add-button {\n  width: 11.5rem;\n  height: 3rem;\n  font-weight: 600;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 6px;\n  padding: 0.5rem 1rem;\n  transition: background 0.3s ease;\n  margin-bottom: 1rem;\n}\n  .add-button:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n  .add-button:disabled {\n  cursor: not-allowed !important;\n}\n\n.table-cell[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.action-container[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.plain-dots[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  cursor: pointer;\n  padding: 5px;\n}\n\n.custom-dropdown[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 100%;\n  background: white;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  border-radius: 4px;\n  z-index: 1000;\n}\n\n.dropdown-item[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  padding: 8px 16px;\n  border: none;\n  background: none;\n  text-align: left;\n  cursor: pointer;\n}\n.dropdown-item[_ngcontent-%COMP%]:hover {\n  background-color: #f5f5f5;\n}\n\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td {\n  background: #fff;\n  text-align: center;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i {\n  transition: color 0.2s;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i:hover {\n  color: #999 !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=\"stockRequests.requestPending\"], [_nghost-%COMP%]     th[pSortableColumn=\"stockRequests.requestCompleted\"], [_nghost-%COMP%]     th[pSortableColumn=\"stockRequests.consumption\"] {\n  text-align: center !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=\"stockRequests.requestPending\"] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=\"stockRequests.requestCompleted\"] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=\"stockRequests.consumption\"] .p-sortable-column-icon {\n  margin-left: 4px;\n}\n[_nghost-%COMP%]     td:nth-child(2), [_nghost-%COMP%]     td:nth-child(3), [_nghost-%COMP%]     td:nth-child(4) {\n  text-align: center !important;\n}\n\n[_nghost-%COMP%]     .custom-calendar .p-calendar {\n  min-width: 247px;\n  display: inline-flex;\n  position: relative;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar input {\n  width: 100%;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 8px 0 0 8px;\n  padding: 0.5rem;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger {\n  width: 40px;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 0 8px 8px 0;\n  color: #666;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:enabled:hover {\n  background: rgba(177, 175, 233, 0.1019607843);\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker {\n  min-width: 247px;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker.p-datepicker-inline {\n  position: absolute;\n  top: 100%;\n  left: 0;\n  z-index: 1000;\n}\n\n[_nghost-%COMP%]     .update-button {\n  width: 364.42px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .update-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .update-button:disabled {\n  opacity: 0.6;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  cursor: not-allowed;\n}\n\n.classroom-initial[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  background: #E6E8F3;\n  color: #FFFFFF;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.classroom-count[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 23px;\n  gap: 16px;\n  padding: 4px 8px;\n  border-radius: 3px;\n  background-color: rgba(217, 255, 203, 0.4);\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  color: #333333;\n}\n\n  .p-tooltip .p-tooltip-text {\n  background-color: #F0FFEA !important;\n  color: #333333 !important;\n  border: 1px solid #E6E6E6;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  font-size: 11px;\n}\n  .p-tooltip .p-tooltip-arrow {\n  border-top-color: #F0FFEA !important;\n}\n\n.classroom-count-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #6E6E6E;\n  cursor: pointer;\n  opacity: 0.7;\n  transition: opacity 0.2s;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%]:hover {\n  opacity: 1;\n}\n\n[_nghost-%COMP%]     .p-menu {\n  background: none !important;\n  border: none !important;\n  box-shadow: none !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay {\n  margin: 0;\n  padding: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu {\n  width: 73px !important;\n  min-height: 80px !important;\n  padding: 16px !important;\n  border-radius: 8px !important;\n  border: 1px solid #E6E6E6 !important;\n  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.05) !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu * {\n  background: #FFFFFF !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list {\n  gap: 16px;\n  display: flex;\n  flex-direction: column;\n  padding: 0;\n  margin: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem {\n  margin: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link {\n  padding: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link:hover .p-menuitem-text, [_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link:hover .p-menuitem-icon {\n  color: #5978F7 !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link .p-menuitem-icon {\n  font-size: 12px;\n  margin-right: 8px;\n  color: #6C757D !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link .p-menuitem-text {\n  font-size: 12px;\n  color: #495057 !important;\n}\n\n[_nghost-%COMP%]     .delete-dialog .p-dialog-content {\n  padding: 2rem;\n}\n[_nghost-%COMP%]     .delete-icon-container {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background-color: #D92D20;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 1rem;\n}\n[_nghost-%COMP%]     .delete-icon-container .pi-trash {\n  font-size: 24px;\n  color: #FFFFFF;\n}\n[_nghost-%COMP%]     .delete-message {\n  font-size: 14px;\n  color: #344054;\n  line-height: 1.5;\n}\n[_nghost-%COMP%]     .delete-message strong {\n  color: #101828;\n}\n\n[_nghost-%COMP%]     .delete-confirm-button {\n  width: 177px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .delete-confirm-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .delete-confirm-button:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .cancel-button {\n  color: #6C757D;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n  color: #495057;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .cancel-button {\n  width: 177.21px;\n  height: 48px;\n  border-radius: 6.96px;\n  gap: 8.7px;\n  background: transparent;\n  position: relative;\n}\n[_nghost-%COMP%]     .cancel-button::before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  border-radius: 6.96px;\n  border: 1px solid transparent;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%) border-box;\n  -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);\n  -webkit-mask-composite: destination-out;\n  mask-composite: exclude;\n}\n[_nghost-%COMP%]     .cancel-button .p-button-label {\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n}\n[_nghost-%COMP%]     .cancel-button:hover::before {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%) border-box;\n}\n[_nghost-%COMP%]     .cancel-button:hover .p-button-label {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .p-dialog.p-fluid {\n  height: auto;\n}\n[_nghost-%COMP%]     .p-dialog.p-fluid .p-dialog-content {\n  overflow-y: visible;\n  overflow-x: hidden;\n  max-height: none !important;\n}\n[_nghost-%COMP%]     .p-dialog .p-fluid .grid {\n  row-gap: 1.5rem;\n}\n\n.classroom-chip[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 4px 8px;\n  border-radius: 6px;\n  font-size: 12px;\n  font-weight: 500;\n  text-align: center;\n  white-space: nowrap;\n  vertical-align: middle;\n  transition: all 0.2s ease;\n}\n.classroom-chip[_ngcontent-%COMP%]:hover {\n  filter: brightness(95%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvY2xhc3Nyb29tL2xpc3QvbGlzdC5jb21wb25lbnQuc2NzcyIsIndlYnBhY2s6Ly8uLy4uLy4uL05ldyUyMGZvbGRlci92Z3NjaG9vbC10aGVtZS9zcmMvYXBwL21vZHVsZXMvYXBwL2NsYXNzcm9vbS9saXN0L2xpc3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsbURBQUE7QUFDQTtFQUNJLGFBQUE7RUFDQSxTQUFBO0VBQ0Esa0NBQUE7QUNDSjs7QURFQSx3QkFBQTtBQUNBO0VBQ0ksWUFBQTtFQUNBLGtDQUFBO0VBQ0EsWUFBQTtFQUNBLG1DQUFBO0VBQ0Esa0JBQUE7RUFDQSw4Q0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0NBQUE7QUNDSjs7QURJQSwrQkFBQTtBQUNBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSx1REFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUNESjtBREdJO0VBQ0ksdURBQUE7QUNEUjs7QURLQSwwQ0FBQTtBQUNBO0VBQ0ksaUJBQUE7RUFDQSx1REFBQTtBQ0ZKOztBRE9JO0VBQ0ksY0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsdURBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZ0NBQUE7RUFDQSxtQkFBQTtBQ0pSO0FETVE7RUFDSSx1REFBQTtBQ0paO0FET1E7RUFFSSw4QkFBQTtBQ05aOztBRFlBO0VBQ0ksa0JBQUE7QUNUSjs7QURZQTtFQUNJLGtCQUFBO0VBQ0EscUJBQUE7QUNUSjs7QURZQTtFQUNJLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FDVEo7O0FEWUE7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSx3Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtBQ1RKOztBRFlBO0VBQ0ksY0FBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQ1RKO0FEV0k7RUFDSSx5QkFBQTtBQ1RSOztBRGdCWTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNiaEI7QURlZ0I7RUFDSSxzQkFBQTtBQ2JwQjtBRGVvQjtFQUNJLHNCQUFBO0FDYnhCO0FEd0JJOzs7RUFHSSw2QkFBQTtBQ3RCUjtBRHdCUTs7O0VBQ0ksZ0JBQUE7QUNwQlo7QUR5Qkk7OztFQUdJLDZCQUFBO0FDdkJSOztBRCtCUTtFQUNJLGdCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQzVCWjtBRDhCWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkNBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0FDNUJoQjtBRCtCWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNkNBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxXQUFBO0FDN0JoQjtBRCtCZ0I7RUFDSSw2Q0FBQTtBQzdCcEI7QURnQ2dCO0VBQ0ksZ0JBQUE7QUM5QnBCO0FEbUNRO0VBQ0ksZ0JBQUE7QUNqQ1o7QURtQ1k7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0VBQ0EsYUFBQTtBQ2pDaEI7O0FEd0NJO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLDREQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDckNSO0FEdUNRO0VBQ0ksNERBQUE7QUNyQ1o7QUR3Q1E7RUFDSSxZQUFBO0VBQ0EsNERBQUE7RUFDQSxtQkFBQTtBQ3RDWjs7QUQyQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUN4Q0o7O0FEMkNBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0VBQ0Esb0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUN4Q0o7O0FENENJO0VBQ0ksb0NBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0NBQUE7RUFDQSxlQUFBO0FDekNSO0FENENJO0VBQ0ksb0NBQUE7QUMxQ1I7O0FEOENBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsUUFBQTtBQzNDSjtBRDZDSTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSx3QkFBQTtBQzNDUjtBRDZDUTtFQUNJLFVBQUE7QUMzQ1o7O0FEbURJO0VBQ0ksMkJBQUE7RUFDQSx1QkFBQTtFQUNBLDJCQUFBO0FDaERSO0FEcURRO0VBQ0ksU0FBQTtFQUNBLFVBQUE7QUNuRFo7QURxRFk7RUFDSSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0Esd0JBQUE7RUFDQSw2QkFBQTtFQUNBLG9DQUFBO0VBQ0Esc0RBQUE7QUNuRGhCO0FEcURnQjtFQUNJLDhCQUFBO0FDbkRwQjtBRHNEZ0I7RUFDSSxTQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7QUNwRHBCO0FEc0RvQjtFQUNJLFNBQUE7QUNwRHhCO0FEc0R3QjtFQUNJLFVBQUE7QUNwRDVCO0FEd0RnQzs7RUFFSSx5QkFBQTtBQ3REcEM7QUQwRDRCO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7QUN4RGhDO0FEMkQ0QjtFQUNJLGVBQUE7RUFDQSx5QkFBQTtBQ3pEaEM7O0FEcUVRO0VBQ0ksYUFBQTtBQ2xFWjtBRHNFSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNwRVI7QURzRVE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtBQ3BFWjtBRHdFSTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUN0RVI7QUR3RVE7RUFDSSxjQUFBO0FDdEVaOztBRDRFSTtFQUNJLFlBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSw0REFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ3pFUjtBRDJFUTtFQUNJLDREQUFBO0FDekVaO0FENEVRO0VBQ0ksZ0JBQUE7QUMxRVo7QUQ4RUk7RUFDSSxjQUFBO0FDNUVSO0FEOEVRO0VBQ0ksdUJBQUE7RUFDQSxjQUFBO0FDNUVaO0FEK0VRO0VBQ0ksZ0JBQUE7QUM3RVo7O0FEbUZJO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0FDaEZSO0FEbUZRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLHFCQUFBO0VBQ0EsNkJBQUE7RUFDQSx1RUFBQTtFQUNBLDhFQUNJO0VBRUosdUNBQUE7RUFDQSx1QkFBQTtBQ25GWjtBRHVGUTtFQUNJLDREQUFBO0VBQ0EsNkJBQUE7RUFDQSxxQkFBQTtFQUNBLG9DQUFBO0VBQ0EsZ0JBQUE7QUNyRlo7QUR3RlE7RUFDSSx1QkFBQTtBQ3RGWjtBRHdGWTtFQUNJLHVFQUFBO0FDdEZoQjtBRHlGWTtFQUNJLDREQUFBO0VBQ0EsNkJBQUE7RUFDQSxxQkFBQTtBQ3ZGaEI7QUQyRlE7RUFDSSxnQkFBQTtBQ3pGWjs7QURrR1E7RUFDSSxZQUFBO0FDL0ZaO0FEaUdZO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0FDL0ZoQjtBRDBHWTtFQUNJLGVBQUE7QUN4R2hCOztBRDhHQTtFQUNRLHFCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHlCQUFBO0FDM0dSO0FENkdRO0VBQ0ksdUJBQUE7QUMzR1oiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBHZW5lcmFsIEZsZXggTGF5b3V0OiAxMnB4IGdhcCBiZXR3ZWVuIGNvbnRyb2xzICovXHJcbi5mbGV4IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBnYXA6IDEycHg7XHJcbiAgICAvKiAxMnB4IGdhcCBiZXR3ZWVuIGVhY2ggY29udHJvbCAqL1xyXG59XHJcblxyXG4vKiBTZWFyY2ggSW5wdXQgc3R5bGVzICovXHJcbi5zZWFyY2gtaW5wdXQge1xyXG4gICAgd2lkdGg6IDI0NnB4O1xyXG4gICAgLyogTWF0Y2hpbmcgdGhlIHdpZHRoIGZyb20gRmlnbWEgKi9cclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIC8qIE1hdGNoaW5nIHRoZSBoZWlnaHQgZnJvbSBGaWdtYSAqL1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgLyogT3B0aW9uYWw6IFNwYWNlIGJldHdlZW4gdGhlIGljb24gYW5kIHRleHQgKi9cclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIC8qIFJvdW5kZWQgY29ybmVycyBmb3IgdGhlIGlucHV0ICovXHJcbn1cclxuXHJcblxyXG5cclxuLyogQ2xlYXIgQnV0dG9uIGN1c3RvbSBzdHlsZXMgKi9cclxuLmNsZWFyLWJ1dHRvbiB7XHJcbiAgICB3aWR0aDogNjNweDtcclxuICAgIGhlaWdodDogMjNweDtcclxuICAgIGdhcDogNnB4O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpOyAvLyBJbmRpZ28gNTAwIHRvIDYwMFxyXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgcGFkZGluZy10b3A6IDRweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDhweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA0cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDhweDtcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0QjY4RTEsICM4QjZFRkYpOyAvLyBEYXJrZXIgb24gaG92ZXJcclxuICAgIH1cclxufVxyXG5cclxuLyogT3B0aW9uYWw6IFN0eWxlIGZvciB0aGUgYnV0dG9uJ3MgaWNvbiAqL1xyXG4uY2xlYXItYnV0dG9uIGkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbiAgICAvKiBBZGp1c3QgaWYgeW91IHdhbnQgc3BhY2UgYmV0d2VlbiB0aGUgaWNvbiBhbmQgdGV4dCAqL1xyXG59XHJcblxyXG5cclxuOjpuZy1kZWVwIHtcclxuICAgIC5hZGQtYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMTEuNXJlbTtcclxuICAgICAgICBoZWlnaHQ6IDNyZW07XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNTk3OEY3LCAjOUM4NEZGKTsgLy8gSW5kaWdvIDUwMCB0byA2MDBcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICAgICAgcGFkZGluZzogMC41cmVtIDFyZW07XHJcbiAgICAgICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjNzIGVhc2U7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzRCNjhFMSwgIzhCNkVGRik7IC8vIERhcmtlciBvbiBob3ZlclxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpkaXNhYmxlZCB7XHJcbiAgICAgICAgICAgIC8vIG9wYWNpdHk6IDAuNiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBjdXJzb3I6IG5vdC1hbGxvd2VkICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuLnRhYmxlLWNlbGwge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4uYWN0aW9uLWNvbnRhaW5lciB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuXHJcbi5wbGFpbi1kb3RzIHtcclxuICAgIGJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbn1cclxuXHJcbi5jdXN0b20tZHJvcGRvd24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICB6LWluZGV4OiAxMDAwO1xyXG59XHJcblxyXG4uZHJvcGRvd24taXRlbSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogOHB4IDE2cHg7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLnAtZGF0YXRhYmxlIHtcclxuICAgICAgICAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHtcclxuICAgICAgICAgICAgdGQge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbiAgICAgICAgICAgICAgICBpIHtcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBjb2xvciAwLjJzO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM5OTkgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRW5zdXJlIGhlYWRlciBjZWxscyBhcmUgYWxzbyBjZW50ZXJlZFxyXG4gICAgLy8gdGhbcFNvcnRhYmxlQ29sdW1uPVwibmFtZVwiXSxcclxuICAgIC8vIHRoW3BTb3J0YWJsZUNvbHVtbj1cImNsYXNzcm9vbXNcIl0sXHJcbiAgICAvLyBVcGRhdGUgdGhlc2Ugc2VsZWN0b3JzIHRvIG1hdGNoIGNsYXNzcm9vbSBjb2x1bW4gZmllbGRzXHJcbiAgICB0aFtwU29ydGFibGVDb2x1bW49XCJzdG9ja1JlcXVlc3RzLnJlcXVlc3RQZW5kaW5nXCJdLFxyXG4gICAgdGhbcFNvcnRhYmxlQ29sdW1uPVwic3RvY2tSZXF1ZXN0cy5yZXF1ZXN0Q29tcGxldGVkXCJdLFxyXG4gICAgdGhbcFNvcnRhYmxlQ29sdW1uPVwic3RvY2tSZXF1ZXN0cy5jb25zdW1wdGlvblwiXSB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XHJcblxyXG4gICAgICAgIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uIHtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDRweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gQWxzbyBjZW50ZXIgdGhlIGNvcnJlc3BvbmRpbmcgdGQgY2VsbHNcclxuICAgIHRkOm50aC1jaGlsZCgyKSxcclxuICAgIHRkOm50aC1jaGlsZCgzKSxcclxuICAgIHRkOm50aC1jaGlsZCg0KSB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcblxyXG59XHJcblxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5jdXN0b20tY2FsZW5kYXIge1xyXG4gICAgICAgIC5wLWNhbGVuZGFyIHtcclxuICAgICAgICAgICAgbWluLXdpZHRoOiAyNDdweDtcclxuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAgICAgICAgIGlucHV0IHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0IxQUZFOTFBO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4IDAgMCA4cHg7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLjVyZW07XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5wLWRhdGVwaWNrZXItdHJpZ2dlciB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogNDBweDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNCMUFGRTkxQTtcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAgOHB4IDhweCAwO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICM2NjY7XHJcblxyXG4gICAgICAgICAgICAgICAgJjplbmFibGVkOmhvdmVyIHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjQjFBRkU5MUE7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgJjpmb2N1cyB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnAtZGF0ZXBpY2tlciB7XHJcbiAgICAgICAgICAgIG1pbi13aWR0aDogMjQ3cHg7XHJcblxyXG4gICAgICAgICAgICAmLnAtZGF0ZXBpY2tlci1pbmxpbmUge1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgdG9wOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgbGVmdDogMDtcclxuICAgICAgICAgICAgICAgIHotaW5kZXg6IDEwMDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAudXBkYXRlLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDM2NC40MnB4O1xyXG4gICAgICAgIGhlaWdodDogNDhweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xyXG4gICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpkaXNhYmxlZCB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuNjtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xyXG4gICAgICAgICAgICBjdXJzb3I6IG5vdC1hbGxvd2VkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmNsYXNzcm9vbS1pbml0aWFsIHtcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgaGVpZ2h0OiAyNHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgYmFja2dyb3VuZDogI0U2RThGMztcclxuICAgIGNvbG9yOiAjRkZGRkZGO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcbi5jbGFzc3Jvb20tY291bnQge1xyXG4gICAgd2lkdGg6IDMycHg7XHJcbiAgICBoZWlnaHQ6IDIzcHg7XHJcbiAgICBnYXA6IDE2cHg7XHJcbiAgICBwYWRkaW5nOiA0cHggOHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Q5RkZDQjY2O1xyXG4gICAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBjb2xvcjogIzMzMzMzMztcclxufVxyXG5cclxuOjpuZy1kZWVwIC5wLXRvb2x0aXAge1xyXG4gICAgLnAtdG9vbHRpcC10ZXh0IHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjBGRkVBICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6ICMzMzMzMzMgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjRTZFNkU2O1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5wLXRvb2x0aXAtYXJyb3cge1xyXG4gICAgICAgIGJvcmRlci10b3AtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG5cclxuLmNsYXNzcm9vbS1jb3VudC13cmFwcGVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZ2FwOiA4cHg7XHJcblxyXG4gICAgLmVkaXQtaWNvbiB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGNvbG9yOiAjNkU2RTZFO1xyXG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICBvcGFjaXR5OiAwLjc7XHJcbiAgICAgICAgdHJhbnNpdGlvbjogb3BhY2l0eSAwLjJzO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcblxyXG4gICAgLy8gUmVzZXQgYW5kIG92ZXJyaWRlIGFsbCBtZW51IHN0eWxlc1xyXG4gICAgLnAtbWVudSB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgIGJvcmRlcjogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTdHlsZSB0aGUgc3BlY2lmaWMgbWVudSBvdmVybGF5XHJcbiAgICAuY3VzdG9tLWFjdGlvbi1tZW51IHtcclxuICAgICAgICAmLnAtbWVudS1vdmVybGF5IHtcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG5cclxuICAgICAgICAgICAgLnAtbWVudSB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogNzNweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgbWluLWhlaWdodDogODBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMTZweCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjRTZFNkU2ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICBib3gtc2hhZG93OiAwcHggMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMDUpICFpbXBvcnRhbnQ7XHJcblxyXG4gICAgICAgICAgICAgICAgKiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0ZGRkZGRiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5wLW1lbnUtbGlzdCB7XHJcbiAgICAgICAgICAgICAgICAgICAgZ2FwOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLnAtbWVudWl0ZW0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbS1saW5rIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJjpob3ZlciB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5wLW1lbnVpdGVtLXRleHQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnAtbWVudWl0ZW0taWNvbiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNTk3OEY3ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5wLW1lbnVpdGVtLWljb24ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDhweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzZDNzU3RCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5wLW1lbnVpdGVtLXRleHQge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzQ5NTA1NyAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLmRlbGV0ZS1kaWFsb2cge1xyXG4gICAgICAgIC5wLWRpYWxvZy1jb250ZW50IHtcclxuICAgICAgICAgICAgcGFkZGluZzogMnJlbTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgICAgd2lkdGg6IDY0cHg7XHJcbiAgICAgICAgaGVpZ2h0OiA2NHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRDkyRDIwO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG5cclxuICAgICAgICAucGktdHJhc2gge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjRkZGRkZGO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuZGVsZXRlLW1lc3NhZ2Uge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBjb2xvcjogIzM0NDA1NDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMS41O1xyXG5cclxuICAgICAgICBzdHJvbmcge1xyXG4gICAgICAgICAgICBjb2xvcjogIzEwMTgyODtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAuZGVsZXRlLWNvbmZpcm0tYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMTc3cHg7XHJcbiAgICAgICAgaGVpZ2h0OiA0OHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XHJcbiAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcblxyXG4gICAgICAgICY6aG92ZXIge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAmOmZvY3VzIHtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmNhbmNlbC1idXR0b24ge1xyXG4gICAgICAgIGNvbG9yOiAjNkM3NTdEO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNDk1MDU3O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpmb2N1cyB7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLmNhbmNlbC1idXR0b24ge1xyXG4gICAgICAgIHdpZHRoOiAxNzcuMjFweDtcclxuICAgICAgICBoZWlnaHQ6IDQ4cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNi45NnB4O1xyXG4gICAgICAgIGdhcDogOC43cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgICAgICAvLyBDcmVhdGUgZ3JhZGllbnQgYm9yZGVyXHJcbiAgICAgICAgJjo6YmVmb3JlIHtcclxuICAgICAgICAgICAgY29udGVudDogJyc7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgdG9wOiAwO1xyXG4gICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICByaWdodDogMDtcclxuICAgICAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSkgYm9yZGVyLWJveDtcclxuICAgICAgICAgICAgLXdlYmtpdC1tYXNrOlxyXG4gICAgICAgICAgICAgICAgbGluZWFyLWdyYWRpZW50KCNmZmYgMCAwKSBwYWRkaW5nLWJveCxcclxuICAgICAgICAgICAgICAgIGxpbmVhci1ncmFkaWVudCgjZmZmIDAgMCk7XHJcbiAgICAgICAgICAgIC13ZWJraXQtbWFzay1jb21wb3NpdGU6IGRlc3RpbmF0aW9uLW91dDtcclxuICAgICAgICAgICAgbWFzay1jb21wb3NpdGU6IGV4Y2x1ZGU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBHcmFkaWVudCB0ZXh0XHJcbiAgICAgICAgLnAtYnV0dG9uLWxhYmVsIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xyXG4gICAgICAgICAgICAtd2Via2l0LWJhY2tncm91bmQtY2xpcDogdGV4dDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xyXG4gICAgICAgICAgICAtd2Via2l0LXRleHQtZmlsbC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblxyXG4gICAgICAgICAgICAmOjpiZWZvcmUge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpIGJvcmRlci1ib3g7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5wLWJ1dHRvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSk7XHJcbiAgICAgICAgICAgICAgICAtd2Via2l0LWJhY2tncm91bmQtY2xpcDogdGV4dDtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY2xpcDogdGV4dDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpmb2N1cyB7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG5cclxuICAgIC8vIEFkZCB0aGlzIG5ldyBzZWN0aW9uXHJcbiAgICAucC1kaWFsb2cge1xyXG4gICAgICAgICYucC1mbHVpZCB7XHJcbiAgICAgICAgICAgIGhlaWdodDogYXV0bztcclxuXHJcbiAgICAgICAgICAgIC5wLWRpYWxvZy1jb250ZW50IHtcclxuICAgICAgICAgICAgICAgIG92ZXJmbG93LXk6IHZpc2libGU7XHJcbiAgICAgICAgICAgICAgICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgICAgICAgICAgICAgICBtYXgtaGVpZ2h0OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICAvLyBwYWRkaW5nOiAycmVtO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAucC1kaWFsb2ctaGVhZGVyIHtcclxuICAgICAgICAgICAgLy8gcGFkZGluZzogMnJlbSAycmVtIDAgMnJlbTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIEFkanVzdCBmb3JtIHNwYWNpbmdcclxuICAgICAgICAucC1mbHVpZCB7XHJcbiAgICAgICAgICAgIC5ncmlkIHtcclxuICAgICAgICAgICAgICAgIHJvdy1nYXA6IDEuNXJlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmNsYXNzcm9vbS1jaGlwIHtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgcGFkZGluZzogNHB4IDhweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgICAgICB0cmFuc2l0aW9uOiBhbGwgMC4ycyBlYXNlO1xyXG5cclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgZmlsdGVyOiBicmlnaHRuZXNzKDk1JSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4iLCIvKiBHZW5lcmFsIEZsZXggTGF5b3V0OiAxMnB4IGdhcCBiZXR3ZWVuIGNvbnRyb2xzICovXG4uZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGdhcDogMTJweDtcbiAgLyogMTJweCBnYXAgYmV0d2VlbiBlYWNoIGNvbnRyb2wgKi9cbn1cblxuLyogU2VhcmNoIElucHV0IHN0eWxlcyAqL1xuLnNlYXJjaC1pbnB1dCB7XG4gIHdpZHRoOiAyNDZweDtcbiAgLyogTWF0Y2hpbmcgdGhlIHdpZHRoIGZyb20gRmlnbWEgKi9cbiAgaGVpZ2h0OiA0MHB4O1xuICAvKiBNYXRjaGluZyB0aGUgaGVpZ2h0IGZyb20gRmlnbWEgKi9cbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAvKiBPcHRpb25hbDogU3BhY2UgYmV0d2VlbiB0aGUgaWNvbiBhbmQgdGV4dCAqL1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIC8qIFJvdW5kZWQgY29ybmVycyBmb3IgdGhlIGlucHV0ICovXG59XG5cbi8qIENsZWFyIEJ1dHRvbiBjdXN0b20gc3R5bGVzICovXG4uY2xlYXItYnV0dG9uIHtcbiAgd2lkdGg6IDYzcHg7XG4gIGhlaWdodDogMjNweDtcbiAgZ2FwOiA2cHg7XG4gIGNvbG9yOiAjZmZmO1xuICBib3JkZXI6IG5vbmU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzU5NzhGNywgIzlDODRGRik7XG4gIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgcGFkZGluZy10b3A6IDRweDtcbiAgcGFkZGluZy1yaWdodDogOHB4O1xuICBwYWRkaW5nLWJvdHRvbTogNHB4O1xuICBwYWRkaW5nLWxlZnQ6IDhweDtcbn1cbi5jbGVhci1idXR0b246aG92ZXIge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0QjY4RTEsICM4QjZFRkYpO1xufVxuXG4vKiBPcHRpb25hbDogU3R5bGUgZm9yIHRoZSBidXR0b24ncyBpY29uICovXG4uY2xlYXItYnV0dG9uIGkge1xuICBtYXJnaW4tcmlnaHQ6IDRweDtcbiAgLyogQWRqdXN0IGlmIHlvdSB3YW50IHNwYWNlIGJldHdlZW4gdGhlIGljb24gYW5kIHRleHQgKi9cbn1cblxuOjpuZy1kZWVwIC5hZGQtYnV0dG9uIHtcbiAgd2lkdGg6IDExLjVyZW07XG4gIGhlaWdodDogM3JlbTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICNmZmY7XG4gIGJvcmRlcjogbm9uZTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNTk3OEY3LCAjOUM4NEZGKTtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBwYWRkaW5nOiAwLjVyZW0gMXJlbTtcbiAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjNzIGVhc2U7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG46Om5nLWRlZXAgLmFkZC1idXR0b246aG92ZXIge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0QjY4RTEsICM4QjZFRkYpO1xufVxuOjpuZy1kZWVwIC5hZGQtYnV0dG9uOmRpc2FibGVkIHtcbiAgY3Vyc29yOiBub3QtYWxsb3dlZCAhaW1wb3J0YW50O1xufVxuXG4udGFibGUtY2VsbCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmFjdGlvbi1jb250YWluZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cblxuLnBsYWluLWRvdHMge1xuICBiYWNrZ3JvdW5kOiBub25lO1xuICBib3JkZXI6IG5vbmU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgcGFkZGluZzogNXB4O1xufVxuXG4uY3VzdG9tLWRyb3Bkb3duIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMDtcbiAgdG9wOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm94LXNoYWRvdzogMCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICB6LWluZGV4OiAxMDAwO1xufVxuXG4uZHJvcGRvd24taXRlbSB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZzogOHB4IDE2cHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuLmRyb3Bkb3duLWl0ZW06aG92ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLnAtZGF0YXRhYmxlIC5wLWRhdGF0YWJsZS1lbXB0eW1lc3NhZ2UgdGQge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG46aG9zdCA6Om5nLWRlZXAgLnAtZGF0YXRhYmxlIC5wLWRhdGF0YWJsZS1lbXB0eW1lc3NhZ2UgdGQgaSB7XG4gIHRyYW5zaXRpb246IGNvbG9yIDAuMnM7XG59XG46aG9zdCA6Om5nLWRlZXAgLnAtZGF0YXRhYmxlIC5wLWRhdGF0YWJsZS1lbXB0eW1lc3NhZ2UgdGQgaTpob3ZlciB7XG4gIGNvbG9yOiAjOTk5ICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPVwic3RvY2tSZXF1ZXN0cy5yZXF1ZXN0UGVuZGluZ1wiXSxcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49XCJzdG9ja1JlcXVlc3RzLnJlcXVlc3RDb21wbGV0ZWRcIl0sXG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPVwic3RvY2tSZXF1ZXN0cy5jb25zdW1wdGlvblwiXSB7XG4gIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1cInN0b2NrUmVxdWVzdHMucmVxdWVzdFBlbmRpbmdcIl0gLnAtc29ydGFibGUtY29sdW1uLWljb24sXG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPVwic3RvY2tSZXF1ZXN0cy5yZXF1ZXN0Q29tcGxldGVkXCJdIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1cInN0b2NrUmVxdWVzdHMuY29uc3VtcHRpb25cIl0gLnAtc29ydGFibGUtY29sdW1uLWljb24ge1xuICBtYXJnaW4tbGVmdDogNHB4O1xufVxuOmhvc3QgOjpuZy1kZWVwIHRkOm50aC1jaGlsZCgyKSxcbjpob3N0IDo6bmctZGVlcCB0ZDpudGgtY2hpbGQoMyksXG46aG9zdCA6Om5nLWRlZXAgdGQ6bnRoLWNoaWxkKDQpIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWNhbGVuZGFyIHtcbiAgbWluLXdpZHRoOiAyNDdweDtcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWNhbGVuZGFyIGlucHV0IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNDBweDtcbiAgYmFja2dyb3VuZDogcmdiYSgxNzcsIDE3NSwgMjMzLCAwLjEwMTk2MDc4NDMpO1xuICBib3JkZXI6IG5vbmU7XG4gIGJvcmRlci1yYWRpdXM6IDhweCAwIDAgOHB4O1xuICBwYWRkaW5nOiAwLjVyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciAucC1kYXRlcGlja2VyLXRyaWdnZXIge1xuICB3aWR0aDogNDBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBiYWNrZ3JvdW5kOiByZ2JhKDE3NywgMTc1LCAyMzMsIDAuMTAxOTYwNzg0Myk7XG4gIGJvcmRlcjogbm9uZTtcbiAgYm9yZGVyLXJhZGl1czogMCA4cHggOHB4IDA7XG4gIGNvbG9yOiAjNjY2O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci10cmlnZ2VyOmVuYWJsZWQ6aG92ZXIge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDE3NywgMTc1LCAyMzMsIDAuMTAxOTYwNzg0Myk7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciAucC1kYXRlcGlja2VyLXRyaWdnZXI6Zm9jdXMge1xuICBib3gtc2hhZG93OiBub25lO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtZGF0ZXBpY2tlciB7XG4gIG1pbi13aWR0aDogMjQ3cHg7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1kYXRlcGlja2VyLnAtZGF0ZXBpY2tlci1pbmxpbmUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTAwJTtcbiAgbGVmdDogMDtcbiAgei1pbmRleDogMTAwMDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uIHtcbiAgd2lkdGg6IDM2NC40MnB4O1xuICBoZWlnaHQ6IDQ4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xuICBib3JkZXI6IG5vbmU7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLnVwZGF0ZS1idXR0b246aG92ZXIge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSk7XG59XG46aG9zdCA6Om5nLWRlZXAgLnVwZGF0ZS1idXR0b246ZGlzYWJsZWQge1xuICBvcGFjaXR5OiAwLjY7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcbn1cblxuLmNsYXNzcm9vbS1pbml0aWFsIHtcbiAgd2lkdGg6IDI0cHg7XG4gIGhlaWdodDogMjRweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBiYWNrZ3JvdW5kOiAjRTZFOEYzO1xuICBjb2xvcjogI0ZGRkZGRjtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuLmNsYXNzcm9vbS1jb3VudCB7XG4gIHdpZHRoOiAzMnB4O1xuICBoZWlnaHQ6IDIzcHg7XG4gIGdhcDogMTZweDtcbiAgcGFkZGluZzogNHB4IDhweDtcbiAgYm9yZGVyLXJhZGl1czogM3B4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDIxNywgMjU1LCAyMDMsIDAuNCk7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogIzMzMzMzMztcbn1cblxuOjpuZy1kZWVwIC5wLXRvb2x0aXAgLnAtdG9vbHRpcC10ZXh0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0YwRkZFQSAhaW1wb3J0YW50O1xuICBjb2xvcjogIzMzMzMzMyAhaW1wb3J0YW50O1xuICBib3JkZXI6IDFweCBzb2xpZCAjRTZFNkU2O1xuICBib3gtc2hhZG93OiAwIDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xuICBmb250LXNpemU6IDExcHg7XG59XG46Om5nLWRlZXAgLnAtdG9vbHRpcCAucC10b29sdGlwLWFycm93IHtcbiAgYm9yZGVyLXRvcC1jb2xvcjogI0YwRkZFQSAhaW1wb3J0YW50O1xufVxuXG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBnYXA6IDhweDtcbn1cbi5jbGFzc3Jvb20tY291bnQtd3JhcHBlciAuZWRpdC1pY29uIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogIzZFNkU2RTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBvcGFjaXR5OiAwLjc7XG4gIHRyYW5zaXRpb246IG9wYWNpdHkgMC4ycztcbn1cbi5jbGFzc3Jvb20tY291bnQtd3JhcHBlciAuZWRpdC1pY29uOmhvdmVyIHtcbiAgb3BhY2l0eTogMTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5wLW1lbnUge1xuICBiYWNrZ3JvdW5kOiBub25lICFpbXBvcnRhbnQ7XG4gIGJvcmRlcjogbm9uZSAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSB7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogMDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUge1xuICB3aWR0aDogNzNweCAhaW1wb3J0YW50O1xuICBtaW4taGVpZ2h0OiA4MHB4ICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmc6IDE2cHggIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogOHB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNFNkU2RTYgIWltcG9ydGFudDtcbiAgYm94LXNoYWRvdzogMHB4IDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjA1KSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAqIHtcbiAgYmFja2dyb3VuZDogI0ZGRkZGRiAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3Qge1xuICBnYXA6IDE2cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbjogMDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IC5wLW1lbnVpdGVtIHtcbiAgbWFyZ2luOiAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3QgLnAtbWVudWl0ZW0gLnAtbWVudWl0ZW0tbGluayB7XG4gIHBhZGRpbmc6IDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IC5wLW1lbnUtbGlzdCAucC1tZW51aXRlbSAucC1tZW51aXRlbS1saW5rOmhvdmVyIC5wLW1lbnVpdGVtLXRleHQsXG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IC5wLW1lbnUtbGlzdCAucC1tZW51aXRlbSAucC1tZW51aXRlbS1saW5rOmhvdmVyIC5wLW1lbnVpdGVtLWljb24ge1xuICBjb2xvcjogIzU5NzhGNyAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3QgLnAtbWVudWl0ZW0gLnAtbWVudWl0ZW0tbGluayAucC1tZW51aXRlbS1pY29uIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBtYXJnaW4tcmlnaHQ6IDhweDtcbiAgY29sb3I6ICM2Qzc1N0QgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IC5wLW1lbnVpdGVtIC5wLW1lbnVpdGVtLWxpbmsgLnAtbWVudWl0ZW0tdGV4dCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICM0OTUwNTcgIWltcG9ydGFudDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtZGlhbG9nIC5wLWRpYWxvZy1jb250ZW50IHtcbiAgcGFkZGluZzogMnJlbTtcbn1cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLWljb24tY29udGFpbmVyIHtcbiAgd2lkdGg6IDY0cHg7XG4gIGhlaWdodDogNjRweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRDkyRDIwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbn1cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLWljb24tY29udGFpbmVyIC5waS10cmFzaCB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1tZXNzYWdlIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogIzM0NDA1NDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbn1cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLW1lc3NhZ2Ugc3Ryb25nIHtcbiAgY29sb3I6ICMxMDE4Mjg7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLWNvbmZpcm0tYnV0dG9uIHtcbiAgd2lkdGg6IDE3N3B4O1xuICBoZWlnaHQ6IDQ4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xuICBib3JkZXI6IG5vbmU7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcbn1cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLWNvbmZpcm0tYnV0dG9uOmZvY3VzIHtcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbiB7XG4gIGNvbG9yOiAjNkM3NTdEO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGNvbG9yOiAjNDk1MDU3O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmZvY3VzIHtcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uIHtcbiAgd2lkdGg6IDE3Ny4yMXB4O1xuICBoZWlnaHQ6IDQ4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcbiAgZ2FwOiA4LjdweDtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjo6YmVmb3JlIHtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBib3R0b206IDA7XG4gIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcbiAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKSBib3JkZXItYm94O1xuICAtd2Via2l0LW1hc2s6IGxpbmVhci1ncmFkaWVudCgjZmZmIDAgMCkgcGFkZGluZy1ib3gsIGxpbmVhci1ncmFkaWVudCgjZmZmIDAgMCk7XG4gIC13ZWJraXQtbWFzay1jb21wb3NpdGU6IGRlc3RpbmF0aW9uLW91dDtcbiAgbWFzay1jb21wb3NpdGU6IGV4Y2x1ZGU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b24gLnAtYnV0dG9uLWxhYmVsIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xuICAtd2Via2l0LWJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xuICAtd2Via2l0LXRleHQtZmlsbC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246aG92ZXIge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpob3Zlcjo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpIGJvcmRlci1ib3g7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246aG92ZXIgLnAtYnV0dG9uLWxhYmVsIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xuICAtd2Via2l0LWJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmZvY3VzIHtcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5wLWRpYWxvZy5wLWZsdWlkIHtcbiAgaGVpZ2h0OiBhdXRvO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRpYWxvZy5wLWZsdWlkIC5wLWRpYWxvZy1jb250ZW50IHtcbiAgb3ZlcmZsb3cteTogdmlzaWJsZTtcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xuICBtYXgtaGVpZ2h0OiBub25lICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLnAtZGlhbG9nIC5wLWZsdWlkIC5ncmlkIHtcbiAgcm93LWdhcDogMS41cmVtO1xufVxuXG4uY2xhc3Nyb29tLWNoaXAge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBhZGRpbmc6IDRweCA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIHRyYW5zaXRpb246IGFsbCAwLjJzIGVhc2U7XG59XG4uY2xhc3Nyb29tLWNoaXA6aG92ZXIge1xuICBmaWx0ZXI6IGJyaWdodG5lc3MoOTUlKTtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ })

}]);
//# sourceMappingURL=src_app_modules_app_classroom_classroom_module_ts.js.map