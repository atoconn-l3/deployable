"use strict";
(self["webpackChunkverona_ng"] = self["webpackChunkverona_ng"] || []).push([["src_app_modules_app_school_school_module_ts"],{

/***/ 57157:
/*!*********************************************!*\
  !*** ./src/app/core/school/school.types.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolEmailValidation: () => (/* binding */ SchoolEmailValidation),
/* harmony export */   SchoolLinkValidation: () => (/* binding */ SchoolLinkValidation),
/* harmony export */   SchoolPhoneNumberValidation: () => (/* binding */ SchoolPhoneNumberValidation),
/* harmony export */   SchoolStatus: () => (/* binding */ SchoolStatus),
/* harmony export */   SchoolType: () => (/* binding */ SchoolType),
/* harmony export */   SchoolValidation: () => (/* binding */ SchoolValidation)
/* harmony export */ });
/**
 * Validation rules for SchoolPhoneNumber
 */
const SchoolPhoneNumberValidation = {
  label: {
    maxLength: 50,
    message: 'Label must not exceed 50 characters'
  },
  country: {
    maxLength: 5,
    message: 'Country code must not exceed 5 characters'
  },
  phoneNumber: {
    minLength: 10,
    maxLength: 15,
    message: 'Phone number must be between 10 and 15 characters'
  }
};
/**
 * Validation rules for SchoolLink
 */
const SchoolLinkValidation = {
  label: {
    required: true,
    message: 'Label is required'
  },
  url: {
    required: true,
    pattern: /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/,
    message: 'Please enter a valid URL'
  }
};
/**
 * Validation rules for SchoolEmail
 */
const SchoolEmailValidation = {
  label: {
    required: false
  },
  email: {
    required: true,
    pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    message: 'Invalid email format'
  }
};
/**
 * School type enum
 * Maps to SchoolType.java in backend
 */
var SchoolType;
(function (SchoolType) {
  SchoolType["DAYCARE"] = "DAYCARE";
  SchoolType["PRESCHOOL"] = "PRESCHOOL";
  SchoolType["ELEMENTARY"] = "ELEMENTARY";
  SchoolType["CHILDCARE"] = "CHILDCARE";
})(SchoolType || (SchoolType = {}));
/**
 * School status enum
 * Maps to School.Status in backend
 */
var SchoolStatus;
(function (SchoolStatus) {
  SchoolStatus["ACTIVE"] = "ACTIVE";
  SchoolStatus["INACTIVE"] = "INACTIVE";
  SchoolStatus["ARCHIVE"] = "ARCHIVE";
})(SchoolStatus || (SchoolStatus = {}));
/**
 * Validation rules for School
 */
const SchoolValidation = {
  code: {
    maxLength: 50,
    required: true,
    message: 'School code is required and must not exceed 50 characters'
  },
  name: {
    maxLength: 100,
    required: true,
    message: 'School name is required and must not exceed 100 characters'
  },
  description: {
    maxLength: 255,
    message: 'Description must not exceed 255 characters'
  },
  logo: {
    maxLength: 1024,
    message: 'Logo URL must not exceed 1024 characters'
  },
  status: {
    required: true,
    message: 'Status is required'
  }
};

/***/ }),

/***/ 54920:
/*!*************************************************************!*\
  !*** ./src/app/modules/app/school/list/school.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolComponent: () => (/* binding */ SchoolComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 98026);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 81891);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 84980);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 2389);
/* harmony import */ var src_app_core_school_school_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/school/school.types */ 57157);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _school_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../school.service */ 6219);
/* harmony import */ var _staff_staff_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../staff/staff.service */ 74975);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/calendar */ 57411);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/inputtextarea */ 30652);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/dropdown */ 94553);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var _school_count_cards_school_count_cards_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../school-count-cards/school-count-cards.component */ 21323);





















function SchoolComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 24)(1, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "i", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "input", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("input", function SchoolComponent_ng_template_14_Template_input_input_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](13);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.onGlobalFilter(_r0, $event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "p-calendar", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function SchoolComponent_ng_template_14_Template_p_calendar_ngModelChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r8.dateRange = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SchoolComponent_ng_template_14_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](13);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r9.clearFilters(_r0));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx_r1.dateRange)("showIcon", true)("showOnFocus", false)("readonlyInput", true)("appendTo", "body");
  }
}
function SchoolComponent_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, " Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "p-sortIcon", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "th", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, " Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "p-sortIcon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "th", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, " Description ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "p-sortIcon", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, " Status ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](12, "p-sortIcon", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "th", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
const _c0 = () => ({
  "min-width": "24px",
  width: "24px",
  height: "24px",
  padding: "0"
});
function SchoolComponent_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "td")(8, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "td", 39)(11, "button", 40, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SchoolComponent_ng_template_16_Template_button_click_11_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r14);
      const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](14);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](_r12.toggle($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "p-menu", 42, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const school_r10 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](school_r10.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](school_r10.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](school_r10.description);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassMap"]("status-badge status-" + (school_r10.status == null ? null : school_r10.status.toLowerCase()));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", school_r10.status, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](11, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("popup", true)("model", ctx_r3.getActionItems(school_r10))("appendTo", "body");
  }
}
function SchoolComponent_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td", 44)(2, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "i", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "span", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "No schools available");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Add new schools using the 'Add School' button");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
}
function SchoolComponent_ng_template_19_small_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "small", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Name is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function SchoolComponent_ng_template_19_small_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "small", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " First name is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function SchoolComponent_ng_template_19_small_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "small", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Last name is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function SchoolComponent_ng_template_19_small_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "small", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Type is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function SchoolComponent_ng_template_19_small_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "small", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Valid phone number is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function SchoolComponent_ng_template_19_small_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "small", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Valid email is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
const _c1 = () => ({
  height: "33px",
  border: "1px solid #57335366",
  borderRadius: "8px"
});
const _c2 = () => ({
  borderRadius: "8px",
  border: "1px solid #57335366"
});
const _c3 = () => ({
  maxWidth: "238px",
  height: "48px",
  borderRadius: "6.96px"
});
function SchoolComponent_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngSubmit", function SchoolComponent_ng_template_19_Template_form_ngSubmit_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r22);
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r21.saveSchool());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1)(2, "label", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "School Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "input", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, SchoolComponent_ng_template_19_small_5_Template, 2, 0, "small", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 53)(7, "label", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Admin First Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, SchoolComponent_ng_template_19_small_10_Template, 2, 0, "small", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 56)(12, "label", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Admin Last Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "input", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, SchoolComponent_ng_template_19_small_15_Template, 2, 0, "small", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "div", 56)(17, "label", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](19, "p-dropdown", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](20, SchoolComponent_ng_template_19_small_20_Template, 2, 0, "small", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 53)(22, "label", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "Phone Number");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](24, "input", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](25, SchoolComponent_ng_template_19_small_25_Template, 2, 0, "small", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "div", 63)(27, "label", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, "Admin Email");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](29, "input", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](30, SchoolComponent_ng_template_19_small_30_Template, 2, 0, "small", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "div", 1)(32, "label", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](33, "Description");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](34, "textarea", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](35, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](36, "button", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    let tmp_2_0;
    let tmp_4_0;
    let tmp_6_0;
    let tmp_9_0;
    let tmp_11_0;
    let tmp_13_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r5.schoolForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](27, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_2_0 = ctx_r5.schoolForm.get("name")) == null ? null : tmp_2_0.touched) && ((tmp_2_0 = ctx_r5.schoolForm.get("name")) == null ? null : tmp_2_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](28, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_4_0 = ctx_r5.schoolForm.get("staff.firstName")) == null ? null : tmp_4_0.touched) && ((tmp_4_0 = ctx_r5.schoolForm.get("staff.firstName")) == null ? null : tmp_4_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](29, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_6_0 = ctx_r5.schoolForm.get("staff.lastName")) == null ? null : tmp_6_0.touched) && ((tmp_6_0 = ctx_r5.schoolForm.get("staff.lastName")) == null ? null : tmp_6_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](30, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("options", ctx_r5.schoolTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_9_0 = ctx_r5.schoolForm.get("type")) == null ? null : tmp_9_0.touched) && ((tmp_9_0 = ctx_r5.schoolForm.get("type")) == null ? null : tmp_9_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](31, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_11_0 = ctx_r5.schoolForm.get("staff.phoneNumber")) == null ? null : tmp_11_0.touched) && ((tmp_11_0 = ctx_r5.schoolForm.get("staff.phoneNumber")) == null ? null : tmp_11_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](32, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_13_0 = ctx_r5.schoolForm.get("staff.email")) == null ? null : tmp_13_0.touched) && ((tmp_13_0 = ctx_r5.schoolForm.get("staff.email")) == null ? null : tmp_13_0.invalid));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](33, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("rows", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](34, _c3));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("label", ctx_r5.school.code ? "Update" : "Add")("disabled", ctx_r5.schoolForm.invalid);
  }
}
const _c4 = () => ["name", "type", "description", "status"];
const _c5 = () => ({
  width: "450px",
  overflow: "visible"
});
const _c6 = () => ({
  overflow: "visible"
});
const _c7 = () => ({
  width: "480px"
});
class SchoolComponent {
  constructor(_schoolService, _staffService, _messageService, _confirmationService, _formBuilder, _changeDetectorRef) {
    this._schoolService = _schoolService;
    this._staffService = _staffService;
    this._messageService = _messageService;
    this._confirmationService = _confirmationService;
    this._formBuilder = _formBuilder;
    this._changeDetectorRef = _changeDetectorRef;
    this.school = {};
    this.schools = [];
    this.selectedSchool = {};
    this.dateRange = null;
    this.schoolDialog = false;
    this.editSchoolDialog = false;
    this.deleteSchoolDialog = false;
    this.submitted = false;
    this.cols = [];
    this.schoolTypes = Object.values(src_app_core_school_school_types__WEBPACK_IMPORTED_MODULE_0__.SchoolType);
    this.schoolStatuses = Object.values(src_app_core_school_school_types__WEBPACK_IMPORTED_MODULE_0__.SchoolStatus);
    this.rowsPerPageOptions = [5, 10, 20];
    this.sortField = '';
    this.sortOrder = 1;
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
  }
  ngOnInit() {
    this.initForm();
    this.initTable();
    this.subscribeToSchools();
    this.loadSchools();
  }
  ngOnDestroy() {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
  initForm() {
    this.schoolForm = this._formBuilder.group({
      name: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100)]],
      type: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      description: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(255)],
      status: [src_app_core_school_school_types__WEBPACK_IMPORTED_MODULE_0__.SchoolStatus.ACTIVE],
      staff: this._formBuilder.group({
        firstName: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100)]],
        lastName: ['Admin', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100)]],
        email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.email]],
        phoneNumber: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('^[0-9]{10}$')]],
        role: ['ADMIN'],
        status: ['ACTIVE']
      })
    });
  }
  initTable() {
    this.cols = [{
      field: 'name',
      header: 'Name'
    }, {
      field: 'type',
      header: 'Type'
    }, {
      field: 'description',
      header: 'Description'
    }, {
      field: 'status',
      header: 'Status'
    }];
  }
  subscribeToSchools() {
    this._schoolService.schoolList$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._unsubscribeAll)).subscribe(schools => {
      if (schools) {
        this.schools = schools;
        this._changeDetectorRef.markForCheck();
      }
    });
  }
  loadSchools() {
    this._schoolService.getSchools().subscribe();
  }
  createNewSchool() {
    this.school = {};
    this.submitted = false;
    this.schoolDialog = true;
    // Ensure one empty entry for email and phone
    const emails = this.schoolForm.get('emails');
    const phones = this.schoolForm.get('phoneNumbers');
    emails.clear();
    phones.clear();
    emails.push(this._formBuilder.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.email]));
    phones.push(this._formBuilder.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('^[0-9]{10}$')]));
  }
  getActionItems(school) {
    return [{
      label: 'Edit',
      // icon: 'pi pi-pencil',
      command: () => {
        this.onEditSchool(school);
      }
    }, {
      label: 'Delete',
      // icon: 'pi pi-trash',
      command: () => {
        this.deleteSchool(school);
      }
    }];
  }
  deleteSchool(school) {
    this.deleteSchoolDialog = true;
    this.school = {
      ...school
    };
  }
  onEditSchool(school) {
    this.school = {
      ...school
    };
    this.schoolDialog = true;
    this.schoolForm.patchValue({
      name: school.name,
      type: school.type,
      description: school.description,
      status: school.status,
      staff: {
        firstName: school.staff?.firstName || '',
        lastName: school.staff?.lastName || '',
        email: school.staff?.email || '',
        phoneNumber: school.staff?.phoneNumber || '',
        role: school.staff?.role || 'ADMIN',
        status: school.staff?.status || 'ACTIVE'
      }
    });
  }
  confirmSchoolDelete() {
    if (this.school?.code) {
      this._schoolService.deleteSchool(this.school.code).subscribe({
        next: response => {
          if (response.success) {
            this.deleteSchoolDialog = false;
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'School deleted successfully'
            });
          }
        },
        error: error => {
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message || 'Failed to delete school'
          });
        }
      });
    }
  }
  saveSchool() {
    if (this.schoolForm.valid) {
      this.submitted = true;
      const formValue = this.schoolForm.getRawValue();
      // Prepare school data
      const schoolData = {
        name: formValue.name,
        type: formValue.type,
        description: formValue.description,
        status: formValue.status,
        emails: [{
          email: formValue.staff.email
        }],
        phoneNumbers: [{
          phoneNumber: formValue.staff.phoneNumber
        }]
      };
      const operation = this.school.code ? this._schoolService.updateSchool({
        ...schoolData,
        code: this.school.code
      }) : this._schoolService.createSchool(schoolData);
      operation.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.switchMap)(response => {
        if (response.success && !this.school.code) {
          // Create staff only for new schools
          const staffData = {
            firstName: formValue.staff.firstName,
            lastName: formValue.staff.lastName,
            email: formValue.staff.email,
            phoneNumber: formValue.staff.phoneNumber,
            role: 'ADMIN',
            status: 'ACTIVE',
            schoolCode: response.data.code,
            allowedClassroomCodes: [],
            primaryClassroomCode: undefined
          };
          return this._staffService.createStaff(staffData);
        }
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(response);
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.catchError)(error => {
        this._messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.message || 'Failed to save school'
        });
        throw error;
      })).subscribe({
        next: response => {
          if (response.success) {
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: `School ${this.school.code ? 'updated' : 'and admin user created'} successfully`
            });
            this.hideDialog();
          }
        }
      });
    }
  }
  saveSchool_old() {
    if (this.schoolForm.valid) {
      this.submitted = true;
      const schoolData = this.schoolForm.getRawValue();
      const operation = this.school.code ? this._schoolService.updateSchool({
        ...schoolData,
        code: this.school.code
      }) : this._schoolService.createSchool(schoolData);
      operation.subscribe({
        next: response => {
          if (response.success) {
            this._messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: `School ${this.school.code ? 'updated' : 'created'} successfully`
            });
            this.hideDialog();
          }
        },
        error: error => {
          this._messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.message
          });
        }
      });
    }
  }
  hideDialog() {
    this.schoolDialog = false;
    this.editSchoolDialog = false;
    this.submitted = false;
    this.schoolForm.reset();
  }
  onSort(event) {
    this.sortField = event.field;
    this.sortOrder = event.order;
  }
  onGlobalFilter(table, event) {
    table.filterGlobal(event.target.value, 'contains');
  }
  clearFilters(table) {
    this.dateRange = null;
    table.clear();
  }
  // Helper method for ngFor tracking
  trackByFn(index, item) {
    return item.code || index;
  }
  static #_ = this.ɵfac = function SchoolComponent_Factory(t) {
    return new (t || SchoolComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_school_service__WEBPACK_IMPORTED_MODULE_1__.SchoolService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_staff_staff_service__WEBPACK_IMPORTED_MODULE_2__.StaffService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: SchoolComponent,
    selectors: [["ng-component"]],
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵProvidersFeature"]([primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService, primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService])],
    decls: 32,
    vars: 27,
    consts: [[1, "grid"], [1, "col-12"], [1, "flex", "align-items-center", "justify-content-start", "mb-3"], [2, "width", "47px", "height", "22px", "font-family", "Manrope, sans-serif", "font-weight", "500", "font-size", "16px", "line-height", "22px", "letter-spacing", "0", "text-align", "center", "color", "#41414e"], [1, "flex", "justify-content-between", "align-items-center", "flex-wrap", "w-full"], ["pButton", "", 1, "flex", "align-items-center", "gap-2", "border-none", 2, "width", "136px", "height", "40px", "border-radius", "12px", "padding-left", "8px", "padding-right", "16px", "background", "linear-gradient(\n                        90deg,\n                        #5978f7 0%,\n                        #9c84ff 100%\n                    )", "color", "white", "font-weight", "500", "margin-left", "auto", 3, "click"], [1, "pi", "pi-plus", 2, "margin-right", "6px"], [1, "card", "px-3"], ["responsiveLayout", "scroll", "currentPageReportTemplate", "Showing {first} to {last} of {totalRecords} entries", "selectionMode", "single", "dataKey", "code", 3, "value", "columns", "rows", "globalFilterFields", "paginator", "rowsPerPageOptions", "showCurrentPageReport", "selection", "rowHover", "sortField", "sortOrder", "selectionChange", "onSort"], ["dt", ""], ["pTemplate", "caption"], ["pTemplate", "header"], ["pTemplate", "body"], ["pTemplate", "emptymessage"], [1, "p-fluid", "school-dialog", 3, "visible", "contentStyle", "header", "modal", "visibleChange"], ["pTemplate", "content"], ["header", "Delete User", "styleClass", "delete-dialog", 3, "visible", "modal", "showHeader", "visibleChange"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", "gap-3"], [1, "delete-icon-container"], [1, "pi", "pi-trash"], [1, "delete-message", "text-center"], [1, "flex", "align-items-center", "gap-2", "mt-4"], ["pButton", "", "pRipple", "", "label", "Cancel", 1, "p-button-outlined", "cancel-button", 3, "click"], ["pButton", "", "pRipple", "", "label", "Delete", 1, "delete-confirm-button", 3, "click"], [1, "flex", "flex-column", "md:flex-row", "md:align-items-center", "gap-5"], [1, "block", "mt-2", "md:mt-0", "p-input-icon-left"], [1, "pi", "pi-search"], ["pInputText", "", "type", "text", "placeholder", "Search...", 1, "w-full", "sm:w-auto", 3, "input"], ["selectionMode", "range", "dateFormat", "mm/dd/yy", "placeholder", "Select date range", 1, "custom-calendar", 3, "ngModel", "showIcon", "showOnFocus", "readonlyInput", "appendTo", "ngModelChange"], ["pButton", "", "type", "button", "label", "Clear", 1, "p-button-secondary", "clear-button", 3, "click"], ["pSortableColumn", "name", 2, "min-width", "200px", "border-top-left-radius", "8px"], ["field", "name"], ["pSortableColumn", "type", 2, "min-width", "150px"], ["field", "type"], ["pSortableColumn", "description", 2, "min-width", "200px"], ["field", "description"], ["pSortableColumn", "status", 2, "min-width", "150px"], ["field", "status"], [2, "width", "10%", "border-top-right-radius", "8px"], [1, "table-cell"], ["type", "button", "pButton", "", "icon", "pi pi-ellipsis-v", 1, "p-button-text", "p-button-plain", "action-button", 3, "click"], ["menuButton", ""], ["styleClass", "custom-action-menu", 3, "popup", "model", "appendTo"], ["menu", ""], ["colspan", "5"], [1, "flex", "flex-column", "align-items-center", "justify-content-center", 2, "padding", "2rem"], [1, "pi", "pi-building", 2, "font-size", "3rem", "color", "#ccc", "margin-bottom", "1rem"], [2, "font-size", "1.2rem", "color", "#666"], [2, "color", "#888", "margin-top", "0.5rem"], [1, "p-fluid", "p-formgrid", "grid", 3, "formGroup", "ngSubmit"], ["for", "name"], ["pInputText", "", "id", "name", "formControlName", "name"], ["class", "p-error", 4, "ngIf"], ["formGroupName", "staff", 1, "col-12", "md:col-6"], ["for", "firstName"], ["pInputText", "", "id", "firstName", "formControlName", "firstName"], [1, "col-12", "md:col-6"], ["for", "lastName"], ["pInputText", "", "id", "lastName", "formControlName", "lastName"], ["for", "type"], ["id", "type", "formControlName", "type", "placeholder", "Select Type", 3, "options"], ["for", "phoneNumber"], ["pInputText", "", "id", "phoneNumber", "formControlName", "phoneNumber"], ["formGroupName", "staff", 1, "col-12"], ["for", "email"], ["pInputText", "", "id", "email", "formControlName", "email"], ["for", "description"], ["pInputTextarea", "", "id", "description", "formControlName", "description", 3, "rows"], [1, "col-12", "flex", "justify-content-center", "gap-2"], ["pButton", "", "type", "submit", 1, "submit-button", 3, "label", "disabled"], [1, "p-error"]],
    template: function SchoolComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, " Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "app-school-count-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SchoolComponent_Template_button_click_7_listener() {
          return ctx.createNewSchool();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, " Add User ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "p-toast");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "p-table", 8, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("selectionChange", function SchoolComponent_Template_p_table_selectionChange_12_listener($event) {
          return ctx.selectedSchool = $event;
        })("onSort", function SchoolComponent_Template_p_table_onSort_12_listener($event) {
          return ctx.onSort($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, SchoolComponent_ng_template_14_Template, 6, 5, "ng-template", 10)(15, SchoolComponent_ng_template_15_Template, 15, 0, "ng-template", 11)(16, SchoolComponent_ng_template_16_Template, 15, 12, "ng-template", 12)(17, SchoolComponent_ng_template_17_Template, 8, 0, "ng-template", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "p-dialog", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function SchoolComponent_Template_p_dialog_visibleChange_18_listener($event) {
          return ctx.schoolDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, SchoolComponent_ng_template_19_Template, 37, 35, "ng-template", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "p-dialog", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function SchoolComponent_Template_p_dialog_visibleChange_20_listener($event) {
          return ctx.deleteSchoolDialog = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 17)(22, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](23, "i", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "div", 20)(25, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, "Do you want to delete this user -");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "div", 21)(30, "button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SchoolComponent_Template_button_click_30_listener() {
          return ctx.deleteSchoolDialog = false;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SchoolComponent_Template_button_click_31_listener() {
          return ctx.confirmSchoolDelete();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", ctx.schools)("columns", ctx.cols)("rows", 10)("globalFilterFields", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](23, _c4))("paginator", true)("rowsPerPageOptions", ctx.rowsPerPageOptions)("showCurrentPageReport", true)("selection", ctx.selectedSchool)("rowHover", true)("sortField", ctx.sortField)("sortOrder", ctx.sortOrder);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](24, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.schoolDialog)("contentStyle", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](25, _c6))("header", ctx.school.code ? "Edit School" : "Add School")("modal", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](26, _c7));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.deleteSchoolDialog)("modal", true)("showHeader", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("\"", ctx.school == null ? null : ctx.school.name, "\"?");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupName, primeng_table__WEBPACK_IMPORTED_MODULE_13__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_11__.PrimeTemplate, primeng_table__WEBPACK_IMPORTED_MODULE_13__.SortableColumn, primeng_table__WEBPACK_IMPORTED_MODULE_13__.SortIcon, primeng_button__WEBPACK_IMPORTED_MODULE_14__.ButtonDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, primeng_menu__WEBPACK_IMPORTED_MODULE_15__.Menu, primeng_calendar__WEBPACK_IMPORTED_MODULE_16__.Calendar, primeng_ripple__WEBPACK_IMPORTED_MODULE_17__.Ripple, primeng_toast__WEBPACK_IMPORTED_MODULE_18__.Toast, primeng_inputtext__WEBPACK_IMPORTED_MODULE_19__.InputText, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_20__.InputTextarea, primeng_dropdown__WEBPACK_IMPORTED_MODULE_21__.Dropdown, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.Dialog, _school_count_cards_school_count_cards_component__WEBPACK_IMPORTED_MODULE_3__.SchoolCountCardComponent],
    styles: ["\n\n.flex[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  \n\n}\n\n\n\n.search-input[_ngcontent-%COMP%] {\n  width: 246px;\n  \n\n  height: 40px;\n  \n\n  padding-left: 10px;\n  \n\n  border-radius: 4px;\n  \n\n}\n\n\n\n.clear-button[_ngcontent-%COMP%] {\n  width: 63px;\n  height: 23px;\n  gap: 6px;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 3px;\n  padding-top: 4px;\n  padding-right: 8px;\n  padding-bottom: 4px;\n  padding-left: 8px;\n}\n.clear-button[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n\n\n\n.clear-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  margin-right: 4px;\n  \n\n}\n\n  .add-button {\n  width: 11.5rem;\n  height: 3rem;\n  font-weight: 600;\n  color: #fff;\n  border: none;\n  background: linear-gradient(to right, #5978F7, #9C84FF);\n  border-radius: 6px;\n  padding: 0.5rem 1rem;\n  transition: background 0.3s ease;\n  margin-bottom: 1rem;\n}\n  .add-button:hover {\n  background: linear-gradient(to right, #4B68E1, #8B6EFF);\n}\n  .add-button:disabled {\n  cursor: not-allowed !important;\n}\n\n.table-cell[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.action-container[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.plain-dots[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  cursor: pointer;\n  padding: 5px;\n}\n\n.custom-dropdown[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 100%;\n  background: white;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  border-radius: 4px;\n  z-index: 1000;\n}\n\n.dropdown-item[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  padding: 8px 16px;\n  border: none;\n  background: none;\n  text-align: left;\n  cursor: pointer;\n}\n.dropdown-item[_ngcontent-%COMP%]:hover {\n  background-color: #f5f5f5;\n}\n\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td {\n  background: #fff;\n  text-align: center;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i {\n  transition: color 0.2s;\n}\n[_nghost-%COMP%]     .p-datatable .p-datatable-emptymessage td i:hover {\n  color: #999 !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=role], [_nghost-%COMP%]     th[pSortableColumn=requestsPending], [_nghost-%COMP%]     th[pSortableColumn=requestsCompleted], [_nghost-%COMP%]     th[pSortableColumn=consumptions] {\n  text-align: center !important;\n}\n[_nghost-%COMP%]     th[pSortableColumn=role] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=requestsPending] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=requestsCompleted] .p-sortable-column-icon, [_nghost-%COMP%]     th[pSortableColumn=consumptions] .p-sortable-column-icon {\n  margin-left: 4px;\n}\n\n[_nghost-%COMP%]     .custom-calendar .p-calendar {\n  min-width: 247px;\n  display: inline-flex;\n  position: relative;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar input {\n  width: 100%;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 8px 0 0 8px;\n  padding: 0.5rem;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger {\n  width: 40px;\n  height: 40px;\n  background: rgba(177, 175, 233, 0.1019607843);\n  border: none;\n  border-radius: 0 8px 8px 0;\n  color: #666;\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:enabled:hover {\n  background: rgba(177, 175, 233, 0.1019607843);\n}\n[_nghost-%COMP%]     .custom-calendar .p-calendar .p-datepicker-trigger:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker {\n  min-width: 247px;\n}\n[_nghost-%COMP%]     .custom-calendar .p-datepicker.p-datepicker-inline {\n  position: absolute;\n  top: 100%;\n  left: 0;\n  z-index: 1000;\n}\n\n[_nghost-%COMP%]     .update-button {\n  width: 364.42px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .update-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .update-button:disabled {\n  opacity: 0.6;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  cursor: not-allowed;\n}\n\n.classroom-initial[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  background: #E6E8F3;\n  color: #FFFFFF;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.classroom-count[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 23px;\n  gap: 16px;\n  padding: 4px 8px;\n  border-radius: 3px;\n  background-color: rgba(217, 255, 203, 0.4);\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 12px;\n  color: #333333;\n}\n\n  .p-tooltip .p-tooltip-text {\n  background-color: #F0FFEA !important;\n  color: #333333 !important;\n  border: 1px solid #E6E6E6;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  font-size: 11px;\n}\n  .p-tooltip .p-tooltip-arrow {\n  border-top-color: #F0FFEA !important;\n}\n\n.classroom-count-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #6E6E6E;\n  cursor: pointer;\n  opacity: 0.7;\n  transition: opacity 0.2s;\n}\n.classroom-count-wrapper[_ngcontent-%COMP%]   .edit-icon[_ngcontent-%COMP%]:hover {\n  opacity: 1;\n}\n\n[_nghost-%COMP%]     .p-menu {\n  background: none !important;\n  border: none !important;\n  box-shadow: none !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay {\n  margin: 0;\n  padding: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu {\n  width: 73px !important;\n  min-height: 80px !important;\n  padding: 16px !important;\n  border-radius: 8px !important;\n  border: 1px solid #E6E6E6 !important;\n  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.05) !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu * {\n  background: #FFFFFF !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list {\n  gap: 16px;\n  display: flex;\n  flex-direction: column;\n  padding: 0;\n  margin: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem {\n  margin: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link {\n  padding: 0;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link:hover .p-menuitem-text, [_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link:hover .p-menuitem-icon {\n  color: #5978F7 !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link .p-menuitem-icon {\n  font-size: 12px;\n  margin-right: 8px;\n  color: #6C757D !important;\n}\n[_nghost-%COMP%]     .custom-action-menu.p-menu-overlay .p-menu .p-menu-list .p-menuitem .p-menuitem-link .p-menuitem-text {\n  font-size: 12px;\n  color: #495057 !important;\n}\n\n[_nghost-%COMP%]     .delete-dialog .p-dialog-content {\n  padding: 2rem;\n}\n[_nghost-%COMP%]     .delete-icon-container {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background-color: #D92D20;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 1rem;\n}\n[_nghost-%COMP%]     .delete-icon-container .pi-trash {\n  font-size: 24px;\n  color: #FFFFFF;\n}\n[_nghost-%COMP%]     .delete-message {\n  font-size: 14px;\n  color: #344054;\n  line-height: 1.5;\n}\n[_nghost-%COMP%]     .delete-message strong {\n  color: #101828;\n}\n\n[_nghost-%COMP%]     .delete-confirm-button {\n  width: 177px;\n  height: 48px;\n  border-radius: 6.96px;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  border: none;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .delete-confirm-button:hover {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n}\n[_nghost-%COMP%]     .delete-confirm-button:focus {\n  box-shadow: none;\n}\n[_nghost-%COMP%]     .cancel-button {\n  color: #6C757D;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n  color: #495057;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .cancel-button {\n  width: 177.21px;\n  height: 48px;\n  border-radius: 6.96px;\n  gap: 8.7px;\n  background: transparent;\n  position: relative;\n}\n[_nghost-%COMP%]     .cancel-button::before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  border-radius: 6.96px;\n  border: 1px solid transparent;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%) border-box;\n  -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);\n  -webkit-mask-composite: destination-out;\n  mask-composite: exclude;\n}\n[_nghost-%COMP%]     .cancel-button .p-button-label {\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n  font-weight: 500;\n}\n[_nghost-%COMP%]     .cancel-button:hover {\n  background: transparent;\n}\n[_nghost-%COMP%]     .cancel-button:hover::before {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%) border-box;\n}\n[_nghost-%COMP%]     .cancel-button:hover .p-button-label {\n  background: linear-gradient(90deg, #4967E6 0%, #8B73EE 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n}\n[_nghost-%COMP%]     .cancel-button:focus {\n  box-shadow: none;\n}\n\n[_nghost-%COMP%]     .p-dialog.p-fluid {\n  height: auto;\n}\n[_nghost-%COMP%]     .p-dialog.p-fluid .p-dialog-content {\n  overflow-y: visible;\n  overflow-x: hidden;\n  max-height: none !important;\n}\n[_nghost-%COMP%]     .p-dialog .p-fluid .grid {\n  row-gap: 1.5rem;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvc2Nob29sL2xpc3Qvc2Nob29sLmNvbXBvbmVudC5zY3NzIiwid2VicGFjazovLy4vLi4vLi4vTmV3JTIwZm9sZGVyL3Znc2Nob29sLXRoZW1lL3NyYy9hcHAvbW9kdWxlcy9hcHAvc2Nob29sL2xpc3Qvc2Nob29sLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLG1EQUFBO0FBQ0E7RUFDSSxhQUFBO0VBQ0EsU0FBQTtFQUNBLGtDQUFBO0FDQ0o7O0FERUEsd0JBQUE7QUFDQTtFQUNJLFlBQUE7RUFDQSxrQ0FBQTtFQUNBLFlBQUE7RUFDQSxtQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsOENBQUE7RUFDQSxrQkFBQTtFQUNBLGtDQUFBO0FDQ0o7O0FESUEsK0JBQUE7QUFDQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsUUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsdURBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FDREo7QURHSTtFQUNJLHVEQUFBO0FDRFI7O0FES0EsMENBQUE7QUFDQTtFQUNJLGlCQUFBO0VBQ0EsdURBQUE7QUNGSjs7QURPSTtFQUNJLGNBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVEQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtFQUNBLGdDQUFBO0VBQ0EsbUJBQUE7QUNKUjtBRE1RO0VBQ0ksdURBQUE7QUNKWjtBRE9RO0VBRUksOEJBQUE7QUNOWjs7QURZQTtFQUNJLGtCQUFBO0FDVEo7O0FEWUE7RUFDSSxrQkFBQTtFQUNBLHFCQUFBO0FDVEo7O0FEWUE7RUFDSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQ1RKOztBRFlBO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGlCQUFBO0VBQ0Esd0NBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUNUSjs7QURZQTtFQUNJLGNBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUNUSjtBRFdJO0VBQ0kseUJBQUE7QUNUUjs7QURnQlk7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0FDYmhCO0FEZWdCO0VBQ0ksc0JBQUE7QUNicEI7QURlb0I7RUFDSSxzQkFBQTtBQ2J4QjtBRHVCSTs7OztFQUlJLDZCQUFBO0FDckJSO0FEdUJROzs7O0VBQ0ksZ0JBQUE7QUNsQlo7O0FENEJRO0VBQ0ksZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0FDekJaO0FEMkJZO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSw2Q0FBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtFQUNBLGVBQUE7QUN6QmhCO0FENEJZO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSw2Q0FBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtFQUNBLFdBQUE7QUMxQmhCO0FENEJnQjtFQUNJLDZDQUFBO0FDMUJwQjtBRDZCZ0I7RUFDSSxnQkFBQTtBQzNCcEI7QURnQ1E7RUFDSSxnQkFBQTtBQzlCWjtBRGdDWTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLE9BQUE7RUFDQSxhQUFBO0FDOUJoQjs7QURxQ0k7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsNERBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNsQ1I7QURvQ1E7RUFDSSw0REFBQTtBQ2xDWjtBRHFDUTtFQUNJLFlBQUE7RUFDQSw0REFBQTtFQUNBLG1CQUFBO0FDbkNaOztBRHdDQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ3JDSjs7QUR3Q0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMENBQUE7RUFDQSxvQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQ3JDSjs7QUR5Q0k7RUFDSSxvQ0FBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7RUFDQSx3Q0FBQTtFQUNBLGVBQUE7QUN0Q1I7QUR5Q0k7RUFDSSxvQ0FBQTtBQ3ZDUjs7QUQyQ0E7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxRQUFBO0FDeENKO0FEMENJO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHdCQUFBO0FDeENSO0FEMENRO0VBQ0ksVUFBQTtBQ3hDWjs7QURnREk7RUFDSSwyQkFBQTtFQUNBLHVCQUFBO0VBQ0EsMkJBQUE7QUM3Q1I7QURrRFE7RUFDSSxTQUFBO0VBQ0EsVUFBQTtBQ2hEWjtBRGtEWTtFQUNJLHNCQUFBO0VBQ0EsMkJBQUE7RUFDQSx3QkFBQTtFQUNBLDZCQUFBO0VBQ0Esb0NBQUE7RUFDQSxzREFBQTtBQ2hEaEI7QURrRGdCO0VBQ0ksOEJBQUE7QUNoRHBCO0FEbURnQjtFQUNJLFNBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtBQ2pEcEI7QURtRG9CO0VBQ0ksU0FBQTtBQ2pEeEI7QURtRHdCO0VBQ0ksVUFBQTtBQ2pENUI7QURxRGdDOztFQUVJLHlCQUFBO0FDbkRwQztBRHVENEI7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtBQ3JEaEM7QUR3RDRCO0VBQ0ksZUFBQTtFQUNBLHlCQUFBO0FDdERoQzs7QURrRVE7RUFDSSxhQUFBO0FDL0RaO0FEbUVJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ2pFUjtBRG1FUTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FDakVaO0FEcUVJO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ25FUjtBRHFFUTtFQUNJLGNBQUE7QUNuRVo7O0FEeUVJO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLDREQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDdEVSO0FEd0VRO0VBQ0ksNERBQUE7QUN0RVo7QUR5RVE7RUFDSSxnQkFBQTtBQ3ZFWjtBRDJFSTtFQUNJLGNBQUE7QUN6RVI7QUQyRVE7RUFDSSx1QkFBQTtFQUNBLGNBQUE7QUN6RVo7QUQ0RVE7RUFDSSxnQkFBQTtBQzFFWjs7QURnRkk7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUM3RVI7QURnRlE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EscUJBQUE7RUFDQSw2QkFBQTtFQUNBLHVFQUFBO0VBQ0EsOEVBQ0k7RUFFSix1Q0FBQTtFQUNBLHVCQUFBO0FDaEZaO0FEb0ZRO0VBQ0ksNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0NBQUE7RUFDQSxnQkFBQTtBQ2xGWjtBRHFGUTtFQUNJLHVCQUFBO0FDbkZaO0FEcUZZO0VBQ0ksdUVBQUE7QUNuRmhCO0FEc0ZZO0VBQ0ksNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0FDcEZoQjtBRHdGUTtFQUNJLGdCQUFBO0FDdEZaOztBRCtGUTtFQUNJLFlBQUE7QUM1Rlo7QUQ4Rlk7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7QUM1RmhCO0FEdUdZO0VBQ0ksZUFBQTtBQ3JHaEIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBHZW5lcmFsIEZsZXggTGF5b3V0OiAxMnB4IGdhcCBiZXR3ZWVuIGNvbnRyb2xzICovXHJcbi5mbGV4IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBnYXA6IDEycHg7XHJcbiAgICAvKiAxMnB4IGdhcCBiZXR3ZWVuIGVhY2ggY29udHJvbCAqL1xyXG59XHJcblxyXG4vKiBTZWFyY2ggSW5wdXQgc3R5bGVzICovXHJcbi5zZWFyY2gtaW5wdXQge1xyXG4gICAgd2lkdGg6IDI0NnB4O1xyXG4gICAgLyogTWF0Y2hpbmcgdGhlIHdpZHRoIGZyb20gRmlnbWEgKi9cclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIC8qIE1hdGNoaW5nIHRoZSBoZWlnaHQgZnJvbSBGaWdtYSAqL1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgLyogT3B0aW9uYWw6IFNwYWNlIGJldHdlZW4gdGhlIGljb24gYW5kIHRleHQgKi9cclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIC8qIFJvdW5kZWQgY29ybmVycyBmb3IgdGhlIGlucHV0ICovXHJcbn1cclxuXHJcblxyXG5cclxuLyogQ2xlYXIgQnV0dG9uIGN1c3RvbSBzdHlsZXMgKi9cclxuLmNsZWFyLWJ1dHRvbiB7XHJcbiAgICB3aWR0aDogNjNweDtcclxuICAgIGhlaWdodDogMjNweDtcclxuICAgIGdhcDogNnB4O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpOyAvLyBJbmRpZ28gNTAwIHRvIDYwMFxyXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgcGFkZGluZy10b3A6IDRweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDhweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA0cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDhweDtcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0QjY4RTEsICM4QjZFRkYpOyAvLyBEYXJrZXIgb24gaG92ZXJcclxuICAgIH1cclxufVxyXG5cclxuLyogT3B0aW9uYWw6IFN0eWxlIGZvciB0aGUgYnV0dG9uJ3MgaWNvbiAqL1xyXG4uY2xlYXItYnV0dG9uIGkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbiAgICAvKiBBZGp1c3QgaWYgeW91IHdhbnQgc3BhY2UgYmV0d2VlbiB0aGUgaWNvbiBhbmQgdGV4dCAqL1xyXG59XHJcblxyXG5cclxuOjpuZy1kZWVwIHtcclxuICAgIC5hZGQtYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMTEuNXJlbTtcclxuICAgICAgICBoZWlnaHQ6IDNyZW07XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNTk3OEY3LCAjOUM4NEZGKTsgLy8gSW5kaWdvIDUwMCB0byA2MDBcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICAgICAgcGFkZGluZzogMC41cmVtIDFyZW07XHJcbiAgICAgICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjNzIGVhc2U7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzRCNjhFMSwgIzhCNkVGRik7IC8vIERhcmtlciBvbiBob3ZlclxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJjpkaXNhYmxlZCB7XHJcbiAgICAgICAgICAgIC8vIG9wYWNpdHk6IDAuNiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBjdXJzb3I6IG5vdC1hbGxvd2VkICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuLnRhYmxlLWNlbGwge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4uYWN0aW9uLWNvbnRhaW5lciB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuXHJcbi5wbGFpbi1kb3RzIHtcclxuICAgIGJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbn1cclxuXHJcbi5jdXN0b20tZHJvcGRvd24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICB6LWluZGV4OiAxMDAwO1xyXG59XHJcblxyXG4uZHJvcGRvd24taXRlbSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogOHB4IDE2cHg7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xyXG4gICAgfVxyXG59XHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLnAtZGF0YXRhYmxlIHtcclxuICAgICAgICAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHtcclxuICAgICAgICAgICAgdGQge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbiAgICAgICAgICAgICAgICBpIHtcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBjb2xvciAwLjJzO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM5OTkgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRW5zdXJlIGhlYWRlciBjZWxscyBhcmUgYWxzbyBjZW50ZXJlZFxyXG4gICAgLy8gdGhbcFNvcnRhYmxlQ29sdW1uPVwibmFtZVwiXSxcclxuICAgIC8vIHRoW3BTb3J0YWJsZUNvbHVtbj1cImNsYXNzcm9vbXNcIl0sXHJcbiAgICB0aFtwU29ydGFibGVDb2x1bW49XCJyb2xlXCJdLFxyXG4gICAgdGhbcFNvcnRhYmxlQ29sdW1uPVwicmVxdWVzdHNQZW5kaW5nXCJdLFxyXG4gICAgdGhbcFNvcnRhYmxlQ29sdW1uPVwicmVxdWVzdHNDb21wbGV0ZWRcIl0sXHJcbiAgICB0aFtwU29ydGFibGVDb2x1bW49XCJjb25zdW1wdGlvbnNcIl0ge1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xyXG5cclxuICAgICAgICAucC1zb3J0YWJsZS1jb2x1bW4taWNvbiB7XHJcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiA0cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbn1cclxuXHJcblxyXG46aG9zdCA6Om5nLWRlZXAge1xyXG4gICAgLmN1c3RvbS1jYWxlbmRhciB7XHJcbiAgICAgICAgLnAtY2FsZW5kYXIge1xyXG4gICAgICAgICAgICBtaW4td2lkdGg6IDI0N3B4O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuICAgICAgICAgICAgaW5wdXQge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjQjFBRkU5MUE7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHggMCAwIDhweDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAuNXJlbTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLnAtZGF0ZXBpY2tlci10cmlnZ2VyIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0IxQUZFOTFBO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMCA4cHggOHB4IDA7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzY2NjtcclxuXHJcbiAgICAgICAgICAgICAgICAmOmVuYWJsZWQ6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNCMUFGRTkxQTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAmOmZvY3VzIHtcclxuICAgICAgICAgICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAucC1kYXRlcGlja2VyIHtcclxuICAgICAgICAgICAgbWluLXdpZHRoOiAyNDdweDtcclxuXHJcbiAgICAgICAgICAgICYucC1kYXRlcGlja2VyLWlubGluZSB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICB0b3A6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICAgICAgei1pbmRleDogMTAwMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC51cGRhdGUtYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogMzY0LjQycHg7XHJcbiAgICAgICAgaGVpZ2h0OiA0OHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XHJcbiAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcblxyXG4gICAgICAgICY6aG92ZXIge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAmOmRpc2FibGVkIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMC42O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XHJcbiAgICAgICAgICAgIGN1cnNvcjogbm90LWFsbG93ZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4uY2xhc3Nyb29tLWluaXRpYWwge1xyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IDI0cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTZFOEYzO1xyXG4gICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG5cclxuLmNsYXNzcm9vbS1jb3VudCB7XHJcbiAgICB3aWR0aDogMzJweDtcclxuICAgIGhlaWdodDogMjNweDtcclxuICAgIGdhcDogMTZweDtcclxuICAgIHBhZGRpbmc6IDRweCA4cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRDlGRkNCNjY7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjMzMzMzMzO1xyXG59XHJcblxyXG46Om5nLWRlZXAgLnAtdG9vbHRpcCB7XHJcbiAgICAucC10b29sdGlwLXRleHQge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcclxuICAgICAgICBjb2xvcjogIzMzMzMzMyAhaW1wb3J0YW50O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNFNkU2RTY7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICB9XHJcblxyXG4gICAgLnAtdG9vbHRpcC1hcnJvdyB7XHJcbiAgICAgICAgYm9yZGVyLXRvcC1jb2xvcjogI0YwRkZFQSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59XHJcblxyXG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBnYXA6IDhweDtcclxuXHJcbiAgICAuZWRpdC1pY29uIHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgY29sb3I6ICM2RTZFNkU7XHJcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgIG9wYWNpdHk6IDAuNztcclxuICAgICAgICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuMnM7XHJcblxyXG4gICAgICAgICY6aG92ZXIge1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuXHJcbiAgICAvLyBSZXNldCBhbmQgb3ZlcnJpZGUgYWxsIG1lbnUgc3R5bGVzXHJcbiAgICAucC1tZW51IHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFN0eWxlIHRoZSBzcGVjaWZpYyBtZW51IG92ZXJsYXlcclxuICAgIC5jdXN0b20tYWN0aW9uLW1lbnUge1xyXG4gICAgICAgICYucC1tZW51LW92ZXJsYXkge1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcblxyXG4gICAgICAgICAgICAucC1tZW51IHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA3M3B4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICBtaW4taGVpZ2h0OiA4MHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNFNkU2RTYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4wNSkgIWltcG9ydGFudDtcclxuXHJcbiAgICAgICAgICAgICAgICAqIHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkZGRkZGICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLnAtbWVudS1saXN0IHtcclxuICAgICAgICAgICAgICAgICAgICBnYXA6IDE2cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5wLW1lbnVpdGVtLWxpbmsge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAmOmhvdmVyIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnAtbWVudWl0ZW0tdGV4dCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucC1tZW51aXRlbS1pY29uIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM1OTc4RjcgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnAtbWVudWl0ZW0taWNvbiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNkM3NTdEICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnAtbWVudWl0ZW0tdGV4dCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNDk1MDU3ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAuZGVsZXRlLWRpYWxvZyB7XHJcbiAgICAgICAgLnAtZGlhbG9nLWNvbnRlbnQge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAycmVtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuZGVsZXRlLWljb24tY29udGFpbmVyIHtcclxuICAgICAgICB3aWR0aDogNjRweDtcclxuICAgICAgICBoZWlnaHQ6IDY0cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNEOTJEMjA7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDFyZW07XHJcblxyXG4gICAgICAgIC5waS10cmFzaCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgICAgICAgICAgY29sb3I6ICNGRkZGRkY7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5kZWxldGUtbWVzc2FnZSB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGNvbG9yOiAjMzQ0MDU0O1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxLjU7XHJcblxyXG4gICAgICAgIHN0cm9uZyB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMTAxODI4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIHtcclxuICAgIC5kZWxldGUtY29uZmlybS1idXR0b24ge1xyXG4gICAgICAgIHdpZHRoOiAxNzdweDtcclxuICAgICAgICBoZWlnaHQ6IDQ4cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNi45NnB4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcclxuICAgICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuXHJcbiAgICAgICAgJjpob3ZlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuY2FuY2VsLWJ1dHRvbiB7XHJcbiAgICAgICAgY29sb3I6ICM2Qzc1N0Q7XHJcblxyXG4gICAgICAgICY6aG92ZXIge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgY29sb3I6ICM0OTUwNTc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAmOmZvY3VzIHtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAuY2FuY2VsLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDE3Ny4yMXB4O1xyXG4gICAgICAgIGhlaWdodDogNDhweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XHJcbiAgICAgICAgZ2FwOiA4LjdweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgICAgIC8vIENyZWF0ZSBncmFkaWVudCBib3JkZXJcclxuICAgICAgICAmOjpiZWZvcmUge1xyXG4gICAgICAgICAgICBjb250ZW50OiAnJztcclxuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICB0b3A6IDA7XHJcbiAgICAgICAgICAgIGxlZnQ6IDA7XHJcbiAgICAgICAgICAgIHJpZ2h0OiAwO1xyXG4gICAgICAgICAgICBib3R0b206IDA7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDYuOTZweDtcclxuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKSBib3JkZXItYm94O1xyXG4gICAgICAgICAgICAtd2Via2l0LW1hc2s6XHJcbiAgICAgICAgICAgICAgICBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApIHBhZGRpbmctYm94LFxyXG4gICAgICAgICAgICAgICAgbGluZWFyLWdyYWRpZW50KCNmZmYgMCAwKTtcclxuICAgICAgICAgICAgLXdlYmtpdC1tYXNrLWNvbXBvc2l0ZTogZGVzdGluYXRpb24tb3V0O1xyXG4gICAgICAgICAgICBtYXNrLWNvbXBvc2l0ZTogZXhjbHVkZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIEdyYWRpZW50IHRleHRcclxuICAgICAgICAucC1idXR0b24tbGFiZWwge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XHJcbiAgICAgICAgICAgIC13ZWJraXQtYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIC13ZWJraXQtdGV4dC1maWxsLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICY6aG92ZXIge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuXHJcbiAgICAgICAgICAgICY6OmJlZm9yZSB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSkgYm9yZGVyLWJveDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLnAtYnV0dG9uLWxhYmVsIHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcclxuICAgICAgICAgICAgICAgIC13ZWJraXQtYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAmOmZvY3VzIHtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCB7XHJcblxyXG4gICAgLy8gQWRkIHRoaXMgbmV3IHNlY3Rpb25cclxuICAgIC5wLWRpYWxvZyB7XHJcbiAgICAgICAgJi5wLWZsdWlkIHtcclxuICAgICAgICAgICAgaGVpZ2h0OiBhdXRvO1xyXG5cclxuICAgICAgICAgICAgLnAtZGlhbG9nLWNvbnRlbnQge1xyXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3cteTogdmlzaWJsZTtcclxuICAgICAgICAgICAgICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcclxuICAgICAgICAgICAgICAgIG1heC1oZWlnaHQ6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICAgIC8vIHBhZGRpbmc6IDJyZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5wLWRpYWxvZy1oZWFkZXIge1xyXG4gICAgICAgICAgICAvLyBwYWRkaW5nOiAycmVtIDJyZW0gMCAycmVtO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gQWRqdXN0IGZvcm0gc3BhY2luZ1xyXG4gICAgICAgIC5wLWZsdWlkIHtcclxuICAgICAgICAgICAgLmdyaWQge1xyXG4gICAgICAgICAgICAgICAgcm93LWdhcDogMS41cmVtO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59IiwiLyogR2VuZXJhbCBGbGV4IExheW91dDogMTJweCBnYXAgYmV0d2VlbiBjb250cm9scyAqL1xuLmZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xuICBnYXA6IDEycHg7XG4gIC8qIDEycHggZ2FwIGJldHdlZW4gZWFjaCBjb250cm9sICovXG59XG5cbi8qIFNlYXJjaCBJbnB1dCBzdHlsZXMgKi9cbi5zZWFyY2gtaW5wdXQge1xuICB3aWR0aDogMjQ2cHg7XG4gIC8qIE1hdGNoaW5nIHRoZSB3aWR0aCBmcm9tIEZpZ21hICovXG4gIGhlaWdodDogNDBweDtcbiAgLyogTWF0Y2hpbmcgdGhlIGhlaWdodCBmcm9tIEZpZ21hICovXG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgLyogT3B0aW9uYWw6IFNwYWNlIGJldHdlZW4gdGhlIGljb24gYW5kIHRleHQgKi9cbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAvKiBSb3VuZGVkIGNvcm5lcnMgZm9yIHRoZSBpbnB1dCAqL1xufVxuXG4vKiBDbGVhciBCdXR0b24gY3VzdG9tIHN0eWxlcyAqL1xuLmNsZWFyLWJ1dHRvbiB7XG4gIHdpZHRoOiA2M3B4O1xuICBoZWlnaHQ6IDIzcHg7XG4gIGdhcDogNnB4O1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyOiBub25lO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM1OTc4RjcsICM5Qzg0RkYpO1xuICBib3JkZXItcmFkaXVzOiAzcHg7XG4gIHBhZGRpbmctdG9wOiA0cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDhweDtcbiAgcGFkZGluZy1ib3R0b206IDRweDtcbiAgcGFkZGluZy1sZWZ0OiA4cHg7XG59XG4uY2xlYXItYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNEI2OEUxLCAjOEI2RUZGKTtcbn1cblxuLyogT3B0aW9uYWw6IFN0eWxlIGZvciB0aGUgYnV0dG9uJ3MgaWNvbiAqL1xuLmNsZWFyLWJ1dHRvbiBpIHtcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XG4gIC8qIEFkanVzdCBpZiB5b3Ugd2FudCBzcGFjZSBiZXR3ZWVuIHRoZSBpY29uIGFuZCB0ZXh0ICovXG59XG5cbjo6bmctZGVlcCAuYWRkLWJ1dHRvbiB7XG4gIHdpZHRoOiAxMS41cmVtO1xuICBoZWlnaHQ6IDNyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiAjZmZmO1xuICBib3JkZXI6IG5vbmU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzU5NzhGNywgIzlDODRGRik7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgcGFkZGluZzogMC41cmVtIDFyZW07XG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4zcyBlYXNlO1xuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xufVxuOjpuZy1kZWVwIC5hZGQtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNEI2OEUxLCAjOEI2RUZGKTtcbn1cbjo6bmctZGVlcCAuYWRkLWJ1dHRvbjpkaXNhYmxlZCB7XG4gIGN1cnNvcjogbm90LWFsbG93ZWQgIWltcG9ydGFudDtcbn1cblxuLnRhYmxlLWNlbGwge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5hY3Rpb24tY29udGFpbmVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbi5wbGFpbi1kb3RzIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgYm9yZGVyOiBub25lO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLmN1c3RvbS1kcm9wZG93biB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogMTAwJTtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgei1pbmRleDogMTAwMDtcbn1cblxuLmRyb3Bkb3duLWl0ZW0ge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDhweCAxNnB4O1xuICBib3JkZXI6IG5vbmU7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi5kcm9wZG93bi1pdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIGkge1xuICB0cmFuc2l0aW9uOiBjb2xvciAwLjJzO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRhdGF0YWJsZSAucC1kYXRhdGFibGUtZW1wdHltZXNzYWdlIHRkIGk6aG92ZXIge1xuICBjb2xvcjogIzk5OSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yb2xlXSxcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cmVxdWVzdHNQZW5kaW5nXSxcbjpob3N0IDo6bmctZGVlcCB0aFtwU29ydGFibGVDb2x1bW49cmVxdWVzdHNDb21wbGV0ZWRdLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1jb25zdW1wdGlvbnNdIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPXJvbGVdIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yZXF1ZXN0c1BlbmRpbmddIC5wLXNvcnRhYmxlLWNvbHVtbi1pY29uLFxuOmhvc3QgOjpuZy1kZWVwIHRoW3BTb3J0YWJsZUNvbHVtbj1yZXF1ZXN0c0NvbXBsZXRlZF0gLnAtc29ydGFibGUtY29sdW1uLWljb24sXG46aG9zdCA6Om5nLWRlZXAgdGhbcFNvcnRhYmxlQ29sdW1uPWNvbnN1bXB0aW9uc10gLnAtc29ydGFibGUtY29sdW1uLWljb24ge1xuICBtYXJnaW4tbGVmdDogNHB4O1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciB7XG4gIG1pbi13aWR0aDogMjQ3cHg7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1jYWxlbmRhciAucC1jYWxlbmRhciBpbnB1dCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDQwcHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTc3LCAxNzUsIDIzMywgMC4xMDE5NjA3ODQzKTtcbiAgYm9yZGVyOiBub25lO1xuICBib3JkZXItcmFkaXVzOiA4cHggMCAwIDhweDtcbiAgcGFkZGluZzogMC41cmVtO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci10cmlnZ2VyIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgYmFja2dyb3VuZDogcmdiYSgxNzcsIDE3NSwgMjMzLCAwLjEwMTk2MDc4NDMpO1xuICBib3JkZXI6IG5vbmU7XG4gIGJvcmRlci1yYWRpdXM6IDAgOHB4IDhweCAwO1xuICBjb2xvcjogIzY2Njtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXItdHJpZ2dlcjplbmFibGVkOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogcmdiYSgxNzcsIDE3NSwgMjMzLCAwLjEwMTk2MDc4NDMpO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci10cmlnZ2VyOmZvY3VzIHtcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWNhbGVuZGFyIC5wLWRhdGVwaWNrZXIge1xuICBtaW4td2lkdGg6IDI0N3B4O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tY2FsZW5kYXIgLnAtZGF0ZXBpY2tlci5wLWRhdGVwaWNrZXItaW5saW5lIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDEwMCU7XG4gIGxlZnQ6IDA7XG4gIHotaW5kZXg6IDEwMDA7XG59XG5cbjpob3N0IDo6bmctZGVlcCAudXBkYXRlLWJ1dHRvbiB7XG4gIHdpZHRoOiAzNjQuNDJweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNDk2N0U2IDAlLCAjOEI3M0VFIDEwMCUpO1xufVxuOmhvc3QgOjpuZy1kZWVwIC51cGRhdGUtYnV0dG9uOmRpc2FibGVkIHtcbiAgb3BhY2l0eTogMC42O1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XG59XG5cbi5jbGFzc3Jvb20taW5pdGlhbCB7XG4gIHdpZHRoOiAyNHB4O1xuICBoZWlnaHQ6IDI0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZDogI0U2RThGMztcbiAgY29sb3I6ICNGRkZGRkY7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXNpemU6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5jbGFzc3Jvb20tY291bnQge1xuICB3aWR0aDogMzJweDtcbiAgaGVpZ2h0OiAyM3B4O1xuICBnYXA6IDE2cHg7XG4gIHBhZGRpbmc6IDRweCA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyMTcsIDI1NSwgMjAzLCAwLjQpO1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICMzMzMzMzM7XG59XG5cbjo6bmctZGVlcCAucC10b29sdGlwIC5wLXRvb2x0aXAtdGV4dCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcbiAgY29sb3I6ICMzMzMzMzMgIWltcG9ydGFudDtcbiAgYm9yZGVyOiAxcHggc29saWQgI0U2RTZFNjtcbiAgYm94LXNoYWRvdzogMCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgZm9udC1zaXplOiAxMXB4O1xufVxuOjpuZy1kZWVwIC5wLXRvb2x0aXAgLnAtdG9vbHRpcC1hcnJvdyB7XG4gIGJvcmRlci10b3AtY29sb3I6ICNGMEZGRUEgIWltcG9ydGFudDtcbn1cblxuLmNsYXNzcm9vbS1jb3VudC13cmFwcGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZ2FwOiA4cHg7XG59XG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIgLmVkaXQtaWNvbiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM2RTZFNkU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgb3BhY2l0eTogMC43O1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuMnM7XG59XG4uY2xhc3Nyb29tLWNvdW50LXdyYXBwZXIgLmVkaXQtaWNvbjpob3ZlciB7XG4gIG9wYWNpdHk6IDE7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1tZW51IHtcbiAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xuICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkge1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IHtcbiAgd2lkdGg6IDczcHggIWltcG9ydGFudDtcbiAgbWluLWhlaWdodDogODBweCAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAxNnB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDhweCAhaW1wb3J0YW50O1xuICBib3JkZXI6IDFweCBzb2xpZCAjRTZFNkU2ICFpbXBvcnRhbnQ7XG4gIGJveC1zaGFkb3c6IDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4wNSkgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgKiB7XG4gIGJhY2tncm91bmQ6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IHtcbiAgZ2FwOiAxNnB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDA7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IC5wLW1lbnUtbGlzdCAucC1tZW51aXRlbSB7XG4gIG1hcmdpbjogMDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IC5wLW1lbnVpdGVtIC5wLW1lbnVpdGVtLWxpbmsge1xuICBwYWRkaW5nOiAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3QgLnAtbWVudWl0ZW0gLnAtbWVudWl0ZW0tbGluazpob3ZlciAucC1tZW51aXRlbS10ZXh0LFxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tYWN0aW9uLW1lbnUucC1tZW51LW92ZXJsYXkgLnAtbWVudSAucC1tZW51LWxpc3QgLnAtbWVudWl0ZW0gLnAtbWVudWl0ZW0tbGluazpob3ZlciAucC1tZW51aXRlbS1pY29uIHtcbiAgY29sb3I6ICM1OTc4RjcgIWltcG9ydGFudDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLWFjdGlvbi1tZW51LnAtbWVudS1vdmVybGF5IC5wLW1lbnUgLnAtbWVudS1saXN0IC5wLW1lbnVpdGVtIC5wLW1lbnVpdGVtLWxpbmsgLnAtbWVudWl0ZW0taWNvbiB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XG4gIGNvbG9yOiAjNkM3NTdEICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmN1c3RvbS1hY3Rpb24tbWVudS5wLW1lbnUtb3ZlcmxheSAucC1tZW51IC5wLW1lbnUtbGlzdCAucC1tZW51aXRlbSAucC1tZW51aXRlbS1saW5rIC5wLW1lbnVpdGVtLXRleHQge1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjNDk1MDU3ICFpbXBvcnRhbnQ7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuZGVsZXRlLWRpYWxvZyAucC1kaWFsb2ctY29udGVudCB7XG4gIHBhZGRpbmc6IDJyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciB7XG4gIHdpZHRoOiA2NHB4O1xuICBoZWlnaHQ6IDY0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0Q5MkQyMDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1pY29uLWNvbnRhaW5lciAucGktdHJhc2gge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtbWVzc2FnZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICMzNDQwNTQ7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1tZXNzYWdlIHN0cm9uZyB7XG4gIGNvbG9yOiAjMTAxODI4O1xufVxuXG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbiB7XG4gIHdpZHRoOiAxNzdweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5kZWxldGUtY29uZmlybS1idXR0b246aG92ZXIge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM0OTY3RTYgMCUsICM4QjczRUUgMTAwJSk7XG59XG46aG9zdCA6Om5nLWRlZXAgLmRlbGV0ZS1jb25maXJtLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b24ge1xuICBjb2xvcjogIzZDNzU3RDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBjb2xvcjogIzQ5NTA1Nztcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbiB7XG4gIHdpZHRoOiAxNzcuMjFweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGdhcDogOC43cHg7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246OmJlZm9yZSB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgYm90dG9tOiAwO1xuICBib3JkZXItcmFkaXVzOiA2Ljk2cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSkgYm9yZGVyLWJveDtcbiAgLXdlYmtpdC1tYXNrOiBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApIHBhZGRpbmctYm94LCBsaW5lYXItZ3JhZGllbnQoI2ZmZiAwIDApO1xuICAtd2Via2l0LW1hc2stY29tcG9zaXRlOiBkZXN0aW5hdGlvbi1vdXQ7XG4gIG1hc2stY29tcG9zaXRlOiBleGNsdWRlO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uIC5wLWJ1dHRvbi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzU5NzhGNyAwJSwgIzlDODRGRiAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xuICBmb250LXdlaWdodDogNTAwO1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNhbmNlbC1idXR0b246aG92ZXI6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKSBib3JkZXItYm94O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5jYW5jZWwtYnV0dG9uOmhvdmVyIC5wLWJ1dHRvbi1sYWJlbCB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzQ5NjdFNiAwJSwgIzhCNzNFRSAxMDAlKTtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY2FuY2VsLWJ1dHRvbjpmb2N1cyB7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cucC1mbHVpZCB7XG4gIGhlaWdodDogYXV0bztcbn1cbjpob3N0IDo6bmctZGVlcCAucC1kaWFsb2cucC1mbHVpZCAucC1kaWFsb2ctY29udGVudCB7XG4gIG92ZXJmbG93LXk6IHZpc2libGU7XG4gIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgbWF4LWhlaWdodDogbm9uZSAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5wLWRpYWxvZyAucC1mbHVpZCAuZ3JpZCB7XG4gIHJvdy1nYXA6IDEuNXJlbTtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 21323:
/*!***************************************************************************************!*\
  !*** ./src/app/modules/app/school/school-count-cards/school-count-cards.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolCountCardComponent: () => (/* binding */ SchoolCountCardComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 72513);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 20274);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61699);
/* harmony import */ var _school_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../school.service */ 6219);



class SchoolCountCardComponent {
  constructor(_schoolService) {
    this._schoolService = _schoolService;
    this.totalSchools = 0;
    this.activeSchools = 0;
    this.inactiveSchools = 0;
    this._unsubscribeAll = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
  }
  ngOnInit() {
    this.getCountCard();
    // Subscribe to school updates
    this._schoolService.schoolList$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.takeUntil)(this._unsubscribeAll)).subscribe(() => {
      this.getCountCard();
    });
  }
  ngOnDestroy() {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
  getCountCard() {
    this._schoolService.getSchoolCounts().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.takeUntil)(this._unsubscribeAll)).subscribe({
      next: response => {
        if (response.success && response.data) {
          this.totalSchools = response.data.totalSchools;
          this.activeSchools = response.data.activeSchools;
          this.inactiveSchools = response.data.inactiveSchools;
        }
      },
      error: error => {
        console.error('Error fetching school counts:', error);
        this.totalSchools = 0;
        this.activeSchools = 0;
        this.inactiveSchools = 0;
      }
    });
  }
  static #_ = this.ɵfac = function SchoolCountCardComponent_Factory(t) {
    return new (t || SchoolCountCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_school_service__WEBPACK_IMPORTED_MODULE_0__.SchoolService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: SchoolCountCardComponent,
    selectors: [["app-school-count-card"]],
    decls: 22,
    vars: 3,
    consts: [[1, "grid", "nested-grid", "pl-0"], [1, "col-12", "xl:col-8", "lg:col-8", "md:col-12", "sm:col-12", "w-full"], [1, "flex", "flex-wrap", "w-full", "gap-2", "justify-content-between", "align-items-center"], [1, "flex", "flex-wrap", "gap-2"], [1, "count-card"], [1, "count-card-content"], [1, "count-label"], [1, "count-value"]],
    template: function SchoolCountCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7, "Total Schools");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 4)(11, "div", 5)(12, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](13, "Active Schools");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "div", 4)(17, "div", 5)(18, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, "Inactive Schools");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.totalSchools);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.activeSchools);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.inactiveSchools);
      }
    },
    styles: ["[_nghost-%COMP%]     .count-card {\n  width: 173px;\n  height: 77px;\n}\n[_nghost-%COMP%]     .count-card .count-card-content {\n  height: 100%;\n  background: var(--White-colour, #ffffff);\n  border: 1px solid rgba(22, 40, 49, 0.1);\n  border-radius: 12px;\n  padding: 1rem;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n[_nghost-%COMP%]     .count-card .count-label {\n  font-size: 14px;\n  font-weight: 600;\n  color: rgba(65, 65, 78, 0.8);\n  max-width: 100px;\n}\n[_nghost-%COMP%]     .count-card .count-value {\n  font-size: 18px;\n  font-weight: 600;\n  color: #41414E;\n  background: linear-gradient(90deg, #5978F7 0%, #9C84FF 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  -webkit-text-fill-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAvc2Nob29sL3NjaG9vbC1jb3VudC1jYXJkcy9zY2hvb2wtY291bnQtY2FyZHMuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi9OZXclMjBmb2xkZXIvdmdzY2hvb2wtdGhlbWUvc3JjL2FwcC9tb2R1bGVzL2FwcC9zY2hvb2wvc2Nob29sLWNvdW50LWNhcmRzL3NjaG9vbC1jb3VudC1jYXJkcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLFlBQUE7RUFDQSxZQUFBO0FDQVI7QURFUTtFQUNJLFlBQUE7RUFDQSx3Q0FBQTtFQUNBLHVDQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUNBWjtBREdRO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtBQ0RaO0FESVE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsNERBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0NBQUE7QUNGWiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IDo6bmctZGVlcCB7XHJcbiAgICAuY291bnQtY2FyZCB7XHJcbiAgICAgICAgd2lkdGg6IDE3M3B4O1xyXG4gICAgICAgIGhlaWdodDogNzdweDtcclxuXHJcbiAgICAgICAgLmNvdW50LWNhcmQtY29udGVudCB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tV2hpdGUtY29sb3VyLCAjZmZmZmZmKTtcclxuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMiwgNDAsIDQ5LCAwLjEpO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxcmVtO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY291bnQtbGFiZWwge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiByZ2JhKDY1LCA2NSwgNzgsIDAuOCk7XHJcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuY291bnQtdmFsdWUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNDE0MTRFO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsICM1OTc4RjcgMCUsICM5Qzg0RkYgMTAwJSk7XHJcbiAgICAgICAgICAgIC13ZWJraXQtYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XHJcbiAgICAgICAgICAgIC13ZWJraXQtdGV4dC1maWxsLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iLCI6aG9zdCA6Om5nLWRlZXAgLmNvdW50LWNhcmQge1xuICB3aWR0aDogMTczcHg7XG4gIGhlaWdodDogNzdweDtcbn1cbjpob3N0IDo6bmctZGVlcCAuY291bnQtY2FyZCAuY291bnQtY2FyZC1jb250ZW50IHtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1XaGl0ZS1jb2xvdXIsICNmZmZmZmYpO1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDIyLCA0MCwgNDksIDAuMSk7XG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gIHBhZGRpbmc6IDFyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbjpob3N0IDo6bmctZGVlcCAuY291bnQtY2FyZCAuY291bnQtbGFiZWwge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiByZ2JhKDY1LCA2NSwgNzgsIDAuOCk7XG4gIG1heC13aWR0aDogMTAwcHg7XG59XG46aG9zdCA6Om5nLWRlZXAgLmNvdW50LWNhcmQgLmNvdW50LXZhbHVlIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzQxNDE0RTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjNTk3OEY3IDAlLCAjOUM4NEZGIDEwMCUpO1xuICAtd2Via2l0LWJhY2tncm91bmQtY2xpcDogdGV4dDtcbiAgYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xuICAtd2Via2l0LXRleHQtZmlsbC1jb2xvcjogdHJhbnNwYXJlbnQ7XG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 71688:
/*!*************************************************************!*\
  !*** ./src/app/modules/app/school/school-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolRoutingModule: () => (/* binding */ SchoolRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 27947);
/* harmony import */ var src_app_core_classroom_classroom_shared_resolver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/classroom/classroom-shared.resolver */ 40226);
/* harmony import */ var _list_school_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list/school.component */ 54920);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61699);





class SchoolRoutingModule {
  static #_ = this.ɵfac = function SchoolRoutingModule_Factory(t) {
    return new (t || SchoolRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
    type: SchoolRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild([{
      path: '',
      component: _list_school_component__WEBPACK_IMPORTED_MODULE_1__.SchoolComponent,
      pathMatch: 'full',
      data: {
        breadcrumb: 'School'
      },
      resolve: {
        classrooms: src_app_core_classroom_classroom_shared_resolver__WEBPACK_IMPORTED_MODULE_0__.classroomsResolver
      }
    }]), _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](SchoolRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
})();

/***/ }),

/***/ 95467:
/*!*****************************************************!*\
  !*** ./src/app/modules/app/school/school.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolModule: () => (/* binding */ SchoolModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 26575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 28849);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/table */ 56192);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/fileupload */ 88285);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/button */ 32947);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/ripple */ 51339);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/toast */ 68313);
/* harmony import */ var primeng_toolbar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/toolbar */ 39177);
/* harmony import */ var primeng_rating__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/rating */ 85583);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/inputtext */ 10873);
/* harmony import */ var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/inputtextarea */ 30652);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/dropdown */ 94553);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/radiobutton */ 63313);
/* harmony import */ var primeng_inputnumber__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/inputnumber */ 65362);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dialog */ 53311);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/calendar */ 57411);
/* harmony import */ var primeng_multiselect__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/multiselect */ 77524);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/tooltip */ 31251);
/* harmony import */ var primeng_splitbutton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/splitbutton */ 64323);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/menu */ 95518);
/* harmony import */ var _school_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./school-routing.module */ 71688);
/* harmony import */ var _list_school_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list/school.component */ 54920);
/* harmony import */ var _school_count_cards_school_count_cards_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./school-count-cards/school-count-cards.component */ 21323);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61699);
























class SchoolModule {
  static #_ = this.ɵfac = function SchoolModule_Factory(t) {
    return new (t || SchoolModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: SchoolModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule, _school_routing_module__WEBPACK_IMPORTED_MODULE_0__.SchoolRoutingModule, primeng_table__WEBPACK_IMPORTED_MODULE_6__.TableModule, primeng_fileupload__WEBPACK_IMPORTED_MODULE_7__.FileUploadModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_8__.ButtonModule, primeng_menu__WEBPACK_IMPORTED_MODULE_9__.MenuModule, primeng_calendar__WEBPACK_IMPORTED_MODULE_10__.CalendarModule, primeng_splitbutton__WEBPACK_IMPORTED_MODULE_11__.SplitButtonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_12__.RippleModule, primeng_toast__WEBPACK_IMPORTED_MODULE_13__.ToastModule, primeng_toolbar__WEBPACK_IMPORTED_MODULE_14__.ToolbarModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_15__.TooltipModule, primeng_rating__WEBPACK_IMPORTED_MODULE_16__.RatingModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_17__.InputTextModule, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_18__.InputTextareaModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_19__.DropdownModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_20__.RadioButtonModule, primeng_inputnumber__WEBPACK_IMPORTED_MODULE_21__.InputNumberModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.DialogModule, primeng_multiselect__WEBPACK_IMPORTED_MODULE_23__.MultiSelectModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](SchoolModule, {
    declarations: [_list_school_component__WEBPACK_IMPORTED_MODULE_1__.SchoolComponent, _school_count_cards_school_count_cards_component__WEBPACK_IMPORTED_MODULE_2__.SchoolCountCardComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule, _school_routing_module__WEBPACK_IMPORTED_MODULE_0__.SchoolRoutingModule, primeng_table__WEBPACK_IMPORTED_MODULE_6__.TableModule, primeng_fileupload__WEBPACK_IMPORTED_MODULE_7__.FileUploadModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_8__.ButtonModule, primeng_menu__WEBPACK_IMPORTED_MODULE_9__.MenuModule, primeng_calendar__WEBPACK_IMPORTED_MODULE_10__.CalendarModule, primeng_splitbutton__WEBPACK_IMPORTED_MODULE_11__.SplitButtonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_12__.RippleModule, primeng_toast__WEBPACK_IMPORTED_MODULE_13__.ToastModule, primeng_toolbar__WEBPACK_IMPORTED_MODULE_14__.ToolbarModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_15__.TooltipModule, primeng_rating__WEBPACK_IMPORTED_MODULE_16__.RatingModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_17__.InputTextModule, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_18__.InputTextareaModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_19__.DropdownModule, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_20__.RadioButtonModule, primeng_inputnumber__WEBPACK_IMPORTED_MODULE_21__.InputNumberModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_22__.DialogModule, primeng_multiselect__WEBPACK_IMPORTED_MODULE_23__.MultiSelectModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_modules_app_school_school_module_ts.js.map